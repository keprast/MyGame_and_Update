﻿#ifndef state_transition_
#define state_transition_

#include"player_sys.h"
#include"animation_sys.h"
#include"gui_sys.h"
#include"state_transition_elem.h"

//不要让优化先于实现
//后期再创造表值判断法
//状态转换器
class state_transition :public state_transition_elem
{
public:
	//转换位置
	enum T_POS
	{
		MAXIS,
		BAXIS
	};

	//按钮键值
	enum Button_value
	{
		MOUSE_L_BUTTON_DOWN = 1,//鼠标左键被按下
		MOUSE_R_BUTTON_DOWN = 10,//鼠标右键被按下
		MOUSE_LR_BUTTON_DOWN = 11,//鼠标左右键同时按下
		KEY_W_BUTTON_DOWN = 100,
		KEY_S_BUTTON_DOWN = 1000,
		KEY_A_BUTTON_DOWN = 10000,
		KEY_WA_BUTTON_DOWN = 10100,
		KEY_SA_BUTTON_DOWN = 11000,
		KEY_D_BUTTON_DOWN = 100000,
		KEY_WD_BUTTON_DOWN = 100100,
		KEY_SD_BUTTON_DOWN = 101000,
		KEY_R_BUTTON_DOWN = 1000000
	};

	//键值
	struct Key_Value
	{
		int m_value;//鼠标键值
		int k_value;//键盘键值
	};

	//初始化转换数，初始化转换位置
	state_transition();
	~state_transition();

	//设定控制器集合
	void set_tra_obj_num(int obj_num, int sub_obj_num);
	//获取当前控制器数目
	int get_TS_num();
	int get_TS_sub_num();
	//获取临时对象
	Transition_op_to_anima & get_tran();

protected:
	static const int windows_num = 3;//可操作窗口数目

	int tra_obj_num;
	int tra_sub_obj_num;
	static int now_windows;//当前的窗口
	Tran_id_plus * transiting;//运行中的中转数据
	Transition_op_to_anima tran;//临时对象
	Transition_op_to_anima * set_tran[windows_num];

	player_sys::Player_opertion temp_pdate;//临时玩家数据
	Key_Value value;

	//键值转换器（鼠标）
	void key_value_transition_for_mouse();
	//键值转换器（键盘）
	void key_value_transition_for_keybord();

	//初始化转换器并设定触发窗口id
	void init_transition(int w_id, int obj_num);
	//设定默认动作
	void set_tra_df_action_id(int w_id, int obj_id, int act_id, T_POS pos, int b_id, int a_id, int lev);
	//初始化坐标触发数目
	void init_tra_other_act_num(int w_id, int obj_id, int act_num);
	//设定按钮动作权级
	void set_tra_action_lever_for_button(int w_id, int obj_id, int act_id, T_POS pos, int butt_arr, int lev);
	//设定坐标动作权级
	void set_tra_action_lever_for_axis(int w_id, int obj_id, int act_id, int lev);
	//设定坐标触发位置（obj_id为操作位，一个位图结构只能有一个操作位）
	void set_tra_for_axis(int w_id, int obj_id, int act_id, int b_id, int a_id, float on_x, float on_y, float to_x, float to_y);
	//初始化按钮（pos为按钮的位置）
	void set_tra_for_button(int w_id, int obj_id, int act_id, T_POS pos, int b_num = 0);
	//设定按钮的位置和触发的位置
	void set_button_pos(int w_id, int obj_id, int act_id, T_POS pos, int b_arr, int b_id, int a_id);
	//设定按钮的键值
	void set_button_value(int w_id, int obj_id, int act_id, T_POS pos, int button_arr, Button_value b_val);
	//获取触发结构数据
	Transition_op_to_anima *& get_transition(int w_id);
	//设定鼠标划过时的关联
	void set_axis_ass_bmp(int w_id, int obj_id, int act_id, T_POS pos, int bmp_id, bool lock, int id);
	//设定按钮关联位图
	void set_button_ass_bmp(int w_id, int obj_id, int act_id, T_POS pos, int b_arr, bool lock = false, int other_bid = 0, int other_aid = 0);
	//设定按钮关联窗口
	void set_button_ass_win(int w_id, int obj_id, int act_id, T_POS pos, int b_arr, bool lock, int win_id);

private:

};

#endif

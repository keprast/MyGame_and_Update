﻿#ifndef ui_sys_
#define ui_sys_

#include"allegro5\allegro.h"
#include"allegro5\allegro_image.h"
#include"string"
#include"animation_sys.h"
#include"gui_config.h"
/**
*若需要增加gui窗口数目
*修改init_gui函数
*修改init_gui_style函数
*修改Gui_name标记
*修改Gui_init_table标记
*修改控制器中的逻辑部分
*/
class Gui_sys :public animation_sys
{
public:
	//Gui名字表
	enum Gui_name
	{
		INDEX,
		INDEX_About,
		INDEX_Config,
		INDEX_StaGame,
		INDEX_StaGames,
	};

	//初始化队列并设定名字
	Gui_sys(int gui_e_num);
	~Gui_sys();

	//初始化UI
	void init_gui();
	//切换gui
	void update_gui(Gui_sys::Gui_name name);
	//获取当前gui名字
	int get_gui_name();

private:
	static int gui_num;//Gui的数目
	static int after_gui_name;//上一个Gui的名字
	static int now_gui_name;//当前Gui的名字
	static Gui_config * gui_animation;//Gui动画

	//注册逻辑至框架系统
	void reg_logic_to_event_queue(Gui_config & obj);
	//初始化Gui
	void init_gui_style(Gui_config & animation, Gui_name flg);

	//首页
	void init_index(Gui_config & obj);
	//开始游戏
	void init_index_stagame(Gui_config & obj);//待完善
	//关于
	void init_index_about(Gui_config & obj);
	//设置
	void init_index_config(Gui_config & obj);

};

#endif // !ui_sys_
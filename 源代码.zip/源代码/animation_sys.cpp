﻿#include"animation_sys.h"
#include<iostream>

using std::cout;
using std::endl;

animation_elem animation_sys::Ui_draw_elem;
animation_elem animation_sys::MapContext_draw_elem;
animation_elem animation_sys::MapUnit_draw_elem;
animation_elem animation_sys::PlayerSpriti_darw_elem;
animation_elem animation_sys::AiSpriti_draw_elem;
animation_sys::Animation * animation_sys::sorter[5]{ nullptr };
int animation_sys::sorter_num[5]{ 0 };
ALLEGRO_EVENT * animation_sys::event = nullptr;
ALLEGRO_EVENT_QUEUE * animation_sys::event_queue = nullptr;

animation_sys::animation_sys()
{
	sta_timer = 0;
	tran_id = nullptr;
	tran_id_num = 0;
	reset = true;
}

animation_sys::~animation_sys()
{
	if (Ui_draw_elem.elem_head)
		Ui_draw_elem.destroy_Animation_elem(Ui_draw_elem.elem_head);
	if (MapContext_draw_elem.elem_head)
		MapContext_draw_elem.destroy_Animation_elem(MapContext_draw_elem.elem_head);
	Del_sorter();
}

animation_elem * animation_sys::get_object(Animation_elem_flags flg)
{
	switch (flg)
	{
	case animation_elem::Ui_ELEM:
		return &Ui_draw_elem;
	case animation_elem::MapContext_ELEM:
		return &MapContext_draw_elem;
	case animation_elem::MapUnit_ELEM:
		return &MapUnit_draw_elem;
	case animation_elem::PlayerSpriti_ELEM:
		return &PlayerSpriti_darw_elem;
	case animation_elem::AiSpriti_ELEM:
		return &AiSpriti_draw_elem;
	}
	return nullptr;
}

void animation_sys::flip_reset()
{
	if (reset == false)
		reset = true;
	else
		reset = false;
}

void animation_sys::get_event_queue(ALLEGRO_EVENT_QUEUE *& event_queue)
{
	this->event_queue = event_queue;
}

void animation_sys::get_event(ALLEGRO_EVENT & ev)
{
	event = &ev;
}

void animation_sys::init_animation_draw_elem(Animation_elem_flags flg, int e_num)
{
	if (flg == Ui_ELEM) 
		Ui_draw_elem.elem_head = Ui_draw_elem.create_Animation_elem(e_num);
	else if (flg == MapContext_ELEM) 
		MapContext_draw_elem.elem_head = MapContext_draw_elem.create_Animation_elem(e_num);
	else if (flg == MapUnit_ELEM) 
		MapUnit_draw_elem.elem_head = MapUnit_draw_elem.create_Animation_elem(e_num);
	else if (flg == PlayerSpriti_ELEM) 
		PlayerSpriti_darw_elem.elem_head = PlayerSpriti_darw_elem.create_Animation_elem(e_num);
	else if (flg == AiSpriti_ELEM) 
		AiSpriti_draw_elem.elem_head = AiSpriti_draw_elem.create_Animation_elem(e_num);
}

void animation_sys::clean_tran_id()
{
	for (int i = 0; i < tran_id_num; i++)
	{
		tran_id[tran_id_num].assoc_lock = false;
		tran_id[tran_id_num].lever = -1;
		tran_id[tran_id_num].pid = -1;
		tran_id[tran_id_num].assoc_winid = -1;
		tran_id[tran_id_num].to_acting_id = -1;
		tran_id[tran_id_num].to_bitmap_id = -1;
	}
}

void animation_sys::update_gui_animation()
{
	obj_num = get_have_date_num(elem_head);

	for (int i = 0; i < obj_num; i++)
	{
		get_Animation_elem_date(i, elem_head, draw_object);
		Ui_draw_elem.in_Animation_elem_date_is_null(Ui_draw_elem.elem_head, draw_object);
	}
}

void animation_sys::update_animation_date(Animation_elem_flags flg, state_transition_elem::Tran_id_plus * t_id)
{
	obj_num = get_have_date_num(get_elem(flg));

	for (int i = 0; i < obj_num; i++)
	{
		if (flg == Ui_ELEM)
			set_animation_date(i, t_id, Ui_draw_elem.elem_head);
	}
}

void animation_sys::update_animation_timer(Animation_elem_flags flg)
{
	if (reset) {
		obj_num = get_have_date_num(get_elem(flg));

		init_order_flg();
		for (int i = 0; i < obj_num; i++)
		{
			get_Animation_elem_order_date(get_elem(flg), draw_object);
			for (int j = 0; j < draw_object.bitmap_obj_num; j++)
				al_set_timer_speed(draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].animation_timer->get_timer(),
					draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].animation_timer->get_timer_sec());
		}
	}
}

void animation_sys::animation_draw_object(Animation_elem_flags flg)
{
	obj_num = get_have_date_num(get_elem(flg));

	Animation_sorter(flg);
	for (int i = 0; i < obj_num; i++)
	{
		Get_sorter(i, draw_object, flg);
		for (int j = 0; j < draw_object.bitmap_obj_num; j++)
		{
			if (!draw_object.bmp[j].non_obj) {
				al_draw_rotated_bitmap(draw_object.bmp[j].animations->get_bitmap(draw_object.bmp[j].now_arr),
					draw_object.bmp[j].bitmap_wh[draw_object.bmp[j].now_arr].bitmap_w / 2.0,
					draw_object.bmp[j].bitmap_wh[draw_object.bmp[j].now_arr].bitmap_h / 2.0,
					draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].axis->b_x +
					draw_object.bmp[j].bitmap_wh[draw_object.bmp[j].now_arr].bitmap_w / 2.0,
					draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].axis->b_y +
					draw_object.bmp[j].bitmap_wh[draw_object.bmp[j].now_arr].bitmap_h / 2.0,
					draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].axis->b_arc,
					ALLEGRO_VIDEO_BITMAP);
			}
			if (draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].flags->d_arr
				== draw_object.bmp[j].now_arr || draw_object.bmp[j].non_obj) {
				draw_object.bmp[j].have_action = false;
				draw_object.bmp[j].draw_OK = true;
			}
		}
		in_Animation_elem_date_is_null(Ui_draw_elem.elem_head, draw_object);
	}
}

void animation_sys::clean_animation_elem_object(Animation_elem_flags flg)
{
	if (flg == Ui_ELEM)
		Ui_draw_elem.clean_Animation_elem(Ui_draw_elem.elem_head);
	else 
		MapContext_draw_elem.clean_Animation_elem(MapContext_draw_elem.elem_head);
}

bool animation_sys::lock_animation_action_state(Animation_elem_flags flg)
{
	int num = 0;
	if (flg == Ui_ELEM)
		num = Ui_draw_elem.get_have_action_num(Ui_draw_elem.elem_head);
	else
		num = MapContext_draw_elem.get_have_action_num(MapContext_draw_elem.elem_head);
	if (num > 0)
		return true;

	return false;
}

void animation_sys::start_animation_timer(Animation_elem_flags flg)
{
	if (reset) {
		obj_num = get_have_date_num(get_elem(flg));

		for (int i = 0; i < obj_num; i++)
		{
			Ui_draw_elem.get_Animation_elem_date(i, get_elem(flg), draw_object);

			for (int j = 0; j < draw_object.bitmap_obj_num; j++)
				al_start_timer(draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].animation_timer->get_timer());
		}
	}
}

bool animation_sys::run_animation_timer(Animation_elem_flags flg)
{
	bool back = false;
	int obj_num = get_have_date_num(get_elem(flg));

	get_object(flg)->init_order_flg();
	for (int i = 0; i < obj_num; i++)
	{
		get_object(flg)->get_Animation_elem_order_date(get_elem(flg), draw_object);

		for (int j = 0; j < draw_object.bitmap_obj_num; j++)
		{
			for (int k = 0; k < draw_object.bmp[j].action_num; k++)
			{
				if (event->timer.source == draw_object.bmp[j].action[k].animation_timer->get_timer()) {
					update_animation_logic(flg, draw_object.bmp[j]);
					back = true;
				}
				if (back)
					break;
			}
			if (back)
				break;
		}
		in_Animation_elem_date(i, get_elem(flg), draw_object);
		if (back)
			break;
	}
	return true;
}

void animation_sys::stop_animation_timer(Animation_elem_flags flg)
{

}

bool animation_sys::lock_animation_action_state(Animation_elem * head)
{
	for (int i = 0; i < obj_num; i++)
	{
		if (head->has_date) {
			for (int j = 0; j < head->date.bitmap_obj_num; j++)
				if (head->date.bmp[j].have_action)
					return true;
		}
		head = head->next_elem;
	}
	return false;
}

//动画排序器启动
void animation_sys::Animation_sorter(Animation_elem_flags flg)
{
	static int sub_obj_num;
	obj_num = get_have_date_num(get_elem(flg));
	sub_obj_num = 0;

	init_order_flg();
	for (int i = 0; i < obj_num; i++)
	{
		if (flg == Ui_ELEM)
			get_Animation_elem_order_date(Ui_draw_elem.elem_head, draw_object);
		else if (flg == MapUnit_ELEM)
			get_Animation_elem_order_date(MapUnit_draw_elem.elem_head, draw_object);
		else if (flg == PlayerSpriti_ELEM)
			get_Animation_elem_order_date(PlayerSpriti_darw_elem.elem_head, draw_object);
		else if (flg == AiSpriti_ELEM)
			get_Animation_elem_order_date(AiSpriti_draw_elem.elem_head, draw_object);

		sub_obj_num += draw_object.bitmap_obj_num;
	}

	if (obj_num != 0) {
		if (obj_num > sorter_num[flg] && sorter_num[flg] != 0) {//对象较大，重新分配排序器
			delete[] sorter[flg];
			sorter[flg] = nullptr;
			sorter[flg] = new animation_elem::Animation[obj_num + 1];
			sorter[flg][obj_num].bmp = new Bmp_date[16];
			for (int i = 0; i < 16; i++)
				sorter[flg][obj_num].bmp[i].animations = new animation(33);
		}
		else if (sorter_num[flg] == 0) {//初始化
			sorter[flg] = new animation_elem::Animation[obj_num + 1];//预留一个空间作为缓冲区
			sorter[flg][obj_num].bmp = new Bmp_date[16];
			for (int i = 0; i < 16; i++)
				sorter[flg][obj_num].bmp[i].animations = new animation(33);
		}
		sorter_num[flg] = obj_num;

		init_order_flg();
		for (int i = 0; i < obj_num; i++)
		{
			if (flg == Ui_ELEM)
				get_Animation_elem_order_date(Ui_draw_elem.elem_head, sorter[flg][i]);
			else if (flg == MapUnit_ELEM)
				get_Animation_elem_order_date(MapUnit_draw_elem.elem_head, sorter[flg][i]);
			else if (flg == PlayerSpriti_ELEM)
				get_Animation_elem_order_date(PlayerSpriti_darw_elem.elem_head, sorter[flg][i]);
			else if (flg == AiSpriti_ELEM)
				get_Animation_elem_order_date(AiSpriti_draw_elem.elem_head, sorter[flg][i]);
		}

		for (int i = 0; i < obj_num; i++)//排序单个对象的层数
		{
			for (int j = 0; j < sorter[flg][i].bitmap_obj_num; j++)
			{
				if (sorter[flg][i].bitmap_obj_num == 1)
					break;
				if (j + 1 == sorter[flg][i].bitmap_obj_num)
					break;
				if (sorter[flg][i].bmp[j].lever > sorter[flg][i].bmp[j + 1].lever) {
					sorter[flg][obj_num].bmp[15] = sorter[flg][i].bmp[j];
					sorter[flg][i].bmp[j] = sorter[flg][i].bmp[j + 1];
					sorter[flg][i].bmp[j + 1] = sorter[flg][obj_num].bmp[15];
				}
			}
		}
		if (flg == 0 || flg == 2) {
			for (int i = 0; i < obj_num; i++)//排序多个对象的层数
			{
				for (int j = 0; j < obj_num - i; j++)
				{
					if (j == obj_num - i)
						break;
					if (sorter[flg][j].lever > sorter[flg][j + 1].lever) {
						sorter[flg][obj_num] = sorter[flg][j];
						sorter[flg][j] = sorter[flg][j + 1];
						sorter[flg][j + 1] = sorter[flg][obj_num];
					}
				}
			}
		}
	}
	else
		cout << "绘制队列不存在对象！排序器" << endl;
}

//破坏排序器
void animation_sys::Del_sorter()
{
	if (sorter[0] != nullptr) {
		delete[] sorter[0];
		sorter[0] = nullptr;
	}
	else if (sorter[1] != nullptr) {
		delete[] sorter[1];
		sorter[1] = nullptr;
	}
	else if (sorter[2] != nullptr) {
		delete[] sorter[2];
		sorter[2] = nullptr;
	}
	else if (sorter[3] != nullptr) {
		delete[] sorter[3];
		sorter[3] = nullptr;
	}
	else if (sorter[4] != nullptr) {
		delete[] sorter[4];
		sorter[4] = nullptr;
	}
}

//获取排序器对象
void animation_sys::Get_sorter(int pos, Animation & obj, Animation_elem_flags flg)
{
	if (pos > sorter_num[flg])
		cout << "排序器获取位置无效！" << endl;
	else
		obj = sorter[flg][pos];
}

//获取排序数目
int animation_sys::get_sorter_num(Animation_elem_flags flg)
{
	return sorter_num[flg];
}

void animation_sys::update_animation_logic(Animation_elem_flags flg, Bmp_date & obj)
{
	if (obj.action[obj.in_acting_id].flags->while_draw_flg) {
		//初始化渲染位置
		if (obj.action[obj.in_acting_id].flags->in_while_flg == false) {
			obj.action[obj.in_acting_id].flags->d_arr = obj.action[obj.in_acting_id].flags->sta_num;
			obj.action[obj.in_acting_id].flags->in_while_flg = true;
		}//渲染到末尾
		else if (obj.now_arr == obj.action[obj.in_acting_id].flags->end_num) {
			obj.action[obj.in_acting_id].flags->in_while_flg = false;
			obj.have_action = false;
			if (obj.action[obj.in_acting_id].flags->while_draw)//循环渲染
				obj.now_arr = obj.action[obj.in_acting_id].flags->sta_num;
		}//渲染状态变化
		else
			obj.now_arr += 1;
	}
	else if (obj.action[obj.in_acting_id].flags->now_draw_flg)
		obj.now_arr = obj.action[obj.in_acting_id].flags->d_arr;
}

animation_sys::Animation_elem *& animation_sys::get_elem(Animation_elem_flags flg)
{
	static Animation_elem * not_this = nullptr;

	switch (flg)
	{
	case animation_elem::Ui_ELEM:
		return Ui_draw_elem.elem_head;
	case animation_elem::MapContext_ELEM:
		return MapContext_draw_elem.elem_head;
	case animation_elem::MapUnit_ELEM:
		return MapUnit_draw_elem.elem_head;
	case animation_elem::PlayerSpriti_ELEM:
		return PlayerSpriti_darw_elem.elem_head;
	case animation_elem::AiSpriti_ELEM:
		return AiSpriti_draw_elem.elem_head;
	}

	return not_this;
}

void animation_sys::set_op_obj_num(int obj_num)
{
	if (tran_id_num == 0) {
		tran_id = new state_transition_elem::Tran_id[obj_num];
	}
	else if(tran_id_num != 0 && tran_id_num != obj_num){
		delete[] tran_id;
		tran_id = nullptr;
		tran_id = new state_transition_elem::Tran_id[obj_num];
	}
	tran_id_num = obj_num;
	for (int i = 0; i < obj_num; i++)
	{
		tran_id[i].assoc_winid = -1;
		tran_id[i].assoc_lock = false;
		tran_id[i].lever = 0;
		tran_id[i].pid = -1;
		tran_id[i].to_acting_id = -1;
		tran_id[i].to_bitmap_id = -1;
	}
}

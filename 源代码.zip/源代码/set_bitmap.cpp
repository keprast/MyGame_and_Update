﻿#include"set_bitmap.h"
#include<iostream>

using std::cout;
using std::endl;

set_bitmap::set_bitmap()
{
}

set_bitmap::~set_bitmap()
{
}

void set_bitmap::init_bitmap(int b_id, int obj_num, animation_elem::Animation & animation, std::string bmp_name)
{
	animation.bitmap_id = b_id;
	animation.bitmap_count_num = 0;
	animation.bitmap_obj_num = obj_num;
	animation.bitmap_name = bmp_name;
	animation.bmp = new animation_elem::Bmp_date[obj_num];
	for (int i = 0; i < obj_num; i++)
	{
		animation.bmp[i].have_action = false;
		animation.bmp[i].animations = nullptr;
	}
}

void set_bitmap::set_bitmap_num(int obj_arr, int b_num, animation_elem::Animation & animation)
{
	animation.bitmap_count_num += b_num;
	animation.bmp[obj_arr].animations = new class animation(b_num);
	animation.bmp[obj_arr].non_obj = false;
	animation.bmp[obj_arr].bitmap_wh = new animation_elem::Animation_wh[b_num];
}

void set_bitmap::set_bitmap_name(int obj_arr, int b_arr, char * animation_name, std::string obj_names, animation_elem::Animation & animation)
{
	animation.bmp[obj_arr].obj_name = obj_names;
	animation.bmp[obj_arr].animations->set_bitmap(b_arr, animation_name);
	animation.bmp[obj_arr].bitmap_wh[b_arr].bitmap_w = al_get_bitmap_width(animation.bmp[obj_arr].animations->get_bitmap(b_arr));
	animation.bmp[obj_arr].bitmap_wh[b_arr].bitmap_h = al_get_bitmap_height(animation.bmp[obj_arr].animations->get_bitmap(b_arr));
}

void set_bitmap::set_bitmap_action_num(int obj_arr, int a_num, animation_elem::Animation & animation)
{
	animation.bmp[obj_arr].action_num = a_num;
	if (a_num >= 0) {
		animation.bmp[obj_arr].action = new animation_elem::Animation_action[a_num];
		for (int i = 0; i < a_num; i++) {
			animation.bmp[obj_arr].action[i].flags = new animation_elem::Animation_draw_flags;
			animation.bmp[obj_arr].action[i].axis = new animation_elem::Animation_axis;
		}
	}
}

void set_bitmap::set_bitmap_df_action_flags(int obj_arr, int act_id, int act_lev, animation_elem::Animation & animation)
{
	if (act_id > animation.bmp[obj_arr].action_num)
		cout << "动画ID：" << animation.bitmap_id << "，设定的默认行为超过了实际行为的大小。" << endl;
	animation.bmp[obj_arr].in_acting_id = act_id;
	animation.bmp[obj_arr].now_arr = animation.bmp[obj_arr].action[act_id].flags->d_arr;
}

void set_bitmap::set_bitmap_non_obj(int obj_arr, bool non, animation_elem::Animation & animation)
{
	animation.bmp[obj_arr].non_obj = non;
}

void set_bitmap::set_bitmap_action_times(int obj_arr, int act_arr, double t, animation_elem::Animation & animation)
{
	if (act_arr > animation.bmp[obj_arr].action_num)
		cout << "动画ID：" << animation.bitmap_id << "，设定的时间超过了实际行为的大小。" << endl;
	animation.bmp[obj_arr].action[act_arr].animation_timer = new timer_sys(t);
}

void set_bitmap::set_bitmap_action_axis(int obj_arr, int act_arr, float x, float y, float arc, animation_elem::Animation & animation)
{
	if (act_arr > animation.bmp[obj_arr].action_num)
		cout << "动画ID：" << animation.bitmap_id << "，设定的坐标超过了实际行为的大小。" << endl;
	animation.bmp[obj_arr].action[act_arr].action_id = act_arr;
	animation.bmp[obj_arr].action[act_arr].axis->b_x = x;
	animation.bmp[obj_arr].action[act_arr].axis->b_y = y;
	animation.bmp[obj_arr].action[act_arr].axis->b_arc = arc;
}

void set_bitmap::set_bitmap_action_draw_flags(int obj_arr, int act_arr, bool now_flg, bool whi_flg, int now_num, int sta, int end, animation_elem::Animation & animation, bool whi)
{
	if (act_arr > animation.bmp[obj_arr].action_num)
		cout << "动画ID：" << animation.bitmap_id << "，设定的标记超过了实际行为的大小。" << endl;
	animation.bmp[obj_arr].action[act_arr].action_id = act_arr;
	animation.bmp[obj_arr].action[act_arr].flags->while_draw_flg = whi_flg;
	animation.bmp[obj_arr].action[act_arr].flags->now_draw_flg = now_flg;
	animation.bmp[obj_arr].action[act_arr].flags->d_arr = now_num;
	animation.bmp[obj_arr].action[act_arr].flags->sta_num = sta;
	animation.bmp[obj_arr].action[act_arr].flags->end_num = end;
	animation.bmp[obj_arr].action[act_arr].flags->while_draw = whi;
	animation.bmp[obj_arr].action[act_arr].flags->in_while_flg = false;
}

void set_bitmap::set_bitmap_lever(int lev, animation_elem::Animation & animation)
{
	animation.lever = lev;
}

void set_bitmap::set_bitmap_lever(int obj_arr, int lev, animation_elem::Animation & animation)
{
	animation.bmp[obj_arr].lever = lev;
}

void set_bitmap::set_bitmap_pid(int obj_arr, int id, animation_elem::Animation & animation)
{
	animation.bmp[obj_arr].b_pid = id;
}

void set_bitmap::destory_bitmap_obj(animation_elem::Animation *& obj)
{
	delete obj;
}
﻿#ifndef unit_elem_
#define unit_elem_

#include"unit_sys.h"

//动画线性链表类
class unit_elem
{
public:
	//动画线性链表结构
	struct Unit_elem
	{
		int e_node_id;//节点id
		Unit_elem * after_elem;//前一个节点
		Unit_elem * next_elem;//后一个节点

		unit_sys::Unit date;//动画结构
		bool has_date;//数据有无标记
	};

	Unit_elem * elem_head;//线性链表头部
	Unit_elem * elem_tail;//线性链表尾部

	unit_elem();
	~unit_elem();

	//创建线性链表
	Unit_elem * create_Unit_elem(int e_num);
	//创建新节点
	void create_new_node();
	//在某节点后插入一个节点
	void create_an_node(Unit_elem * e_head, int node_id);
	//按照顺序获得数据
	void init_order_flg();
	bool get_Unit_elem_order_date(Unit_elem * e_head, unit_sys::Unit & unit);
	int get_order_flg();
	//获取某一节点的数据
	void get_Unit_elem_date(int u_pid, Unit_elem * e_head, unit_sys::Unit & need_date);
	void get_Unit_elem_arr_date(Unit_elem * e_head, unit_sys::Unit need_date[]);

	//数据自动插入一个空位置
	int in_Unit_elem_date_is_null(Unit_elem *e_head, unit_sys::Unit & in_date);
	//将数据插入某一节点
	void in_Unit_elem_date(int e_id, Unit_elem * e_head, unit_sys::Unit & in_date);

	//清洗线性链表
	void clean_Unit_elem(Unit_elem * e_head);
	//清除一个对象
	void clean_Unit_elem_node(Unit_elem * e_head, unit_sys::Unit & obj);
	//破坏线性链表
	void destroy_Unit_elem(Unit_elem *& e_head);
	//破坏一个节点
	void destroy_an_node(Unit_elem * e_head, int node_id);

	//前序遍历
	void pre_order_elem(Unit_elem * e_head);
	//后序遍历
	void lrd_order_elem(Unit_elem * e_tail);

	//检查线性链表的状态
	bool Unit_elem_is_state(Unit_elem * e_head);

	int get_e_node_num();

private:
	Unit_elem * get_node;//按顺序获取节点标记
	Unit_elem * in_node;//按顺序输入节点标记
	int e_node_num;//节点的数目
	int order_pos;//顺序标记
	int unit_num;//单元的数目

	//输出结构中的数据
	void get_node_date(Unit_elem * e_tail);

};

#endif 

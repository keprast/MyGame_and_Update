﻿#ifndef unit_sys_
#define unit_sys_

//单元的基本类，包含单元的全部特性和功能
//因为全是公有方法，所以其他单元类请使用类继承的方式获取相关数据
//切记不要在其他单元类中添加沉余数据
//在非单元类仅仅获取数据的位置不要使用类继承
//请用头文件的方式提供新的接口方案以获取单元数据
//单元系统类（基类）
class unit_sys
{
public:
	//单元的视野范围
	struct Unit_see
	{
		int see_area;
	};

	//单元的坐标属性结构
	struct Unit_axis
	{
		float u_x;//单元的x轴
		float u_y;//单元的y轴
		float u_z;//单元的z轴
		float u_arc;//单元的arc
	};

	//单元的速度属性结构
	struct Unit_v
	{
		float u_v_x;//单元的x轴速度
		float u_v_y;//单元的y轴速度
		float u_v_z;//单元的z轴速度
		float u_v_arc;//单元的arc速度
	};

	//单元的加速度属性结构
	struct Unit_a
	{
		float u_a_x;//单元的x轴加速度
		float u_a_y;//单元的y轴加速度
		float u_a_z;//单元的z轴加速度
		float u_a_arc;//单元的arc加速度
	};

	//单元的状态属性结构
	struct Unit_state
	{
		int u_hp;//单元的生命值
		bool u_is_live;//单元的存活状态

		int u_pid;//单元对象id（全局单元id）
		int u_itme_id;//单元项目id（表示这是什么单位）
		int u_team_id;//单元的队伍id
	};

	//单元的宽高结构
	struct Unit_wh
	{
		int u_w;//单元的宽
		int u_h;//单元的高
	};

	//单元的通用结构
	struct Unit
	{
		Unit_state state;//单元的状态
		Unit_axis axis;//单元的坐标
		Unit_wh wh;//单元的宽高
		Unit_v velocity;//单元的速度
		Unit_a accelerate;//单元的加速度
		Unit_see see;//单元的视野范围
	};

	unit_sys();
	~unit_sys();

	void set_unit_x(float x);
	void set_unit_y(float y);
	void set_unit_z(float z);
	void set_unit_arc(float arc);
	//设定单元的xyz和arc
	void set_unit_axis(float x, float y, float z, float arc);

	void set_unit_vx(float vx);
	void set_unit_vy(float vy);
	void set_unit_vz(float vz);
	void set_unit_varc(float varc);
	//设定单元的速度
	void set_unit_velocity(float vx, float vy, float vz, float varc);

	void set_unit_ax(float ax);
	void set_unit_ay(float ay);
	void set_unit_az(float az);
	void set_unit_aarc(float aarc);
	//设定单元的加速度
	void set_unit_accelerate(float ax, float ay, float az, float aarc);
	
	void set_unit_see_area(int r);
	void set_unit_pid(int obj_pid);
	void set_unit_itme_id(int itme_id);
	void set_unit_team_id(int team_id);
	void set_unit_hp(int hp);
	void set_unit_live(bool live);
	//设定单元的属性
	void set_unit_state(int obj_id, int team_id, int hp, bool live, int itme_id = -1);
	//设定单元的数据
	void set_unit(Unit & un);
	
	//设定单元的宽高
	void set_unit_wh(int w, int h);

	int & get_unit_w();
	int & get_unit_h();
	int & get_unit_hp();
	int & get_unit_object_id();
	int & get_unit_itme_id();
	int & get_unit_team_id();
	bool & get_unit_is_live();
	//获得单元的状态属性
	Unit_state & get_unit_state();

	float & get_unit_x();
	float & get_unit_y();
	float & get_unit_z();
	float & get_unit_arc();
	//获得单元的坐标属性
	Unit_axis & get_unit_axis();

	float & get_unit_vx();
	float & get_unit_vy();
	float & get_unit_vz();
	float & get_unit_varc();
	//获得单元的速度属性
	Unit_v & get_unit_velocity();

	float & get_unit_ax();
	float & get_unit_ay();
	float & get_unit_az();
	float & get_unit_aarc();
	//获得单元的加速度属性
	Unit_a & get_unit_accelerate();
	//获得单元的一切数据
	Unit & get_unit();

private:
	Unit unit;//单元的数据
	static int unit_num;//单元的数目

};

extern float pi;//π的值

#endif // !unit_sys


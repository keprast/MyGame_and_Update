﻿#ifndef logic_
#define logic_

#include"player_sys.h"
#include"set_player.h"
#include"ai_sys.h"
#include"ai_state.h"
#include"set_sys.h"
#include"set_map.h"
#include"controller.h"
#include"association.h"

#endif 

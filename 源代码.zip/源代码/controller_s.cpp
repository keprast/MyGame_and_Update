﻿#include"controller_s.h"
#include<iostream>

using std::cout;
using std::endl;

controller_s::controller_s()
{
}

controller_s::~controller_s()
{
}

void controller_s::register_date_in_map(int map_val, player_sys::Player_opertion & pdate, State_Transition_elem *& table_head)
{
	temp_pdate = pdate;
	value = { 0,0 };
	get_ST_elem_date(map_val, table_head, tran);//获取窗口数据

	key_value_transition_for_mouse();//转换键值
	key_value_transition_for_keybord();

	controller_pid_date();

	MoveBmp();
}

void controller_s::controller_pid_date()
{

}
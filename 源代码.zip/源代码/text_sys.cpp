﻿#include"text_sys.h"

#if defined(_MSC_VER) && (_MSC_VER >= 1900)
#pragma execution_character_set("utf-8")
#endif

text_sys::Axis text_sys::unit_axis{ 0 };
text_sys * text_sys::text_date = nullptr;
text_sys::Text text_sys::after_text;
text_sys::Slide_text text_sys::after_slide;
int text_sys::now_draw_text = 0;
int text_sys::now_draw_win = 0;

ALLEGRO_EVENT_QUEUE * text_sys::event_queue = nullptr;
ALLEGRO_EVENT * text_sys::event = nullptr;
player_sys::Player_opertion * text_sys::opertion = nullptr;
int * text_sys::slide_flg = nullptr;
int text_sys::slide_addup = 0;

text_sys::text_sys()
{
	text_num = 0;
}

text_sys::~text_sys()
{
}

void text_sys::init_text()
{
	text_date = new text_sys[5];

	text_date[Gui_sys::INDEX].line_text("毫无   作用", 210, 207, size_32, Black, simhei);
	text_date[Gui_sys::INDEX].line_text("尝试   游玩", 210, 331);
	text_date[Gui_sys::INDEX].line_text("关于   我们", 210, 457);
	text_date[Gui_sys::INDEX].line_text("操作   设置", 210, 581);

	text_date[Gui_sys::INDEX].start_slide_text(5);
	text_date[Gui_sys::INDEX].text_slide(text_date[Gui_sys::INDEX].line_text("这是测试A", 610, 107)
		, lengthways, Mouse_axis, 5, 1 / 10.0, 30.0, size_16);
	text_date[Gui_sys::INDEX].text_slide(text_date[Gui_sys::INDEX].line_text("这是测试B"));
	text_date[Gui_sys::INDEX].text_slide(text_date[Gui_sys::INDEX].line_text("这是测试C"));
	text_date[Gui_sys::INDEX].text_slide(text_date[Gui_sys::INDEX].line_text("这是测试D"));
	text_date[Gui_sys::INDEX].text_slide(text_date[Gui_sys::INDEX].line_text("这是测试E"));
	text_date[Gui_sys::INDEX].end_slide_text();

	text_date[Gui_sys::INDEX_About].line_text("————版本Ver0.0.5————", 330, 160, size_32, Red, simhei);
	text_date[Gui_sys::INDEX_About].line_text("*本次较上次更新：");
	text_date[Gui_sys::INDEX_About].line_text("*解决了IO响应的问题");
	text_date[Gui_sys::INDEX_About].line_text("**同样新增了一些可知及不可知的bug");
	text_date[Gui_sys::INDEX_About].line_text("——————————————————————————————————", 120);
	text_date[Gui_sys::INDEX_About].line_text("首先谢谢你参与测试！这是测试版本，制作者只有一人，");
	text_date[Gui_sys::INDEX_About].line_text("所有的贴图都不太优良，因此请见谅。");
	text_date[Gui_sys::INDEX_About].line_text("另外，本次更新导致性能下降，尽管较上次能够运行，");
	text_date[Gui_sys::INDEX_About].line_text("但是显然出现了一些问题。");
	text_date[Gui_sys::INDEX_About].line_text("因为一些事没有如期完成，抱歉。");
	text_date[Gui_sys::INDEX_About].line_text("但更新还会继续，敬请期待。");
	text_date[Gui_sys::INDEX_About].line_text("如发现更多的BUG请反馈到作者邮箱445405604@qq.com，或者直接联系作者QQ。");

	text_date[Gui_sys::INDEX_Config].line_text("操作帮助（未完成）", 0, 0, size_32, Red, simhei);

	text_date[Gui_sys::INDEX_StaGame].line_text("测试版本", 1180, 0, size_32, Red, simhei);
	text_date[Gui_sys::INDEX_StaGame].line_text(float_tran_to_char(unit_axis.x), 0, 0);
	text_date[Gui_sys::INDEX_StaGame].line_text(float_tran_to_char(unit_axis.y));

	text_date[Gui_sys::INDEX_StaGames].line_text("测试版本", 1180, 0, size_32, Red, simhei);
	text_date[Gui_sys::INDEX_StaGames].line_text(float_tran_to_char(unit_axis.x), 0, 0);
	text_date[Gui_sys::INDEX_StaGames].line_text(float_tran_to_char(unit_axis.y));
}

void text_sys::get_event_queue(ALLEGRO_EVENT_QUEUE *& event_queue)
{
	this->event_queue = event_queue;
}

void text_sys::get_event(ALLEGRO_EVENT & event)
{
	this->event = &event;
}

void text_sys::get_opertion(player_sys::Player_opertion & opertion)
{
	this->opertion = &opertion;
}

void text_sys::set_axis_date(float x, float y)
{
	unit_axis.x = x;
	unit_axis.y = y;
}

void text_sys::draw_text(int windows_id)
{
	now_draw_win = windows_id;
	now_draw_text = 0;

	for (int i = 0; i < text_date[windows_id].text_num; i++, now_draw_text++)
	{
		if (text_date[windows_id].roll() || text_date[windows_id].slide() || text_date[windows_id].shade());
		else {
			al_draw_text(text_date[windows_id].get_font(), text_date[windows_id].get_color(),
				text_date[windows_id].get_axis().x, text_date[windows_id].get_axis().y, ALLEGRO_ALIGN_LEFT,
				text_date[windows_id].get_content());
		}
	}
}
/**
*滚动文本
*roll_num形参决定滚动的字体数目（字节）
*即每次显示的字体数目
*（最小为6，由于中文一个字符占用3个字节，必须使用3的倍数，不然乱码）
*显示时位置将靠后三位（bug）
*sec为滚动速度
*决定一次滚动需要多长时间
*/
void text_sys::text_roll(int i, int roll_size, double sec)
{
	text[i].roll_text = new Roll_text;

	text[i].roll_text->run = true;
	text[i].roll_text->roll_size = roll_size;
	//从末端开始滚动
	text[i].roll_text->roll_count = 0;
	text[i].roll_text->content_now_pos = 0;
	text[i].roll_text->roll_now_pos = roll_size + 3;
	text[i].roll_text->roll_content = new char[roll_size];
	text[i].roll_text->timer = al_create_timer((sec * 3) / roll_size);
	al_register_event_source(event_queue, al_get_timer_event_source(text[i].roll_text->timer));

	//获取匿名数据及大小
	int ch_size = 0;
	char ch_buffer[64];
	for (int j = 0; j < 64; j++)
	{
		ch_buffer[j] = text[i].content[j];
		if (ch_buffer[j] == '\0')
			break;
		else
			ch_size += 1;
	}

	//获取字符串
	text[i].roll_text->content_size = ch_size;
	text[i].roll_text->content = new char[ch_size];
	for (int j = 0; j < ch_size; j++)
		text[i].roll_text->content[j] = ch_buffer[j];
}
/**
*滑动文本
*style决定滑动的样式
*
*sec决定文本的滑动响应速度
*slide_num决定滑动文本的多少（为单数）
*line_size决定滑动的字体行距/纵距（像素距离）
*smile_text_size决定滑动时缩小的文本的大小
*w，h为触发宽高（不设置时为默认值）
*
*文本的初始化位置和结束位置等
now决定初始位置
*
*run_count运行计数
*/
void text_sys::text_slide(int i, Slide_style style, Spark spark, int slide_num, double sec, double line_size, Size smile_text_size, int w, int h)
{
	text[i].slide_text = new Slide_text;

	if (style != Slide_Def) {
		//初始化
		text[i].slide_text->run = new bool;
		text[i].slide_text->ok = new bool;
		text[i].slide_text->line_size = new double;
		text[i].slide_text->slide_addup = new int;
		text[i].slide_text->slide_num = new int;
		text[i].slide_text->now_text_flg = new int;
		text[i].slide_text->sta_text_flg = new int;
		text[i].slide_text->end_text_flg = new int;
		text[i].slide_text->run_count = new int;
		text[i].slide_text->way = new int;
		text[i].slide_text->on_axis = new Axis;
		text[i].slide_text->to_axis = new Axis;
		text[i].slide_text->refer_to = new Axis;
		text[i].slide_text->style = new Slide_style;
		text[i].slide_text->spark_style = new Spark;
		text[i].slide_text->smile_size = new Size;

		*text[i].slide_text->run = true;
		*text[i].slide_text->run_count = 0;
		*text[i].slide_text->ok = false;//测试中
		*text[i].slide_text->style = style;
		*text[i].slide_text->spark_style = spark;
		*text[i].slide_text->way = 0;
		*text[i].slide_text->slide_num = slide_num;
		text[i].slide_text->smile_font = get_font(text[i].font, smile_text_size);
		text[i].slide_text->timer = al_create_timer(sec);
		al_register_event_source(event_queue, al_get_timer_event_source(text[i].slide_text->timer));
		*text[i].slide_text->line_size = line_size;
		*text[i].slide_text->smile_size = smile_text_size;
		*text[i].slide_text->now_text_flg = i;
		*text[i].slide_text->sta_text_flg = i;
		*text[i].slide_text->end_text_flg = -1;
		text[i].slide_text->refer_to->x = text[i].axis.x;
		text[i].slide_text->refer_to->y = text[i].axis.y;
		*text[i].slide_text->slide_addup = slide_addup;

		//获取文本大小和文字数目
		int size, word_num = 0;
		switch (text[i].size)
		{
		case size_8:
			size = 8;
			break;
		case size_16:
			size = 16;
			break;
		case size_24:
			size = 24;
			break;
		case size_32:
			size = 32;
			break;
		}
		for (int j = 0; j < 64; j++)
		{
			if (text[i].content[j] == '\0')
				break;
			else
				word_num += 1;
		}
		word_num = word_num / 3;

		//设定触发位置
		if (style == lengthways) {//待完善坐标值
			if (w == -1) {
				text[i].slide_text->on_axis->x = text[i].axis.x;
				text[i].slide_text->to_axis->x = text[i].axis.x + (word_num * size);
			}
			else {
				text[i].slide_text->on_axis->x = (text[i].axis.x + size * word_num) - (w / 2);
				text[i].slide_text->to_axis->x = text[i].slide_text->on_axis->x + w;
			}
			if (h == -1) {
				text[i].slide_text->on_axis->y = text[i].axis.y - line_size - smile_text_size;
				text[i].slide_text->to_axis->y = text[i].axis.y + size + line_size;
			}
			else {
				text[i].slide_text->on_axis->y = text[i].axis.y + h - size;
				text[i].slide_text->to_axis->y = text[i].axis.y - size;
			}
		}
		else {
			if (w == -1) {
				text[i].slide_text->on_axis->x = text[i].axis.x;
				text[i].slide_text->to_axis->x = text[i].axis.x + 300;
			}
			else {
				text[i].slide_text->on_axis->x = (text[i].axis.x + size * word_num) - (w / 2);
				text[i].slide_text->to_axis->x = text[i].slide_text->on_axis->x + w;
			}
			if (h == -1) {
				text[i].slide_text->on_axis->y = text[i].axis.y - 250;
				text[i].slide_text->to_axis->y = text[i].axis.y + 250;
			}
			else {
				text[i].slide_text->on_axis->y = text[i].axis.y + h - size;
				text[i].slide_text->to_axis->y = text[i].axis.y - size;
			}
		}

		after_slide = *text[i].slide_text;
	}
	else
		*text[i].slide_text = after_slide;
}

void text_sys::start_slide_text(int s_num)
{
	if (slide_flg != nullptr) {
		delete[] slide_flg;
		slide_flg = nullptr;
	}
	slide_flg = new int[s_num];
	slide_addup = s_num;

	if (text_num != 0)
		slide_flg[0] = text_num;
	else
		slide_flg[0] = 0;
}

void text_sys::end_slide_text()
{
	slide_addup = 0;
	*text[text_num - 1].slide_text->end_text_flg = text_num - 1;
}
/**
*渐变文本
*style决定滑动的样式
*sec决定渐变需要的时间
*/
void text_sys::text_shade(int i, Shade_style style, double sec)
{
	text[i].shade_text = new Shade_text;
}

bool text_sys::roll()//待修复bug
{
	if (text[now_draw_text].roll_text == nullptr)
		return false;
	//保持文本显示
	else if (!text[now_draw_text].roll_text->run) {
		al_draw_text(get_font(), get_color(),
			get_axis().x, get_axis().y, ALLEGRO_ALIGN_LEFT,
			text[now_draw_text].roll_text->roll_content);
	}
	else {
		text[now_draw_text].roll_text->run = false;
		text[now_draw_text].roll_text->roll_count += 3;
		//初始化滚动内容
		for (int i = 0; i < text[now_draw_text].roll_text->roll_size; i++)
			text[now_draw_text].roll_text->roll_content[i] = ' ';

		//复位
		if (text[now_draw_text].roll_text->roll_now_pos == 0
			&& text[now_draw_text].roll_text->content_now_pos == text[now_draw_text].roll_text->content_size - 3) {
			text[now_draw_text].roll_text->roll_now_pos = text[now_draw_text].roll_text->roll_size + 3;
			text[now_draw_text].roll_text->roll_count = 0;
		}
		else if (text[now_draw_text].roll_text->roll_now_pos > 0)
			text[now_draw_text].roll_text->roll_now_pos -= 3;
		if (text[now_draw_text].roll_text->content_now_pos == text[now_draw_text].roll_text->content_size - 3)
			text[now_draw_text].roll_text->content_now_pos = 0;
		else if (text[now_draw_text].roll_text->roll_now_pos < text[now_draw_text].roll_text->roll_size - 3
			&& text[now_draw_text].roll_text->roll_count > text[now_draw_text].roll_text->roll_size + 3)
			text[now_draw_text].roll_text->content_now_pos += 3;

		//填充滚动内容
		if (text[now_draw_text].roll_text->roll_now_pos < text[now_draw_text].roll_text->roll_size) {
			int size = text[now_draw_text].roll_text->roll_size - text[now_draw_text].roll_text->roll_now_pos;
			for (int i = 0; i < size; i++)
				text[now_draw_text].roll_text->roll_content[text[now_draw_text].roll_text->roll_now_pos + i]
				= text[now_draw_text].roll_text->content[text[now_draw_text].roll_text->content_now_pos + i];
		}

		//绘制文本
		al_draw_text(get_font(), get_color(),
			get_axis().x, get_axis().y, ALLEGRO_ALIGN_LEFT,
			text[now_draw_text].roll_text->roll_content);
	}
	return true;
}

bool text_sys::slide()//待完善
{
	static bool move = false;
	static bool run_one = false;

	if (text[now_draw_text].slide_text == nullptr)
		return false;
	//先尝试移动文本
	if (move) {
		static bool up;
		static int x, y, pos;
		static int size = *text[now_draw_text].slide_text->slide_num - 1;

		if (*text[now_draw_text].slide_text->way > 0)
			//往上移动
			up = true;
		else if(*text[now_draw_text].slide_text->way < 0)
			//往下移动
			up = false;

		for (int i = 0; i < size; i++)
		{
			if (*text[now_draw_text].slide_text->style == lengthways) {
				if (up) {
					x = text[now_draw_text].slide_text->refer_to->x;
					y = text[now_draw_text].slide_text->refer_to->y + *text[now_draw_text].slide_text->line_size / 2.0;
					pos = *text[now_draw_text].slide_text->now_text_flg - i;
				}
				else {
					x = text[now_draw_text].slide_text->refer_to->x;
					y = text[now_draw_text].slide_text->refer_to->y - *text[now_draw_text].slide_text->line_size / 2.0;
					pos = *text[now_draw_text].slide_text->now_text_flg + i;
				}
			}
			else {
				if (up) {
					x = text[now_draw_text].slide_text->refer_to->x;
					y = text[now_draw_text].slide_text->refer_to->x + *text[now_draw_text].slide_text->line_size;
					pos = *text[now_draw_text].slide_text->now_text_flg - i;
				}
				else {
					x = text[now_draw_text].slide_text->refer_to->x;
					y = text[now_draw_text].slide_text->refer_to->x + *text[now_draw_text].slide_text->line_size;
					pos = *text[now_draw_text].slide_text->now_text_flg - i;
				}
			}
			if (pos < *text[now_draw_text].slide_text->sta_text_flg ||
				pos > *text[now_draw_text].slide_text->end_text_flg)
				break;
			//绘制
			al_draw_text(get_font(), get_color(), x, y, ALLEGRO_ALIGN_LEFT, text[pos].content);
		}
	}
	//判断是否符合操作要求
	if (slide_spark()) {
		if (*text[now_draw_text].slide_text->spark_style == Mouse_axis) {
			if (opertion->mouse.dz > 0) {
				*text[now_draw_text].slide_text->now_text_flg -= 1;
				*text[now_draw_text].slide_text->way = 1;
				move = true;
			}
			else if (opertion->mouse.dz < 0) {
				*text[now_draw_text].slide_text->now_text_flg += 1;
				*text[now_draw_text].slide_text->way = -1;
				move = true;
			}
		}
		else if (*text[now_draw_text].slide_text->spark_style == Key_button) {
			static int after_text;
			after_text = *text[now_draw_text].slide_text->now_text_flg;

			if (opertion->keybords.key_1) {
				move = true;
				*text[now_draw_text].slide_text->ok = true;
				*text[now_draw_text].slide_text->now_text_flg = *text[now_draw_text].slide_text->sta_text_flg;
			}
			else if (opertion->keybords.key_2
				&& *text[now_draw_text].slide_text->end_text_flg >= *text[now_draw_text].slide_text->sta_text_flg + 1) {
				move = true;
				*text[now_draw_text].slide_text->ok = true;
				*text[now_draw_text].slide_text->now_text_flg = *text[now_draw_text].slide_text->sta_text_flg + 1;
			}
			else if (opertion->keybords.key_3
				&& *text[now_draw_text].slide_text->end_text_flg >= *text[now_draw_text].slide_text->sta_text_flg + 2) {
				move = true;
				*text[now_draw_text].slide_text->ok = true;
				*text[now_draw_text].slide_text->now_text_flg = *text[now_draw_text].slide_text->sta_text_flg + 2;
			}
			else if (opertion->keybords.key_4
				&& *text[now_draw_text].slide_text->end_text_flg >= *text[now_draw_text].slide_text->sta_text_flg + 3) {
				move = true;
				*text[now_draw_text].slide_text->ok = true;
				*text[now_draw_text].slide_text->now_text_flg = *text[now_draw_text].slide_text->sta_text_flg + 3;
			}
			else if (opertion->keybords.key_5
				&& *text[now_draw_text].slide_text->end_text_flg >= *text[now_draw_text].slide_text->sta_text_flg + 4) {
				move = true;
				*text[now_draw_text].slide_text->ok = true;
				*text[now_draw_text].slide_text->now_text_flg = *text[now_draw_text].slide_text->sta_text_flg + 4;
			}

			if (*text[now_draw_text].slide_text->now_text_flg > after_text)
				*text[now_draw_text].slide_text->way = 1;
			else if (*text[now_draw_text].slide_text->now_text_flg < after_text)
				*text[now_draw_text].slide_text->way = -1;
		}
	}
	//操作符合条件
	else if (*text[now_draw_text].slide_text->run && *text[now_draw_text].slide_text->ok) {
		*text[now_draw_text].slide_text->run = false;
		*text[now_draw_text].slide_text->run_count += 1;

		if (*text[now_draw_text].slide_text->run_count == 2) {
			*text[now_draw_text].slide_text->ok = false;
			*text[now_draw_text].slide_text->run_count = 0;
			*text[now_draw_text].slide_text->way = 0;
			move = false;
		}
	}
	//保持文本显示
	else {
		run_one = true;
		static int x, y, font_size, s_font_size, pos;
		static int size = (*text[now_draw_text].slide_text->slide_num - 1) / 2;
		static bool left, right;
		left = right = false;

		switch (text[now_draw_text].size)
		{
		case text_sys::size_8:
			font_size = 8;
			break;
		case text_sys::size_16:
			font_size = 16;
			break;
		case text_sys::size_24:
			font_size = 24;
			break;
		case text_sys::size_32:
			font_size = 32;
			break;
		}
		switch (*text[now_draw_text].slide_text->smile_size)
		{
		case text_sys::size_8:
			s_font_size = 8;
			break;
		case text_sys::size_16:
			s_font_size = 16;
			break;
		case text_sys::size_24:
			s_font_size = 24;
			break;
		case text_sys::size_32:
			s_font_size = 32;
			break;
		}

		//参考点绘制
		al_draw_text(get_font(), get_color(),
			text[now_draw_text].slide_text->refer_to->x,
			text[now_draw_text].slide_text->refer_to->y,
			ALLEGRO_ALIGN_LEFT,
			text[*text[now_draw_text].slide_text->now_text_flg].content);

		//只绘制参考点下端（右端）
		if (*text[now_draw_text].slide_text->now_text_flg == *text[now_draw_text].slide_text->sta_text_flg)
			left = true;
		//只绘制参考点上端（左端）
		else if (*text[now_draw_text].slide_text->now_text_flg == *text[now_draw_text].slide_text->end_text_flg)
			right = true;
		//参考点上下（左右）端都绘制
		else
			left = right = true;

		if (left) {
			if (*text[now_draw_text].slide_text->style == lengthways) {
				x = text[now_draw_text].slide_text->refer_to->x;
				y = text[now_draw_text].slide_text->refer_to->y + *text[now_draw_text].slide_text->line_size + font_size;
			}
			else {
				x = text[now_draw_text].slide_text->refer_to->x + *text[now_draw_text].slide_text->line_size;
				y = text[now_draw_text].slide_text->refer_to->y;
			}
			for (int i = 0; i < size; i++)
			{
				pos = *text[now_draw_text].slide_text->now_text_flg + 1 + i;
				if (pos > *text[now_draw_text].slide_text->end_text_flg)
					break;
				al_draw_text(text[now_draw_text].slide_text->smile_font, get_color(), 
					x, y, ALLEGRO_ALIGN_LEFT,
					text[pos].content);
				if (*text[now_draw_text].slide_text->style == lengthways)
					y += (*text[now_draw_text].slide_text->line_size + s_font_size);
				else
					x += *text[now_draw_text].slide_text->line_size;
			}
		}
		if (right) {
			if (*text[now_draw_text].slide_text->style == lengthways) {
				x = text[now_draw_text].slide_text->refer_to->x;
				y = text[now_draw_text].slide_text->refer_to->y - *text[now_draw_text].slide_text->line_size - font_size;
			}
			else {
				x = text[now_draw_text].slide_text->refer_to->x - *text[now_draw_text].slide_text->line_size;
				y = text[now_draw_text].slide_text->refer_to->y;
			}
			for (int i = 0; i < size; i++)
			{
				pos = *text[now_draw_text].slide_text->now_text_flg - 1 - i;
				if (pos < *text[now_draw_text].slide_text->sta_text_flg)
					break;
				al_draw_text(text[now_draw_text].slide_text->smile_font, get_color(), 
					x, y, ALLEGRO_ALIGN_LEFT,
					text[pos].content);

				if (*text[now_draw_text].slide_text->style == lengthways)
					y -= (*text[now_draw_text].slide_text->line_size + s_font_size);
				else
					x -= *text[now_draw_text].slide_text->line_size;
			}
		}
	}
	return true;
}

bool text_sys::slide_spark()
{
	switch (*text[now_draw_text].slide_text->spark_style)
	{
		//使用鼠标滑轮
	case Mouse_axis:
		if (opertion->mouse.x >= text[now_draw_text].slide_text->on_axis->x
			&& opertion->mouse.x <= text[now_draw_text].slide_text->to_axis->x
			&& opertion->mouse.y >= text[now_draw_text].slide_text->on_axis->y
			&& opertion->mouse.y <= text[now_draw_text].slide_text->to_axis->y
			&& opertion->mouse.left
			&& !*text[now_draw_text].slide_text->ok)
			return true;
		break;
		//使用键盘
	case Key_button:
		if ((opertion->keybords.key_1 ||
			opertion->keybords.key_2 ||
			opertion->keybords.key_3 ||
			opertion->keybords.key_4 ||
			opertion->keybords.key_5)
			&& !*text[now_draw_text].slide_text->ok)
			return true;
		break;
	}
	return false;
}

bool text_sys::shade()
{
	return false;
}

int text_sys::line_text(char * content, int x, int y, Size size, Color color, Font font)
{
	int after_size;
	//自动化分配结构体内存
	stor_allocation();

	text[text_num - 1].roll_text = nullptr;
	text[text_num - 1].slide_text = nullptr;
	text[text_num - 1].shade_text = nullptr;
	text[text_num - 1].content = content;

	//转换字体大小
	switch (after_text.size)
	{
	case text_sys::size_8:
		after_size = 8;
		break;
	case text_sys::size_16:
		after_size = 16;
		break;
	case text_sys::size_24:
		after_size = 24;
		break;
	case text_sys::size_32:
		after_size = 32;
		break;
	}
	//xy值均根据上一行变化
	if (y == -1 && x == -1) {
		text[text_num - 1].axis.x = after_text.axis.x;
		text[text_num - 1].axis.y = after_text.axis.y + after_size;
	}
	//y值根据上一行变化，x值根据设置值
	else if (y == -1) {
		text[text_num - 1].axis.x = x;
		text[text_num - 1].axis.y = after_text.axis.y + after_size;
	}
	//根据设置值
	else {
		text[text_num - 1].axis.x = x;
		text[text_num - 1].axis.y = y;
	}
	//如果字体有被设置
	if (size != Siz_Def)
		text[text_num - 1].size = size;
	else
		text[text_num - 1].size = after_text.size;
	//如果颜色有被设置
	if (color != Col_Def)
		text[text_num - 1].color = color;
	//否则颜色为上一个字体的颜色
	else
		text[text_num - 1].color = after_text.color;
	//如果字体有被设置
	if (font != msyh)
		text[text_num - 1].font = font;
	else
		text[text_num - 1].font = after_text.font;

	after_text = text[text_num - 1];

	return (text_num - 1);
}

void text_sys::modfiy_content(Text & text, char * content)
{
//	strcpy(text.content, content);
}

void text_sys::modfiy_axis(Text & text, int x, int y)
{
	text.axis.x = x;
	text.axis.y = y;
}

void text_sys::modfiy_color(Text & text, Color color)
{
	text.color = color;
}

void text_sys::modfiy_size(Text & text, Size size)
{
	text.size = size;
}

void text_sys::modfiy_font(Text & text, Font font)
{
	text.font = font;
}

ALLEGRO_COLOR text_sys::get_color()
{
	switch (text[now_draw_text].color)
	{
	case text_sys::Col_Def:
		return al_map_rgb(0, 0, 0);
	case text_sys::Black:
		return al_map_rgb(0, 0, 0);
	case text_sys::White:
		return al_map_rgb(255, 255, 255);
	case text_sys::Red:
		return al_map_rgb(220, 20, 60);
	case text_sys::Yellow:
		return al_map_rgb(255, 255, 0);
	case text_sys::Blue:
		return al_map_rgb(30, 144, 255);
	case text_sys::Green:
		return al_map_rgb(0, 255, 0);
	case text_sys::Young:
		return al_map_rgb(0, 255, 255);
	case text_sys::Orange:
		return al_map_rgb(255, 215, 0);
	}
	return al_map_rgb(0, 0, 0);
}

ALLEGRO_FONT * text_sys::get_font(Font font, Size size)
{
	static char * msyh = "font/msyh.ttc";
	static char * simhei = "font/simhei.ttf";

	static ALLEGRO_FONT * msyh_8 = al_load_ttf_font(msyh, 8, 0);
	static ALLEGRO_FONT * msyh_16 = al_load_ttf_font(msyh, 16, 0);
	static ALLEGRO_FONT * msyh_24 = al_load_ttf_font(msyh, 24, 0);
	static ALLEGRO_FONT * msyh_32 = al_load_ttf_font(msyh, 32, 0);

	static ALLEGRO_FONT * simhei_8 = al_load_ttf_font(simhei, 8, 0);
	static ALLEGRO_FONT * simhei_16 = al_load_ttf_font(simhei, 16, 0);
	static ALLEGRO_FONT * simhei_24 = al_load_ttf_font(simhei, 24, 0);
	static ALLEGRO_FONT * simhei_32 = al_load_ttf_font(simhei, 32, 0);

	static int sizes;
	static Font font_style;
	static ALLEGRO_FONT * fonts = nullptr;

	if (font != Font::msyh)
		font_style = font;
	else
		font_style = text[now_draw_text].font;
	if (size != Size::Siz_Def)
		sizes = size;
	else
		sizes = text[now_draw_text].size;

	switch (font_style)
	{
	case text_sys::msyh:
		switch (sizes)
		{
		case Size::size_8:
			fonts = msyh_8;
			break;
		case Size::size_16:
			fonts = msyh_16;
			break;
		case Size::size_24:
			fonts = msyh_24;
			break;
		case Size::size_32:
			fonts = msyh_32;
			break;
		}
		break;
	case text_sys::simhei:
		switch (sizes)
		{
		case Size::size_8:
			fonts = simhei_8;
			break;
		case Size::size_16:
			fonts = simhei_16;
			break;
		case Size::size_24:
			fonts = simhei_24;
			break;
		case Size::size_32:
			fonts = simhei_32;
			break;
		}
		break;
	}
	return fonts;
}

char * text_sys::get_content()
{
	return text[now_draw_text].content;
}

text_sys::Axis text_sys::get_axis()
{
	return text[now_draw_text].axis;
}

void text_sys::stor_allocation()
{
	if (text_num != 0) {
		//创建临时对象存储旧数据
		auto text_buffer = new Text[text_num];
		for (int i = 0; i < text_num; i++)
			text_buffer[i] = text[i];
		delete[] text;
		text = nullptr;
		text_num += 1;
		//将旧数据存储至新数据中
		text = new Text[text_num];
		for (int i = 0; i < text_num - 1; i++)
			text[i] = text_buffer[i];
		delete[] text_buffer;
		text_buffer = nullptr;
	}
	else {
		text_num += 1;
		text = new Text[text_num];
	}
}

void text_sys::res_text()
{
	for (int i = 0; i < text_date[now_draw_win].text_num; i++)
	{
		if (text_date[now_draw_win].text[i].roll_text) {
			for (int k = 0; k < text_date[now_draw_win].text[i].roll_text->roll_size; k++)
				text_date[now_draw_win].text[i].roll_text->roll_content[k] = ' ';
			text_date[now_draw_win].text[i].roll_text->roll_now_pos = text_date[now_draw_win].text[i].roll_text->roll_size + 3;
			text_date[now_draw_win].text[i].roll_text->roll_count = 0;
			text_date[now_draw_win].text[i].roll_text->content_now_pos = 0;
		}
		else if (text_date[now_draw_win].text[i].slide_text)
			text_date[now_draw_win].text[i].slide_text;
		else if (text_date[now_draw_win].text[i].shade_text)
			text_date[now_draw_win].text[i].shade_text;
	}
}

void text_sys::start_text_timer(int windows_id)
{
	for (int i = 0; i < text_date[windows_id].text_num; i++)
	{
		if (text_date[windows_id].text[i].roll_text)
			al_start_timer(text_date[windows_id].text[i].roll_text->timer);
		else if (text_date[windows_id].text[i].slide_text)
			al_start_timer(text_date[windows_id].text[i].slide_text->timer);
		else if (text_date[windows_id].text[i].shade_text)
			al_start_timer(text_date[windows_id].text[i].shade_text->timer);
	}
}

void text_sys::run_text_timer()
{
	for (int i = 0; i < text_date[now_draw_win].text_num; i++)
	{
		if (text_date[now_draw_win].text[i].roll_text) {
			if (text_date[now_draw_win].text[i].roll_text->timer == event->timer.source) {
				text_date[now_draw_win].text[i].roll_text->run = true;
				break;
			}
		}
		else if (text_date[now_draw_win].text[i].slide_text) {
			if (text_date[now_draw_win].text[i].slide_text->timer == event->timer.source) {
				*text_date[now_draw_win].text[i].slide_text->run = true;
				break;
			}
		}
		else if (text_date[now_draw_win].text[i].shade_text) {
			if (text_date[now_draw_win].text[i].shade_text->timer == event->timer.source) {
				text_date[now_draw_win].text[i].shade_text->run = true;
				break;
			}
		}
	}
}

void text_sys::stop_text_timer(int windows_id)
{
	for (int i = 0; i < text_date[windows_id].text_num; i++)
	{
		if (text_date[now_draw_win].text[i].roll_text)
			al_stop_timer(text_date[windows_id].text[i].roll_text->timer);
		else if (text_date[now_draw_win].text[i].slide_text)
			al_stop_timer(text_date[windows_id].text[i].slide_text->timer);
		else if (text_date[now_draw_win].text[i].shade_text)
			al_stop_timer(text_date[windows_id].text[i].shade_text->timer);
	}
}

﻿#ifndef animation_sys_
#define animation_sys_

#include<string>
#include"allegro5\allegro.h"
#include"allegro5\allegro_image.h"
#include"animation_elem.h"
#include"set_bitmap.h"
#include"state_transition_elem.h"
#include"timer_sys.h"
#include"animation.h"
#include"timer_sys.h"
//通用的动画类，请将需要动画渲染的类共有继承该类
//通过获取结构数据载入队列
//通过队列读取需要的数据
//需要配合state_transition类作为逻辑与动画的交互媒介
//动画类
class animation_sys :public animation_elem, protected set_bitmap
{
public:
	animation_sys();
	~animation_sys();

	//获取对象
	animation_elem * get_object(Animation_elem_flags flg);
	//更改重设情况（将反转设定标记）
	void flip_reset();
	//获取事件队列
	void get_event_queue(ALLEGRO_EVENT_QUEUE *& event_queue);
	//获取事件
	void get_event(ALLEGRO_EVENT & ev);
	//初始化动画绘制队列
	void init_animation_draw_elem(Animation_elem_flags flg, int e_num);
	//更新gui动画
	void update_gui_animation();
	//更新动画数据
	void update_animation_date(Animation_elem_flags flg, state_transition_elem::Tran_id_plus * t_id);
	//修改绘制对象更新速度
	void update_animation_timer(Animation_elem_flags flg);
	//绘制对象
	void animation_draw_object(Animation_elem_flags flg);
	//清除对象表
	void clean_animation_elem_object(Animation_elem_flags flg);
	//动画动作锁
	bool lock_animation_action_state(Animation_elem_flags flg);
	//控制动画计时器
	void start_animation_timer(Animation_elem_flags flg);
	//运行动画计时器
	bool run_animation_timer(Animation_elem_flags flg);
	//停止动画计时器
	void stop_animation_timer(Animation_elem_flags flg);
	//获取线性链表
	Animation_elem *& get_elem(Animation_elem_flags flg);
	//由于不存在任何动作，则清除所有的操作标记
	void clean_tran_id();

protected:
	static ALLEGRO_EVENT * event;//事件
	static ALLEGRO_EVENT_QUEUE * event_queue;//事件队列

	//动画锁
	bool lock_animation_action_state(Animation_elem * head);
	//设定可操作动画对象数目
	void set_op_obj_num(int obj_num);

private:
	bool reset;//重新设定标记

	int obj_num;
	Animation draw_object;//渲染中的临时对象
	state_transition_elem::Tran_id * tran_id;//临时状态id（与对象成正比）
	int tran_id_num;//操作数目
	int sta_timer;//启动的计时器

	static Animation * sorter[5];//排序器
	static int sorter_num[5];//排序器大小

	static animation_elem Ui_draw_elem;//ui绘制队列
	static animation_elem MapContext_draw_elem;//map背景绘制队列
	static animation_elem MapUnit_draw_elem;//map单元绘制队列
	static animation_elem PlayerSpriti_darw_elem;//玩家精灵绘制队列
	static animation_elem AiSpriti_draw_elem;//电脑精灵绘制队列

	//启动动画排序器
	void Animation_sorter(Animation_elem_flags flg);
	//释放动画排序器
	void Del_sorter();
	//获取排序器对象
	void Get_sorter(int pos, Animation & obj, Animation_elem_flags flg);
	//获取排序器大小
	int get_sorter_num(Animation_elem_flags flg);

	//更新动画更新逻辑
	void update_animation_logic(Animation_elem_flags flg, Bmp_date & obj);

};

#endif //!animation_sys_
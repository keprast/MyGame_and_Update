﻿#ifndef vector_
#define vector_

#include<cmath>

template<typename T1, typename T2>
class vector
{
public:
	//向量结构
	struct Vector
	{
		T1 x[2], y[2];//向量起始坐标
		T1 len;//向量长度
		T2 angle;//角度
		T2 arc;//弧度
	};

	//计算向量的弧度值还是角度值
	enum vector_flags
	{
		Angle,
		Arc
	};
	const double pi = 3.14159265358979323846;//π
	
	//默认初始化（构造一条起点为原点，长度为1，角度为0的单位向量）
	vector();
	//构造一条自定义向量
	vector(T1 x1, T1 y1, T1 l, T2 ang, T2 this_is_flags);
	vector(T1 x1, T1 y1, T1 x2, T1 y2);
	~vector();

	void set_vector_angle(T2 ang);
	void set_vector_arc(T2 ar);
	//设定向量的数据
	void set_vector(Vector<T1, T2> ve);

	void get_vector_x1(T1 & x1);
	void get_vector_y1(T1 & y1);
	void get_vector_zero(T1 & x1, T1 & y1);
	void get_vector_end(T1 & x2, T1 & y2);
	void get_vector_angle(T2 & ang);
	void get_vector_arc(T2 & ar);
	void get_vector_len(T1 & l);
	//获得向量的角度或弧度
	T2 get_vector_degree(T1 x1, T1 y1, T1 x2, T1 y2, vector_flags flg) const;
	//获得向量的终点
	void get_vector_end(T1 x1, T1 y1, T1 l, T2 a, T1 & x2, T1 & y2) const;
	//获得向量的长度
	T1 get_vector_len(T1 x1, T1 y1, T1 x2, T1 y2) const;
	//获得向量的数据
	vector<T1, T2> get_vector();
	//获得加长向量后的终点坐标
	void get_vector_add_len_end(T1 add_l, T1 & x2, T1 & y2);
	//获得减短向量后的终点坐标
	void get_vector_reduce_len_end(T1 re_l, T1 & x2, T1 & y2);
	//获得两向量的弧度夹角
	T2 get_vector_lnc_arc(vector<T1, T2> & v1, vector<T1, T2> & v2) const;
	//获得向量的弧度
	T2 get_vector_arc(T1 x1, T1 y1, T1 x2, T1 y2) const;
	//获得向量的角度
	T2 get_vector_angle(T1 x1, T1 y1, T1 x2, T1 y2) const;
	//获得相加的两条向量
	vector<T1, T2> operator+(vector<T1, T2> & vect);
	//获得相减的两条向量
	vector<T1, T2> operator-(vector<T1, T2> & vect);
	//获得另一条向量
	void operator=(vector<T1, T2> & vect);

private:
	Vector<T1, T2> vec;//向量数据

};

#endif

template<typename T1, typename T2>
inline vector<T1, T2>::vector()
{
	vec.x[0] = vec.y[0] = vec.y[1] = 0;
	vec.x[1] = 1;
	vec.len = 1;
	vec.angle = vec.arc = 0;
}

template<typename T1, typename T2>
inline vector<T1, T2>::vector(T1 x1, T1 y1, T1 l, T2 ang, T2 this_is_flags)
{
	vec.x[0] = x1;
	vec.y[0] = y1;
	vec.len = l;
	vec.angle = ang;
	vec.x[1] = l*cos(ang * pi / 180);
	vec.y[1] = l*sin(ang * pi / 180);
}

template<typename T1, typename T2>
inline vector<T1, T2>::vector(T1 x1, T1 y1, T1 x2, T1 y2)
{
	vec.x[0] = x1;
	vec.y[0] = y1;
	vec.x[1] = x2;
	vec.y[1] = y2;
	vec.len = pow((pow(fabs(x2 - x1), 2) + pow(fabs(y2 - y1), 2)), 0.5);
	if ((x2 - x1) == 0) {
		if (y2 > y1) {
			vec.arc = pi / 2;
			vec.angle = 90;
		}
		else 
		{
			vec.arc = -pi / 2;
			vec.angle = -90;
		}
	}
	else
	{
		vec.arc = atan2(y2 - y1, x2 - x1);
		vec.angle = 180 / (vec.arc * pi);
	}
}

template<typename T1, typename T2>
inline vector<T1, T2>::~vector()
{
	
}

template<typename T1, typename T2>
inline void vector<T1, T2>::set_vector_angle(T2 ang)
{
	vec.angle = ang;
	vec.arc = ang * pi / 180;
	vec.x[1] = vec.x[0] + vec.len*cos(vec.arc);
	vec.y[1] = vec.y[0] + vec.len*sin(vec.arc);
}

template<typename T1, typename T2>
inline void vector<T1, T2>::set_vector_arc(T2 ar)
{
	vec.arc = ar;
	vec.angle = 180 / (pi * 2 * ar);
	vec.x[1] = vec.x[0] + vec.len*cos(vec.arc);
	vec.y[1] = vec.y[0] + vec.len*sin(vec.arc);
}

template<typename T1, typename T2>
inline void vector<T1, T2>::set_vector(Vector<T1,T2> ve)
{
	ve = vec;
}

template<typename T1, typename T2>
inline void vector<T1, T2>::get_vector_x1(T1 & x1)
{
	x1 = vec.x[0];
}

template<typename T1, typename T2>
inline void vector<T1, T2>::get_vector_y1(T1 & y1)
{
	y1 = vec.y[0];
}

template<typename T1, typename T2>
inline void vector<T1, T2>::get_vector_zero(T1 & x1, T1 & y1)
{
	x1 = vec.x[0];
	y1 = vec.y[0];
}

template<typename T1, typename T2>
inline void vector<T1, T2>::get_vector_end(T1 & x2, T1 & y2)
{
	x2 = vec.x[1];
	y2 = vec.y[1];
}

template<typename T1, typename T2>
inline void vector<T1, T2>::get_vector_angle(T2 & ang)
{
	ang = vec.angle;
}

template<typename T1, typename T2>
inline void vector<T1, T2>::get_vector_arc(T2 & ar)
{
	ar = vec.arc;
}

template<typename T1, typename T2>
inline void vector<T1, T2>::get_vector_len(T1 & l)
{
	l = vec.len;
}

template<typename T1, typename T2>
inline T2 vector<T1, T2>::get_vector_degree(T1 x1, T1 y1, T1 x2, T1 y2, vector_flags flg) const
{
	T2 a = get_vector_arc(x1, y1, x2, y2);
	if (flg == Angle)return 180 / (pi  * a);
	else return a;
}

template<typename T1, typename T2>
inline void vector<T1, T2>::get_vector_end(T1 x1, T1 y1, T1 l, T2 a, T1 & x2, T1 & y2) const
{
	x2 = x1 + l*cos(a);
	y2 = y1 + l*sin(a);
}

template<typename T1, typename T2>
inline T1 vector<T1, T2>::get_vector_len(T1 x1, T1 y1, T1 x2, T1 y2) const
{
	return pow((pow(fabs(x2 - x1), 2) + pow(fabs(y2 - y1), 2)), 0.5);
}

template<typename T1, typename T2>
inline vector<T1, T2> vector<T1, T2>::get_vector()
{
	return *this;
}

template<typename T1, typename T2>
inline void vector<T1, T2>::get_vector_add_len_end(T1 add_l, T1 & x2, T1 & y2)
{
	vec.len += add_l;
	vec.x[1] += vec.len*cos(vec.arc * pi / 180);
	vec.y[1] += vec.len*sin(vec.arc * pi / 180);
	x2 = vec.x[1];
	y2 = vec.y[1];
}

template<typename T1, typename T2>
inline void vector<T1, T2>::get_vector_reduce_len_end(T1 re_l, T1 & x2, T1 & y2)
{
	vec.len -= re_l;
	vec.x[1] -= vec.len*cos(vec.arc * pi / 180);
	vec.y[1] -= vec.len*sin(vec.arc * pi / 180);
	x2 = vec.x[1];
	y2 = vec.y[1];
}

template<typename T1, typename T2>
inline T2 vector<T1, T2>::get_vector_lnc_arc(vector<T1, T2>& v1, vector<T1, T2>& v2) const
{
	T2 arc, arc1, arc2;
	T1 x0[2], y0[2], x1[2], y1[2], x2[2], y2[2];

	v1.get_vector_zero(x1[0], y1[0]);
	v1.get_vector_end(x2[0], y2[0]);
	v2.get_vector_zero(x1[1], y1[1]);
	v2.get_vector_end(x2[1], y2[1]);
	v1.get_vector_arc(arc1);
	v2.get_vector_arc(arc2);
	for (int i = 0; i < 2; i++)
	{
		x0[i] = x2[i] - x1[i];
		y0[i] = y2[i] - y1[i];
	}
	arc = acos((x0[0] * x0[1] + y0[0] * y0[1]) /
		(pow(pow(x0[0] * x0[0], 2) + pow(y0[0] * y0[0], 2), 0.5)*pow(pow(x0[1] * x0[1], 2) + pow(y0[1] * y0[1], 2), 0.5)));
	while (arc > 2 * pi)arc -= 2 * pi;
	while (arc < -2 * pi)arc += 2 * pi;
	if (arc > pi)arc -= pi;
	else if (arc < -pi)arc += pi;
	else if (arc == 0 && arc1 != arc2)arc = pi / 2;

	return arc;
}

template<typename T1, typename T2>
inline T2 vector<T1, T2>::get_vector_arc(T1 x1, T1 y1, T1 x2, T1 y2) const
{
	T2 arc;
	if ((x2 - x1) == 0) {
		if (y2 > y1)arc = pi / 2;
		else arc = -pi / 2;
	}
	else arc = atan2(y2 - y1, x2 - x1);
	return arc;
}

template<typename T1, typename T2>
inline T2 vector<T1, T2>::get_vector_angle(T1 x1, T1 y1, T1 x2, T1 y2) const
{
	T2 angle;
	if ((x2 - x1) == 0) {
		if (y2>y1)angle = 90;
		else angle = -90;
	}
	else angle = 180 / (pi*atan2(y2 - y1, x2 - x1));
	return angle;
}

template<typename T1,typename T2>
inline vector<T1, T2> vector<T1, T2>::operator+(vector<T1, T2>& vect)
{
	T1 l2;
	T1 x2, y2;
	T2 arc2;
	vector<T1, T2> v;

	get_vector_end(x2, y2);
	vect.get_vector_arc(arc2);
	vect.get_vector_len(l2);
	vect.get_vector_end(x2, y2, l2, arc2, x2, y2);
	v.vec.x[0] = vec.x[0];//起点
	v.vec.y[0] = vec.y[0];
	v.vec.x[1] = x2;//终点
	v.vec.y[1] = y2;
	v.vec.len = get_vector_len(v.vec.x[0], v.vec.y[0], v.vec.x[1], v.vec.y[1]);//长度
	v.vec.arc = get_vector_arc(v.vec.x[0], v.vec.y[0], v.vec.x[1], v.vec.y[1]);//弧度
	if (v.vec.arc >= 1.56 && v.vec.arc <= 1.58)v.vec.angle = 90;
	else if (v.vec.arc <= -1.56 && v.vec.arc >= -1.58)v.vec.angle = -90;
	else v.vec.angle = 180 / (pi*v.vec.arc);

	return v;
}

template<typename T1, typename T2>
inline vector<T1, T2> vector<T1, T2>::operator-(vector<T1, T2>& vect)
{
	T1 l2;
	T1 x2, y2;
	T2 arc;
	vector<T1, T2> v;

	get_vector_end(x2, y2);
	vect.get_vector_arc(arc);
	vect.get_vector_len(l2);
	vect.get_vector_end(x2, y2, l2, pi + arc, x2, y2);
	v.vec.x[0] = vec.x[0];//起点
	v.vec.y[0] = vec.y[0];
	v.vec.x[1] = x2;//终点
	v.vec.y[1] = y2;
	v.vec.len = v.get_vector_len(v.vec.x[0], v.vec.y[0], v.vec.x[1], v.vec.y[1]);//长度
	v.vec.arc = v.get_vector_arc(v.vec.x[0], v.vec.y[0], v.vec.x[1], v.vec.y[1]);//弧度
	if (v.vec.arc >= 1.56 && v.vec.arc <= 1.58)v.vec.angle = 90;
	else if (v.vec.arc <= -1.56 && v.vec.arc >= -1.58)v.vec.angle = -90;
	else v.vec.angle = 180 / (pi*v.vec.arc);

	return v;
}

template<typename T1, typename T2>
inline void vector<T1, T2>::operator=(vector<T1, T2>& vect)
{
	vec = vect.vec;
}

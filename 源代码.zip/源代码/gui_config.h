﻿#ifndef Gui_config_
#define Gui_config_

#include"set_bitmap.h"
#include"animation_sys.h"
#include<string>

using std::string;

class Gui_config :protected set_bitmap
{
public:
	enum Button_name
	{
		WhiteRectangle,//白色长方形
		WhiteDiamond,//白色菱形
	};
	enum Animation_name
	{
		Frie,
	};
	enum Context_name
	{
		index,//主页
		about,//关于
		config//设置
	};

	Gui_config();
	~Gui_config();

	//获取对象数目
	int get_obj_num();
	//获取动画数据数目
	int get_animation_num();
	//获取动画数据数组
	animation_sys::Animation & operator[](int i);
	animation_sys::Animation & get_animation(int i);
	animation_sys::Animation * get_animation();

	//添加一个按钮
	void add_button(char * bitmap_name, Button_name name, int x, int y);
	//添加一个动画背景
	void add_animation(char * bitmap_name, Animation_name name, int x, int y, int bitmap_num, int now, int sta, int end, double time_sec, bool whi);
	//添加一个静态背景
	void add_context(char * bitmap_name, Context_name name, int x = 0, int y = 0);

private:
	static int obj_num;//对象数目
	int bitmap_id;//位图id
	int bitmap_pid;//位图pid
	int animation_num;//位图数目
	animation_sys::Animation * animation;//动画资源

	//分配内存
	void stor_allocation();

	//获取路径
	char * get_button_path(Button_name button_name, int pos);
	char * get_animation_path(Animation_name animation_name, int pos);
	char * get_context_path(Context_name context_name);

};


#endif
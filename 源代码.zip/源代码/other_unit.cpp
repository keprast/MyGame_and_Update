﻿#include"other_unit.h"

other_unit::other_unit()
{
	bitmap_pid = 0;
	bitmap_id = 0;
}

other_unit::~other_unit()
{
}

void other_unit::Rush_solier(unit_sys::Unit & unit, animation_elem::Animation & animation)
{
	init_bitmap(bitmap_id, 4, animation, "rush_solier");
	bitmap_id += 1;

	set_bitmap_pid(0, bitmap_pid, animation);
	bitmap_pid += 1;
	set_bitmap_pid(1, bitmap_pid, animation);
	bitmap_pid += 1;
	set_bitmap_pid(2, bitmap_pid, animation);
	bitmap_pid += 1;
	set_bitmap_pid(3, bitmap_pid, animation);
	bitmap_pid += 1;

	set_bitmap_num(0, 1, animation);
	set_bitmap_num(1, 1, animation);
	set_bitmap_num(2, 1, animation);
	set_bitmap_num(3, 1, animation);

	set_bitmap_lever(1, animation);
	set_bitmap_lever(1, 0, animation);
	set_bitmap_lever(2, 0, animation);
	set_bitmap_lever(3, 0, animation);

	set_bitmap_lever(0, 4, animation);
	set_bitmap_name(0, 0, "solier/rush_solier/head.png", "突击兵头部", animation);
	set_bitmap_action_num(0, 1, animation);

	set_bitmap_lever(1, 3, animation);
	set_bitmap_name(1, 0, "solier/rush_solier/trunk.png", "突击兵躯干", animation);
	set_bitmap_action_num(1, 1, animation);

	set_bitmap_lever(2, 2, animation);
	set_bitmap_name(2, 0, "solier/rush_solier/hand.png", "突击兵手部", animation);
	set_bitmap_action_num(2, 1, animation);

	set_bitmap_lever(3, 1, animation);
	set_bitmap_name(3, 0, "solier/rush_solier/foot.png", "突击兵腿部", animation);
	set_bitmap_action_num(3, 1, animation);

	set_bitmap_action_draw_flags(0, 0, true, false, 0, 0, 0, animation);
	set_bitmap_action_axis(0, 0, 0, 0, 0, animation);//单元的绘制位置由相机位置决定
	set_bitmap_action_times(0, 0, 1 / 60.0, animation);
	set_bitmap_df_action_flags(0, 0, 0, animation);

	set_bitmap_action_draw_flags(1, 0, true, false, 0, 0, 0, animation);
	set_bitmap_action_axis(1, 0, 0, 0, 0, animation);
	set_bitmap_action_times(1, 0, 1 / 60.0, animation);
	set_bitmap_df_action_flags(1, 0, 0, animation);

	set_bitmap_action_draw_flags(2, 0, true, false, 0, 0, 0, animation);
	set_bitmap_action_axis(2, 0, 0, 0, 0, animation);
	set_bitmap_action_times(2, 0, 1 / 60.0, animation);
	set_bitmap_df_action_flags(2, 0, 0, animation);

	set_bitmap_action_draw_flags(3, 0, true, false, 0, 0, 0, animation);
	set_bitmap_action_axis(3, 0, 0, 0, 0, animation);
	set_bitmap_action_times(3, 0, 1 / 60.0, animation);
	set_bitmap_df_action_flags(3, 0, 0, animation);

	unit.accelerate.u_a_arc = 0.035;
	unit.accelerate.u_a_x = 1.5;
	unit.accelerate.u_a_y = 1.5;
	unit.accelerate.u_a_z = 0;

	unit.state.u_hp = 100;
	unit.state.u_is_live = true;

	unit.wh.u_w = 64;
	unit.wh.u_h = 64;
}

void other_unit::Doctor_solier(unit_sys::Unit & unit, animation_elem::Animation & animation)
{

}

void other_unit::Repar_solier(unit_sys::Unit & unit, animation_elem::Animation & animation)
{

}

void other_unit::Spy_solier(unit_sys::Unit & unit, animation_elem::Animation & animation)
{

}

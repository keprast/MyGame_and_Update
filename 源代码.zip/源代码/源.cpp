﻿#include<iostream>
#include"allegro5\allegro.h"
#include"allegro5\allegro_image.h"
#include"allegro5\allegro_font.h"
#include"allegro5\allegro_ttf.h"
#include"draw.h"
#include"logic.h"
#include"warning.h"
#include"debug.h"
#include"text_sys.h"

//修改为多线程，将四叉树单独放置在一个线程内。
#if defined(_MSC_VER) && (_MSC_VER >= 1900)
#pragma execution_character_set("utf-8")
#endif

using std::cout;
using std::endl;

const int Gui_op_object_num = 32;
const int Player_num = 1;
const int Ai_num = 4;

auto Gui_animation = new Gui_sys(16);
auto Map_animation = new Map_sys;
auto init_map = new Set_map(*Map_animation);

namespace logic
{
	player_sys player;
	ai_state ai_ste;
	set_sys set_config;
	controller con_tran(Gui_op_object_num, 16, 1);
	association assoc_tran;
	camera player_camera(1280, 720);
}

int main(int argc, char ** argv)
{
	//初始化快板框架资源
	ALLEGRO_DISPLAY * display = nullptr;
	ALLEGRO_TIMER * fps_timer = nullptr;
	ALLEGRO_TIMER * logic_timer = nullptr;
	ALLEGRO_EVENT_QUEUE * event_queue = nullptr;
	ALLEGRO_EVENT event;

	al_init();
	al_init_image_addon();
	al_install_mouse();
	al_install_keyboard();
	al_init_font_addon();
	al_init_ttf_addon();

	//初始化预设操作资源
	player_sys::Player_opertion opertion[16];
	opertion[0].keybords = { false,false,false,false,false };
	opertion[0].mouse = { false,false,0,0 };
	opertion[1].keybords = { false,false,false,true,false };
	opertion[1].mouse = { false,false,0,0 };
	opertion[2].keybords = { false,false,false,true,false };
	opertion[2].mouse = { false,false,0,0 };
	opertion[3].keybords = { false,false,false,true,false };
	opertion[3].mouse = { false,false,0,0 };
	opertion[4].keybords = { false,false,false,true,false };
	opertion[4].mouse = { false,false,0,0 };
	opertion[5].keybords = { false,false,false,true,false };
	opertion[5].mouse = { false,false,0,0 };
	opertion[6].keybords = { false,false,true,false,false };
	opertion[6].mouse = { false,false,0,0 };
	opertion[7].keybords = { false,false,true,false,false };
	opertion[7].mouse = { false,false,0,0 };
	opertion[8].keybords = { false,false,true,false,false };
	opertion[8].mouse = { false,false,0,0 };
	opertion[9].keybords = { false,true,false,false,false };
	opertion[9].mouse = { false,false,0,0 };
	opertion[10].keybords = { true,false,false,false,false };
	opertion[10].mouse = { false,false,0,0 };
	opertion[11].keybords = { false,false,false,true,false };
	opertion[11].mouse = { false,false,0,0 };
	opertion[12].keybords = { false,true,false,false,false };
	opertion[12].mouse = { false,false,0,0 };
	opertion[13].keybords = { false,false,true,false,false };
	opertion[13].mouse = { false,false,0,0 };
	opertion[14].keybords = { false,false,true,false,false };
	opertion[14].mouse = { false,false,0,0 };
	opertion[15].keybords = { false,false,true,false,false };
	opertion[15].mouse = { false,false,0,0 };

	//初始化快板框架资源
	fps_timer = al_create_timer(1 / 60.0);
	logic_timer = al_create_timer(1 / 60.0);

	event_queue = al_create_event_queue();

	//初始化引擎资源
	auto text = new text_sys();
	text->get_event_queue(event_queue);
	text->init_text();

	logic::set_config.init_display_wh(display);
	logic::set_config.init_mouse_axis(display, opertion[0]);

	al_set_window_title(display, "Ver0.1.0【洞察之识】");

	//获取快板框架事件队列到引擎
	Gui_animation->get_event_queue(event_queue);
	Map_animation->get_event_queue(event_queue);
	//初始化动画控制器逻辑
	logic::con_tran.init_index_logic();
	logic::con_tran.init_index_about_logic();
	logic::con_tran.init_index_config_logic();

	//初始动画容器
	Gui_animation->init_animation_draw_elem(Gui_animation->Ui_ELEM, Gui_op_object_num);
	Gui_animation->init_animation_draw_elem(Gui_animation->MapContext_ELEM, 128);
	Gui_animation->init_animation_draw_elem(Gui_animation->MapUnit_ELEM, 128);
	Gui_animation->init_animation_draw_elem(Gui_animation->PlayerSpriti_ELEM, Player_num);
	Gui_animation->init_animation_draw_elem(Gui_animation->AiSpriti_ELEM, Ai_num);

	//初始化Gui动画资源
	Gui_animation->init_gui();

	//初始化Map资源
	animation_elem * ai_animation = new animation_elem;
	animation_elem * player_animation = new animation_elem;
	unit_elem * map_context_elem = new unit_elem[1];
	unit_elem * map_unit_elem = new unit_elem[1];
	animation_elem * map_context_animation = new animation_elem[1];
	animation_elem * map_unit_animation = new animation_elem[1];

	Map_sys * map_context = new Map_sys[1]{ { 0, 640, 640,"test" } };
	Map_sys * map_unit = new Map_sys[1]{ {0, 640, 640, "test"} };
	set_player * set_pla = new set_player(Player_num, map_context[0]);

	init_map->init_map_table(map_context[0], map_context_elem[0], map_unit_elem[0], map_context_animation[0], map_unit_animation[0]);
	logic::player.set_unit_itme_id(1);
	set_pla->init_player(map_context[0], logic::player, *player_animation);
	Map_animation->init_map_context(map_context[0], map_context_elem[0], map_context_animation[0]);
	Map_animation->init_map_unit(map_unit[0], map_unit_elem[0], map_unit_animation[0]);

	al_register_event_source(event_queue, al_get_display_event_source(display));
	al_register_event_source(event_queue, al_get_keyboard_event_source());
	al_register_event_source(event_queue, al_get_mouse_event_source());
	al_register_event_source(event_queue, al_get_timer_event_source(fps_timer));
	al_register_event_source(event_queue, al_get_timer_event_source(logic_timer));

	int k = 0;
	int ticks = 0, now_windows = 0;
	bool open_game = true;
	bool redraw = false;

	//初始化引擎资源
	Gui_animation->update_gui(Gui_animation->INDEX);
	Gui_animation->update_gui_animation();

	text->start_text_timer(Gui_animation->INDEX);
	Gui_animation->start_animation_timer(Gui_animation->Ui_ELEM);
	al_start_timer(fps_timer);
	al_start_timer(logic_timer);

	while (open_game)
	{
		//预设资源计数复位
		if (k == 16)
			k = 0;

		//引擎重绘屏幕
		if (redraw) {
			redraw = false;

			logic::player.set_player_date(opertion[0]);
			text->get_opertion(opertion[0]);

			//绘制Map对象
			if (now_windows >= 3) {
				al_clear_to_color(al_map_rgb(255, 255, 255));
				Map_animation->MapContext_draw_object();//ok
				Map_animation->MapUnit_draw_object();//ok
				Map_animation->Spriti_draw_object();//ok
			}

			//绘制Gui对象
			Gui_animation->animation_draw_object(Gui_animation->Ui_ELEM);

			logic::assoc_tran.end_bmp_assoc();
			logic::assoc_tran.end_win_assoc();

			text->set_axis_date(logic::player.get_unit_x(), logic::player.get_unit_y());
			text->draw_text(now_windows);

			//快板框架绘制
			al_flip_display();

			event.mouse.dx = 0;
			event.mouse.dy = 0;
			event.mouse.dz = 0;
		}

		//获取快板框架事件
		while (al_get_next_event(event_queue, &event))
		{
			Gui_animation->get_event(event);
			Map_animation->get_event(event);
			text->get_event(event);

			if (event.type == ALLEGRO_EVENT_KEY_DOWN) {
				switch (event.keyboard.keycode)
				{
				case ALLEGRO_KEY_ESCAPE:
					open_game = false;
					break;
				case ALLEGRO_KEY_W:
					opertion[0].keybords.key_w = true;
					break;
				case ALLEGRO_KEY_S:
					opertion[0].keybords.key_s = true;
					break;
				case ALLEGRO_KEY_A:
					opertion[0].keybords.key_a = true;
					break;
				case ALLEGRO_KEY_D:
					opertion[0].keybords.key_d = true;
					break;
				case ALLEGRO_KEY_1:
					opertion[0].keybords.key_1 = true;
					break;
				case ALLEGRO_KEY_2:
					opertion[0].keybords.key_2 = true;
					break;
				case ALLEGRO_KEY_3:
					opertion[0].keybords.key_3 = true;
					break;
				case ALLEGRO_KEY_4:
					opertion[0].keybords.key_4 = true;
					break;
				case ALLEGRO_KEY_5:
					opertion[0].keybords.key_5 = true;
					break;
				}
			}
			else if (event.type == ALLEGRO_EVENT_KEY_UP) {
				switch (event.keyboard.keycode)
				{
				case ALLEGRO_KEY_ESCAPE:
					open_game = false;
					break;
				case ALLEGRO_KEY_W:
					opertion[0].keybords.key_w = false;
					break;
				case ALLEGRO_KEY_S:
					opertion[0].keybords.key_s = false;
					break;
				case ALLEGRO_KEY_A:
					opertion[0].keybords.key_a = false;
					break;
				case ALLEGRO_KEY_D:
					opertion[0].keybords.key_d = false;
					break;
				case ALLEGRO_KEY_1:
					opertion[0].keybords.key_1 = false;
					break;
				case ALLEGRO_KEY_2:
					opertion[0].keybords.key_2 = false;
					break;
				case ALLEGRO_KEY_3:
					opertion[0].keybords.key_3 = false;
					break;
				case ALLEGRO_KEY_4:
					opertion[0].keybords.key_4 = false;
					break;
				case ALLEGRO_KEY_5:
					opertion[0].keybords.key_5 = false;
					break;
				}
			}
			else if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) {
				switch (event.mouse.button)
				{
				case 1:
					opertion[0].mouse.left = true;
					break;
				case 2:
					opertion[0].mouse.right = true;
					break;
				}
			}
			else if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP) {
				switch (event.mouse.button)
				{
				case 1:
					opertion[0].mouse.left = false;
					break;
				case 2:
					opertion[0].mouse.right = false;
					break;
				}
			}
			//鼠标移动
			else if (event.type == ALLEGRO_EVENT_MOUSE_AXES ||
				event.type == ALLEGRO_EVENT_MOUSE_ENTER_DISPLAY) {
				opertion[0].mouse.x = event.mouse.x;
				opertion[0].mouse.y = event.mouse.y;
				opertion[0].mouse.z = event.mouse.z;
				opertion[0].mouse.dx = event.mouse.dx;
				opertion[0].mouse.dy = event.mouse.dy;
				opertion[0].mouse.dz = event.mouse.dz;
			}
			else if (event.type == ALLEGRO_EVENT_TIMER) {
				//运行一次逻辑
				if (event.timer.source == fps_timer)
					redraw = true;
				//运行一次重绘
				else if (event.timer.source == logic_timer)
					ticks += 1;
				//运行动画计时器
				else {
					text->run_text_timer();

					Gui_animation->run_animation_timer(Gui_animation->Ui_ELEM);
					Gui_animation->run_animation_timer(Gui_animation->MapContext_ELEM);
					Gui_animation->run_animation_timer(Gui_animation->MapUnit_ELEM);
					Gui_animation->run_animation_timer(Gui_animation->PlayerSpriti_ELEM);
//				    Animation.run_animation_timer(Animation.AiSpriti_ELEM);
				}
			}
		}

		//运行引擎逻辑
		while (ticks > 0)
		{
			ticks -= 1;
			now_windows = logic::con_tran.windows_pos_transition();

			if (now_windows == 3)
				logic::player.set_player_date(opertion[k]);
			else if (now_windows == 4)
				logic::player.set_player_date(opertion[0]);
			else
				logic::player.set_player_date(opertion[0]);

			logic::con_tran.reg_date_in_gui(now_windows, logic::player.get_player_opertion());

			logic::assoc_tran.sta_bmp_assoc(logic::con_tran.get_TS_num(), logic::con_tran.get_service_state());
			logic::assoc_tran.sta_win_assoc(logic::con_tran, *Gui_animation, *text);

			//动画控制器
			if (!Gui_animation->lock_animation_action_state(Gui_animation->Ui_ELEM)) {
				Gui_animation->clean_animation_elem_object(Gui_animation->Ui_ELEM);
				Gui_animation->update_gui_animation();
				Gui_animation->start_animation_timer(Gui_animation->Ui_ELEM);
			}

			Gui_animation->update_animation_date(Gui_animation->Ui_ELEM, logic::con_tran.get_service_state());
			Gui_animation->update_animation_timer(Gui_animation->Ui_ELEM);

			//开始游戏时运行此分支
			if (now_windows >= 3) {
				//玩家移动
				logic::player.move();
				//玩家开火
				logic::player.fire();

				set_pla->update_player(logic::player, *player_animation);//待完善

				Map_animation->reg_player_date_in_map(opertion[k], logic::player.get_unit());
				Map_animation->update_map_date(logic::player, logic::ai_ste);//待完善

				Map_animation->clean_animation_elem_object(Map_animation->MapContext_ELEM);
				Map_animation->update_map_animation(map_context[0], map_unit[0], *set_pla->get_player_date(), *player_animation, logic::player_camera);

				Map_animation->init_map_timer(Map_animation->MapUnit_ELEM);
				Map_animation->init_map_timer(Map_animation->PlayerSpriti_ELEM);
				//Animation1.init_Spriti_timer(Animation1.AiSpriti_ELEM, AiSpirit_timer_num, AiSpirit_timer);

				Map_animation->update_animation_timer(Map_animation->MapUnit_ELEM);
				Map_animation->update_animation_timer(Map_animation->PlayerSpriti_ELEM);
				//Animation1.update_animation_timer(Animation1.AiSpriti_ELEM, AiSpirit_timer_num, AiSpirit_timer);
			}
		}

		//预设资源计数
		k += 1;
	}

	//释放游戏资源
	delete Gui_animation;
	delete Map_animation;
	delete init_map;
	delete[] map_context;
	delete[] map_unit;
	delete[] map_context;
	delete[] map_context_animation;
	delete[] map_context_elem;
	delete[] map_unit_elem;
	delete ai_animation;
	delete player_animation;
	delete set_pla;
	al_destroy_timer(fps_timer);
	al_destroy_timer(logic_timer);
	al_destroy_event_queue(event_queue);
	al_destroy_display(display);
}
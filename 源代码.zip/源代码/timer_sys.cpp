﻿#include"timer_sys.h"

timer_sys::timer_sys(double sec)
{
	timer = nullptr;
	this->sec = sec;
	timer = al_create_timer(sec);
}

timer_sys::~timer_sys()
{
	al_destroy_timer(timer);
}

double timer_sys::get_timer_sec()
{
	return sec;
}

ALLEGRO_TIMER * timer_sys::get_timer()
{
	return timer;
}


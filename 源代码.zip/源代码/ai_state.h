#ifndef ai_state_
#define ai_state_

#include"player_sys.h"

class ai_state
{
public:
	ai_state();
	~ai_state();

	void reg_player_date_in_state(player_sys::Player_opertion & player);

private:
	player_sys::Player_opertion player_date;//��ҵ�����

};

#endif
﻿#include"state_transition_elem.h"

state_transition_elem::state_transition_elem()
{

}

state_transition_elem::~state_transition_elem()
{
	
}

state_transition_elem::State_Transition_elem * state_transition_elem::create_ST_elem(int e_num)
{
	State_Transition_elem * e_head;
	State_Transition_elem * e_after, *e_next;

	e_node_num = e_num;
	int e_id = 0;
	e_head = nullptr;
	e_after = e_next = nullptr;
	while (e_num != 0)
	{
		e_num--;
		e_next = new State_Transition_elem;
		if (e_head == nullptr) {
			e_head = e_next;
			get_node = in_node = e_head;
			e_next->next_elem = nullptr;
			e_next->after_elem = nullptr;
			e_next->e_node_id = e_id;
			e_next->has_date = false;
			e_next->p_date = nullptr;
			e_after = e_next;
		}
		else
		{
			e_after->next_elem = e_next;
			e_next->after_elem = e_after;
			e_next->e_node_id = ++e_id;
			e_next->has_date = false;
			e_next->p_date = nullptr;
			e_next->next_elem = nullptr;
			e_after = e_next;
		}
	}
	if (e_num == 0)elem_tail = e_next;

	return e_head;
}

void state_transition_elem::create_new_node()
{
	State_Transition_elem * new_node = new State_Transition_elem;
	e_node_num -= 1;

	new_node->has_date = false;
	new_node->p_date = nullptr;
	elem_tail->next_elem = new_node;
	new_node->after_elem = elem_tail;
	new_node->next_elem = nullptr;
	new_node->e_node_id = elem_tail->e_node_id + 1;
	elem_tail = new_node;
}

void state_transition_elem::create_an_node(State_Transition_elem * e_head, int node_id)
{
	while (e_head)
	{
		if (e_head->e_node_id == node_id) {
			State_Transition_elem * new_node = new State_Transition_elem;

			new_node->has_date = false;
			new_node->p_date = nullptr;
			e_head->next_elem = new_node;
			new_node->after_elem = e_head;
			if (e_head->next_elem == nullptr)new_node->next_elem = nullptr;
			else new_node->next_elem = e_head->next_elem;
			e_node_num += 1;
		}
		if (e_head->next_elem == nullptr)break;
		e_head = e_head->next_elem;
	}
}

void state_transition_elem::get_ST_elem_date(State_Transition_elem * e_head, Transition_op_to_anima * need_date, short state)
{
	if (state != 0)
		get_node = e_head;//顺序归位
	need_date = get_node->p_date;
	if (get_node == elem_tail)
		get_node = e_head;//顺序归位
	get_node = get_node->next_elem;
}

void state_transition_elem::get_ST_elem_date(State_Transition_elem * e_head, Transition_op_to_anima & need_date, short state)
{
	if (state != 0)
		get_node = e_head;//顺序归位
	need_date = get_node->date;
	if (get_node == elem_tail)
		get_node = e_head;//顺序归位
	get_node = get_node->next_elem;
}

void state_transition_elem::get_ST_elem_date(int e_id, State_Transition_elem * e_head, Transition_op_to_anima & need_date)
{
	while (e_head)
	{
		if (e_head->date.windows_id == e_id) {
			need_date = e_head->date;
			break;
		}
		e_head = e_head->next_elem;
	}
}

int state_transition_elem::in_ST_elem_date_is_null(State_Transition_elem * e_head, Transition_op_to_anima in_date)
{
	if (!e_head)return -1;//不存在该表
	while (true)
	{
		if (e_head->has_date == false) {
			e_head->date = in_date;
			get_node->has_date = true;
			return 1;//成功
		}
		if (!e_head->next_elem)break;
		e_head = e_head->next_elem;
	}
	return 0;//无空位置
}

int state_transition_elem::in_ST_elem_date_is_null(State_Transition_elem * e_head, Transition_op_to_anima * in_date)
{
	if (!e_head)return -1;
	while (true)
	{
		if (e_head->p_date == nullptr) {
			e_head->p_date = in_date;
			get_node->has_date = true;
			return 1;
		}
		if (!e_head->next_elem)break;
		e_head = e_head->next_elem;
	}
	return 0;
}

void state_transition_elem::in_ST_elem_date(int e_id, State_Transition_elem * e_head, Transition_op_to_anima & in_date)
{
	while (e_head)
	{
		if (e_head->e_node_id == e_id) {
			e_head->date = in_date;
			e_head->has_date = true;
			break;
		}
		if (!e_head->next_elem)break;
		e_head = e_head->next_elem;
	}
}

void state_transition_elem::in_ST_elem_date(int e_id, State_Transition_elem * e_head, Transition_op_to_anima * in_date)
{
	while (e_head->next_elem)
	{
		if (e_head->e_node_id == e_id) {
			e_head->p_date = in_date;
			get_node->has_date = true;
			break;
		}
		e_head = e_head->next_elem;
	}
}

void state_transition_elem::in_ST_elem_date(State_Transition_elem * e_head, Transition_op_to_anima & in_date, short state)
{
	if (state != 0)
		in_node = e_head;//顺序归位
	get_node->date = in_date;
	get_node->has_date = true;
	if (get_node == elem_tail)
		in_node = e_head;//顺序归位
	in_node = in_node->next_elem;
}

void state_transition_elem::in_ST_elem_date(State_Transition_elem * e_head, Transition_op_to_anima *& in_need, short state)
{
	if (state != 0)
		in_node = e_head;//顺序归位
	get_node->p_date = in_need;
	get_node->has_date = true;
	if (get_node == elem_tail)
		in_node = e_head;//顺序归位
	in_node = in_node->next_elem;
}

void state_transition_elem::clean_ST_elem(State_Transition_elem * e_head)
{
	while (elem_head)
	{
		e_head->has_date = false;
		e_head->p_date = nullptr;
		if (e_head->next_elem == nullptr)break;
		e_head = e_head->next_elem;
	}
}

void state_transition_elem::destroy_ST_elem(State_Transition_elem *& e_head)
{
	if (e_head) {
		State_Transition_elem * after_e = nullptr;
		if (e_head->next_elem) {
			while (e_head->next_elem)
			{
				delete after_e;
				after_e = nullptr;
				after_e = e_head;
				e_head = e_head->next_elem;
			}
			delete after_e;
			after_e = nullptr;
		}
		else
		{
			delete e_head;
			e_head = nullptr;
		}
	}
}

void state_transition_elem::destroy_an_node(State_Transition_elem * e_head, int node_id)
{
	while (e_head)
	{
		if (e_head->e_node_id == node_id) {
			if (e_head == elem_head) {
				elem_head = e_head->next_elem;
				e_head->next_elem->after_elem = nullptr;
				delete e_head;
				e_head = nullptr;
				e_node_num -= 1;
				break;
			}
			if (e_head == elem_tail) {
				elem_tail = elem_tail->after_elem;
				elem_tail->after_elem->next_elem = nullptr;
				delete e_head;
				e_head = nullptr;
				e_node_num -= 1;
				break;
			}
			e_head->next_elem->after_elem = e_head->after_elem;
			e_head->after_elem->next_elem = e_head->next_elem;
			delete e_head;
			e_head = nullptr;
			e_node_num -= 1;
			break;
		}
		if (e_head->next_elem == nullptr)break;
		e_head = e_head->next_elem;
	}
}

void state_transition_elem::pre_order_elem(State_Transition_elem * e_head)
{
	while (e_head)
	{
		get_node_date(e_head);
		if (e_head->next_elem == nullptr)break;
		e_head = e_head->next_elem;
	}
}

void state_transition_elem::lrd_order_elem(State_Transition_elem * e_tail)
{
	while (e_tail)
	{
		get_node_date(e_tail);
		if (e_tail->after_elem == nullptr)break;
		e_tail = e_tail->after_elem;
	}
}

int state_transition_elem::ST_elem_is_state(State_Transition_elem * e_head)
{
	int e_state = 1;//1代表满表,0代表有空间
	while (e_head->next_elem)
	{
		if (e_head->has_date == false || e_head->p_date == nullptr) {
			e_state = 0;
			break;
		}
		e_head = e_head->next_elem;
	}
	return e_state;
}

int state_transition_elem::get_elem_node_num()
{
	return e_node_num;
}

int state_transition_elem::get_have_date_node_num(State_Transition_elem * head)
{
	int have_date_obj_num = 0;
	while (head)
	{
		if (head->has_date)
			have_date_obj_num += 1;
		if (!head->next_elem)break;
		head = head->next_elem;
	}
	return have_date_obj_num;
}

void state_transition_elem::get_node_date(State_Transition_elem * e_tail)
{

}
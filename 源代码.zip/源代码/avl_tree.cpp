#include"avl_tree.h"

short avl_tree::AVL_wordbook_1[1]
{ 1 };
short avl_tree::AVL_wordbook_2[3]
{ 2,1,3 };
short avl_tree::AVL_wordbook_3[7]
{ 4,2,1,3,6,5,7 };
short avl_tree::AVL_wordbook_4[15]
{ 8,4,2,1,3,6,5,7,12,10,9,11,14,13,15 };
short avl_tree::AVL_wordbook_5[31]
{ 16,8,4,2,1,3,6,5,7,12,10,9,11,14,13,15,24,19,17,16,18,21,20,22,26,24,23,25,30,28,31 };
short avl_tree::AVL_wordbook_6[63]
{ 48,16,8,4,2,1,3,6,5,7,12,10,9,11,14,13,15,24,19,17,16,18,21,20,22,26,24,23,25,30,28,31,56,
40,36,34,33,35,38,37,39,44,42,41,43,46,45,47,56,52,50,49,51,54,53,55,60,58,57,59,62,61,63 };//Ŀǰ֧����ԭ�����Ϲ���߶�Ϊ6��AVL��

avl_tree::avl_tree()
{
	array_node = 0;
}

avl_tree::~avl_tree()
{

}

int avl_tree::create_AVL_tree(Ttree * t_node)
{
	if (!t_node)return -1;//��������
	int tree_H = get_tree_H_num(t_node);//�Ȼ�ȡ���ĸ߶�

	switch (tree_H)
	{
	case 1:
		avl_wordbook = AVL_wordbook_1;
		break;
	case 2:
		avl_wordbook = AVL_wordbook_2;
		break;
	case 3:
		avl_wordbook = AVL_wordbook_3;
		break;
	case 4:
		avl_wordbook = AVL_wordbook_4;
		break;
	case 5:
		avl_wordbook = AVL_wordbook_5;
		break;
	case 6:
		avl_wordbook = AVL_wordbook_6;
		break;
	default:
		return 0;//�����ֵ��С
		break;
	}
	modify_node_id(t_node, avl_wordbook);
	tree_node_num = 0;
	array_node = 0;
	
	return 1;//����ɹ�
}

int avl_tree::get_AVL_tree_date(Ttree * t_node, int n_id, int & get_date)
{
	if (!t_node)return -1;//��������
	while (true)
	{
		if (t_node->node_id == n_id) {
			get_date = t_node->date;
			return 1;//��ѯ�ɹ�
		}
		else if (t_node->node_id < n_id && t_node->left)t_node = t_node->left;
		else if (t_node->right)t_node = t_node->right;
		else break;
	}
	return 0;//��ѯʧ�ܣ������ڸýڵ�
}

int avl_tree::in_AVL_tree_date(Ttree * t_node, int n_id, int get_date)
{
	if (!t_node)return -1;//��������
	while (true)
	{
		if (t_node->node_id == n_id) {
			t_node->date = get_date;
			return 1;//��ѯ�ɹ�
		}
		else if (t_node->node_id < n_id && t_node->left)t_node = t_node->left;
		else if (t_node->right)t_node = t_node->right;
		else break;
	}
	return 0;//��ѯʧ�ܣ������ڸýڵ�
}

void avl_tree::modify_node_id(Ttree * t_node, short ar_id[])
{
	if (t_node) {
		t_node->node_id = ar_id[array_node];
		array_node++;
		modify_node_id(t_node->left, ar_id);
		modify_node_id(t_node->right, ar_id);
	}
}
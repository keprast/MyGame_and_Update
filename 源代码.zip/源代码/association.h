﻿#ifndef controller_plus_
#define controller_plus_

#include"allegro5\allegro.h"
#include"state_transition_elem.h"
#include"Gui_sys.h"
#include"controller.h"
#include"animation_sys.h"
#include"text_sys.h"

class association
{
public:
	association();
	~association();

	//关联对象
	struct Assoc
	{
		int to_bitmap_id;//触发点触发的位图id
		int to_acting_id;//触发点触发的行为id
	};

	//关联位图
	struct Assoc_bmp
	{
		int pid;
		bool in_assoc;
		bool assoc_lock;
		Assoc obj;
	};

	//关联窗口
	struct Assoc_win
	{
		int windows_id;
		bool in_assoc;
		bool assoc_lock;
	};

	static const int assoc_bnum = 32;//其他位图标记数目
	static const int assoc_wnum = 1;//其他窗口标记数目
	static Assoc_bmp assoc[assoc_bnum];//关联位图
	static Assoc_win a_win[assoc_wnum];//关联窗口

	//设定关联位图
	friend void set_bmp_assoc(state_transition_elem::Tran_id * t);
	//锁定关联
	void Lock_bmp_assoc(int j_pid, state_transition_elem::Tran_id * t);
	//解锁关联
	void unLock_bmp_assoc(int j_pid, state_transition_elem::Tran_id * t);
	//开始关联事件（如果有）
	void sta_bmp_assoc(int obj_num, state_transition_elem::Tran_id_plus * t_id, int j_pid = -1);
	//结束关联事件（如果有）
	void end_bmp_assoc();

	//设定关联窗口
	friend void set_win_assoc(bool lock, int w_pos);
	//锁定关联
	void Lock_win_assoc(int j_pid, state_transition_elem::Tran_id * t);
	//解锁关联
	void unLock_win_assoc(int j_pid, state_transition_elem::Tran_id * t);
	//开始关联事件（如果有）
	void sta_win_assoc(controller & con_tran, Gui_sys & animation, text_sys & text);
	//结束关联事件（如果有）
	bool end_win_assoc();

	friend void get_win_assoc_date(Assoc_win *& pos);
	Assoc_bmp * get_bmp_assoc_date();

private:
	static bool assocw_OK;

};

#endif

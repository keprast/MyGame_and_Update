﻿#ifndef player_sys_
#define player_sys_

#include"unit_sys.h"

//玩家的基础类，扩展请让该类继承
//包含玩家的所有操作，可直接对单元数据进行操作
//不需要额外增加接口，该类已继承单元类
//玩家系统类（基类）
class player_sys :public unit_sys
{
public:
	//鼠标操作结构
	struct Mouse_opertion
	{
		bool left;//鼠标左键
		bool right;//鼠标右键
		int x;//鼠标x坐标
		int y;//鼠标y坐标
		int z;
		int dx;//鼠标移动较上次移动的x坐标
		int dy;//鼠标移动较上次移动的y坐标
		int dz;
	};

	//键盘操作结构
	struct Keybord_opertion
	{
		bool key_w;//前键
		bool key_s;//后键
		bool key_a;//左键
		bool key_d;//右键
		bool key_r;//R键
		bool key_1;
		bool key_2;
		bool key_3;
		bool key_4;
		bool key_5;
	};

	//管理员操作结构
	struct Admin_opertion
	{

	};

	//玩家操作结构
	struct Player_opertion
	{
		Mouse_opertion mouse;//鼠标
		Keybord_opertion keybords;//键盘
	};

	//初始化玩家数据
	player_sys();
	//初始化并设定玩家的数据
	player_sys(Unit & pl);
	~player_sys();

	void set_player_mouse_x(int & mx);
	void set_player_mouse_y(int & my);
	void set_player_mouse_left(bool & ml);
	void set_player_mouse_right(bool & mr);
	//设定玩家的鼠标数据
	void set_player_mouse(Mouse_opertion & m);

	void set_player_key_w(bool & kw);
	void set_player_key_s(bool & ks);
	void set_player_key_a(bool & ka);
	void set_player_key_d(bool & kd);
	//设定玩家的键盘数据
	void set_player_keybord(Keybord_opertion & kbord);
	//设定玩家的数据
	void set_player_date(Player_opertion & plop);

	int & get_player_mouse_x();
	int & get_player_mouse_y();
	bool & get_player_mouse_left();
	bool & get_player_mouse_right();
	//获取玩家的鼠标数据
	Mouse_opertion & get_player_mouse();

	bool & get_player_key_w();
	bool & get_player_key_s();
	bool & get_player_key_a();
	bool & get_player_key_d();
	//获取玩家的键盘数据
	Keybord_opertion & get_player_keybord();
	//获取玩家的操作数据
	Player_opertion get_player_opertion();

	//获得玩家的生死状态
	bool & get_player_is_live_state();
	//获得玩家的开火状态
	bool & get_player_fire_state();
	//获得玩家的移动状态
	bool & get_player_move_state();
	//玩家移动时的调用函数
	void move();
	//玩家开火时的调用函数
	void fire();

private:
	Player_opertion player_opertion;//玩家的操作数据

};

#endif

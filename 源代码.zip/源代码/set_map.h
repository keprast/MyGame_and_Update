﻿#ifndef set_map_
#define set_map_

#include"map_sys.h"
#include"unit_elem.h"
#include"animation_elem.h"
#include"set_bitmap.h"
#include"unit_sys.h"
#include<string>

using std::string;

class Set_map :protected set_bitmap, public unit_sys
{
public:
	Set_map(Map_sys & map_date);
	~Set_map();

	//建造地图表格数据
	void init_map_table(Map_sys & map_date, unit_elem & map_context, unit_elem & map_unit, animation_elem & map_context_animation, animation_elem & map_unit_animation);

private:
	int bitmap_id;//位图id
	int pid;//位图pid
	string * name;//地图名字

	enum Map_unit_name
	{
		Blacks,
		CemFlo,Grassd,
		WoodBx
	};

	//初始化位图标记
	void init_bmp_flg();
	//获取地图表格
	int * get_map_table(int map_z, string map_name, int & map_w, int & map_h);


	//测试地图表格
	int * test_of_table(int map_z, int & map_w, int & map_h);
	//火焰岛地图表格
	int * fire_island_of_table(int map_z, int & map_w, int & map_h);

	//黑色块0
	void black(int x, int y, int z, unit_sys::Unit & unit, animation_elem::Animation & animation);
	//水泥地1
	void cement_floor(int x, int y, int z, unit_sys::Unit & unit, animation_elem::Animation & animation);
	//草地2
	void grass(int x, int y, int z, unit_sys::Unit & unit, animation_elem::Animation & animation);
	//木箱子3
	void wood_box(int x, int y, int z, unit_sys::Unit & unit, animation_elem::Animation & animation);

};

#endif
/*
pid >= 1000 的单位为地图单位
pid >= 9000 的单位为地图可互动单位
pid >= 10000 的单位为地图可移动单位
pid < 1000 的单位为可移动单位
---------------------------------
同理，其他的id也相同
*/
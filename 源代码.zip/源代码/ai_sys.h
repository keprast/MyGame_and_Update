#ifndef ai_sys_
#define ai_sys_

#include"unit_sys.h"

class ai_sys :public unit_sys
{
public:
	ai_sys();
	~ai_sys();

private:

};

#endif
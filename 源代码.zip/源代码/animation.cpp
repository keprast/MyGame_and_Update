﻿#include"animation.h"

animation::animation(int bitmap_num)
{
	this->bitmap_num = bitmap_num;
	bitmap = nullptr;
	bitmap = new ALLEGRO_BITMAP*[bitmap_num];
}

animation::~animation()
{
	for (int i = 0; i < bitmap_num; i++)
		al_destroy_bitmap(bitmap[i]);
}

int animation::get_bitmap_num()
{
	return bitmap_num;
}

ALLEGRO_BITMAP * animation::operator[](int i)
{
	return bitmap[i];
}

ALLEGRO_BITMAP * animation::get_bitmap(int i)
{
	return bitmap[i];
}

void animation::set_bitmap(int i, char * name)
{
	bitmap[i] = al_load_bitmap_flags(name, ALLEGRO_VIDEO_BITMAP);
}

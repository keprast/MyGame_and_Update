﻿#include"iostream"
#include"quad_tree.h"

using std::cout;
using std::endl;

//预定义区域最大容纳数为150
unit_sys::Unit quad_tree::unit_obj;
animation_elem::Animation quad_tree::animation_obj;
int * quad_tree::map_table = nullptr;
unit_sys::Unit quad_tree::unit[16][object_max_num];
animation_elem::Animation quad_tree::animation[16][object_max_num];

int quad_tree::tree_wordbook_1[6]
{ 0,1,0,0,0,0 };
int quad_tree::tree_wordbook_2[22]
{ 0,1,2,0,0,0,0,3,0,0,0,0,4,0,0,0,0,5,0,0,0,0 };
int quad_tree::tree_wordbook_3[86]
{ 0,1,2,3,0,0,0,0,4,0,0,0,0,5,0,0,0,0,6,0,0,0,0,7,8,0,0,0,0,9,0,0,0,0,10,0,0,0,0,11,0,0,0,0,
12,13,0,0,0,0,14,0,0,0,0,15,0,0,0,0,16,0,0,0,0,17,18,0,0,0,0,19,0,0,0,0,20,0,0,0,0,21,0,0,0,0 };

quad_tree::quad_tree()
{
	obj_addup_num = 0;
	w1 = 640;
	h1 = 640;
}

quad_tree::~quad_tree()
{
	destroy_quad_tree(root);
}

void quad_tree::set_quad_tree(int lever)
{
	switch (lever)
	{
	case 1:
		word_book = tree_wordbook_1;
		break;
	case 2:
		word_book = tree_wordbook_2;
		break;
	case 3:
		word_book = tree_wordbook_3;
		break;
	}
}

quad_tree::q_tree * quad_tree::create_quad_tree(int * word_book, q_tree_box root_box)
{
	q_tree * root = new q_tree;
	q_tree_box rect_box[4];

	++word_book;
	root->node_id = *word_book;
	if (root->node_id != 0){//避免内存浪费
		root->q_date.unit_num = 0;
		root->q_date.unit_date = new unit_elem();
		root->q_date.animation_date = new animation_elem();
		root->q_date.unit_date->elem_head = root->q_date.unit_date->create_Unit_elem(object_max_num);
		root->q_date.animation_date->elem_head = root->q_date.animation_date->create_Animation_elem(object_max_num);
	}

	root->q_box.on_box_x = root_box.on_box_x;
	root->q_box.on_box_y = root_box.on_box_y;
	root->q_box.to_box_x = root_box.to_box_x;
	root->q_box.to_box_y = root_box.to_box_y;

	rect_box[UR].on_box_x = root_box.to_box_x / 2.0;
	rect_box[UR].on_box_y = root_box.on_box_y;
	rect_box[UR].to_box_x = root_box.to_box_x;
	rect_box[UR].to_box_y = root_box.to_box_y / 2.0;

	rect_box[UL].on_box_x = root_box.on_box_x;
	rect_box[UL].on_box_y = root_box.on_box_y;
	rect_box[UL].to_box_x = root_box.to_box_x / 2.0;
	rect_box[UL].to_box_y = root_box.to_box_y / 2.0;

	rect_box[BL].on_box_x = root_box.on_box_x;
	rect_box[BL].on_box_y = root_box.to_box_y / 2.0;
	rect_box[BL].to_box_x = root_box.to_box_x / 2.0;
	rect_box[BL].to_box_y = root_box.to_box_y;

	rect_box[BR].on_box_x = root_box.to_box_x / 2.0;
	rect_box[BR].on_box_y = root_box.to_box_y / 2.0;
	rect_box[BR].to_box_x = root_box.to_box_x;
	rect_box[BR].to_box_y = root_box.to_box_y;
	
	if (root->node_id == 0)
		return nullptr;

	root->rect[UR] = create_quad_tree(word_book, rect_box[UR]);
	root->rect[UL] = create_quad_tree(word_book, rect_box[UL]);
	root->rect[BL] = create_quad_tree(word_book, rect_box[BL]);
	root->rect[BR] = create_quad_tree(word_book, rect_box[BR]);

	return root;
}

void quad_tree::create_new_node(q_tree *& root)
{
	int next_lever = root->t_lever + 1;
	static q_tree_box rect_box[4];
	static animation_elem::Animation anima_obj[20];
	static unit_sys::Unit unit_obj[20];

	//获取队列中的数据
	root->q_date.unit_date->get_Unit_elem_arr_date(root->q_date.unit_date->elem_head, unit_obj);

	root->q_date.unit_num = 0;
	divesion_area(root, rect_box);//划分区域
	q_tree * new_node[4];
	for (int i = 0; i < 4; i++) {
		new_node[i] = new q_tree;
		root->rect[i] = new_node[i];
		root->rect[i]->q_date.unit_num = 0;
		root->rect[i]->q_date.unit_date = new unit_elem();
		root->rect[i]->q_date.animation_date = new animation_elem();
		root->rect[i]->q_date.unit_date->elem_head = root->q_date.unit_date->create_Unit_elem(object_max_num);
		root->rect[i]->q_date.animation_date->elem_head = root->q_date.animation_date->create_Animation_elem(object_max_num);
		root->rect[i]->node_id = root->node_id + i;
		root->rect[i]->t_lever = next_lever;
		root->rect[i]->q_box = rect_box[i];
		root->rect[i]->rect[UR] = nullptr;
		root->rect[i]->rect[UL] = nullptr;
		root->rect[i]->rect[BL] = nullptr;
		root->rect[i]->rect[BR] = nullptr;
	}
//	for (int j = 0; j < 20; j++)
//		in_quad_tree_date(root, unit_obj[j], anima_obj[j]);//入队
}

void quad_tree::destroy_quad_tree(q_tree *& root)
{
	if (root) {
		destroy_quad_tree(root->rect[UR]);
		destroy_quad_tree(root->rect[UL]);
		destroy_quad_tree(root->rect[BL]);
		destroy_quad_tree(root->rect[BR]);

		delete root;
		root = nullptr;
	}
}

void quad_tree::pre_quad_tree(q_tree * root)
{
	if (root) {
		get_date(root);
		pre_quad_tree(root->rect[UR]);
		pre_quad_tree(root->rect[UL]);
		pre_quad_tree(root->rect[BL]);
		pre_quad_tree(root->rect[BR]);
	}
}

int quad_tree::get_quad_tree_date(unit_sys::Unit & target, unit_sys::Unit unit[][150], animation_elem::Animation animation[][150])
{
	now_arr = 0;
	w2 = target.wh.u_w;
	h2 = target.wh.u_h;
	x_axis[0] = target.axis.u_x;
	y_axis[0] = target.axis.u_y;
	x_axis[1] = target.axis.u_x + target.wh.u_w;
	y_axis[1] = target.axis.u_y;
	x_axis[2] = target.axis.u_x + target.wh.u_w;
	y_axis[2] = target.axis.u_y + target.wh.u_h;
	x_axis[3] = target.axis.u_x;
	y_axis[3] = target.axis.u_y + target.wh.u_h;

	get_quad_tree_date(root);
	for (int i = 0; i < now_arr; i++)
	{
		for (int j = 0; j < object_max_num; j++) 
		{
			unit[i][j] = this->unit[i][j];
			animation[i][j] = this->animation[i][j];
		}
	}
	return now_arr;
}

void quad_tree::get_date(q_tree * root)
{
	int num = 0;//bug
	if (root) {
		num++;
		cout << num << "节点的x1 =" << root->q_box.on_box_x << endl;
		cout << num << "节点的y1 =" << root->q_box.on_box_y << endl;
		cout << num << "节点的x2 =" << root->q_box.to_box_x << endl;
		cout << num << "节点的y2 =" << root->q_box.to_box_y << endl;
		cout << endl;
	}
}

void quad_tree::divesion_area(q_tree * root, q_tree_box rect_box[4])
{
	rect_box[UR].on_box_x = root->q_box.to_box_x / 2.0;
	rect_box[UR].on_box_y = root->q_box.on_box_y;
	rect_box[UR].to_box_x = root->q_box.to_box_x;
	rect_box[UR].to_box_y = root->q_box.to_box_y / 2.0;

	rect_box[UL].on_box_x = root->q_box.on_box_x;
	rect_box[UL].on_box_y = root->q_box.on_box_y;
	rect_box[UL].to_box_x = root->q_box.to_box_x / 2.0;
	rect_box[UL].to_box_y = root->q_box.to_box_y / 2.0;

	rect_box[BL].on_box_x = root->q_box.on_box_x;
	rect_box[BL].on_box_y = root->q_box.to_box_y / 2.0;
	rect_box[BL].to_box_x = root->q_box.to_box_x / 2.0;
	rect_box[BL].to_box_y = root->q_box.to_box_y;

	rect_box[BR].on_box_x = root->q_box.to_box_x / 2.0;
	rect_box[BR].on_box_y = root->q_box.to_box_y / 2.0;
	rect_box[BR].to_box_x = root->q_box.to_box_x;
	rect_box[BR].to_box_y = root->q_box.to_box_y;
}

void quad_tree::guide_to_pos(q_tree *& q_pos, const float & target_x, const float & target_y, bool pos[4])
{
	if (q_pos->rect[UR]->q_box.on_box_x <= target_x && q_pos->rect[UR]->q_box.on_box_y <= target_y
		&& q_pos->rect[UR]->q_box.to_box_x >= target_x && q_pos->rect[UR]->q_box.to_box_y >= target_y)
		pos[UR] = true;
	if (q_pos->rect[UL]->q_box.on_box_x <= target_x && q_pos->rect[UL]->q_box.on_box_y <= target_y
		&& q_pos->rect[UL]->q_box.to_box_x >= target_x && q_pos->rect[UL]->q_box.to_box_y >= target_y)
		pos[UL] = true;
	if (q_pos->rect[BL]->q_box.on_box_x <= target_x && q_pos->rect[BL]->q_box.on_box_y <= target_y
		&& q_pos->rect[BL]->q_box.to_box_x >= target_x && q_pos->rect[BL]->q_box.to_box_y >= target_y)
		pos[BL] = true;
	if (q_pos->rect[BR]->q_box.on_box_x <= target_x && q_pos->rect[BR]->q_box.on_box_y <= target_y
		&& q_pos->rect[BR]->q_box.to_box_x >= target_x && q_pos->rect[BR]->q_box.to_box_y >= target_y)
		pos[BR] = true;
}

void quad_tree::in_quad_tree_date(q_tree * root)//存在数据遗漏问题
{
	if (root && !stop_in) {
		if (!root->rect[0])
			in_date(root);

		in_quad_tree_date(root->rect[UL]);
		in_quad_tree_date(root->rect[UR]);
		in_quad_tree_date(root->rect[BL]);
		in_quad_tree_date(root->rect[BR]);
	}
	else
		obj_addup_num += 1;
}

void quad_tree::in_date(q_tree * root)
{
	static bool unit_ok;
	just_this = 0;

	for (int i = 0; i < 4; i++)
	{
		if (root->q_box.on_box_x < x_axis[i] && root->q_box.on_box_y < y_axis[i]
			&& root->q_box.to_box_x > x_axis[i] && root->q_box.to_box_y > y_axis[i])
			just_this += 1;
	}
	if (just_this != 0) {
		if(just_this == 4)
			stop_in = true;
		unit_ok = root->q_date.unit_date->in_Unit_elem_date_is_null(root->q_date.unit_date->elem_head, unit_obj);
		root->q_date.animation_date->in_Animation_elem_date_is_null(root->q_date.animation_date->elem_head, animation_obj);
		root->q_date.unit_num += 1;
	}
	if (!unit_ok)
		cout << "四叉树的单元容器过小！" << endl;
}

void quad_tree::get_quad_tree_date(q_tree * root)
{
	if (root) {
		if (!root->rect[0]) {
			if (get_pos(root->q_box.on_box_x, root->q_box.on_box_y)) {
				root->q_date.unit_date->get_Unit_elem_arr_date(root->q_date.unit_date->elem_head, unit[now_arr]);
				root->q_date.animation_date->get_Animation_elem_arr_date(root->q_date.animation_date->elem_head, animation[now_arr]);
				now_arr += 1;
			}
		}
		get_quad_tree_date(root->rect[UL]);
		get_quad_tree_date(root->rect[UR]);
		get_quad_tree_date(root->rect[BL]);
		get_quad_tree_date(root->rect[BR]);
	}
}

void quad_tree::in_quad_tree_date(unit_sys::Unit & unit, animation_elem::Animation & animation)
{
	stop_in = false;
	unit_obj = unit;
	animation_obj = animation;

	x_axis[0] = unit.axis.u_x;
	y_axis[0] = unit.axis.u_y;
	x_axis[1] = unit.axis.u_x + unit.wh.u_w;
	y_axis[1] = unit.axis.u_y;
	x_axis[2] = unit.axis.u_x + unit.wh.u_w;
	y_axis[2] = unit.axis.u_y + unit.wh.u_h;
	x_axis[3] = unit.axis.u_x;
	y_axis[3] = unit.axis.u_y + unit.wh.u_h;

	in_quad_tree_date(root);
}

void quad_tree::clean_quad_tree_obj_date(q_tree * root, unit_sys::Unit & obj, animation_elem::Animation & anima_obj)
{
	q_tree * q_node[4];
	float x[4], y[4];
	bool no_this_obj[4]{ false,false,false,false };

	int next_node = 0;
	for (int i = 0; i < 4; i++)
	{
		if (root->rect[i]) {
			next_node += 1;
			q_node[i] = root->rect[i];
		}
		else {
			no_this_obj[i] = true;
			q_node[i] = nullptr;
		}
	}
	if (next_node == 0) {
		no_this_obj[0] = false;
		q_node[0] = root;
	}

	x[0] = obj.axis.u_x + obj.wh.u_w;
	y[0] = obj.axis.u_y;
	x[1] = obj.axis.u_x;
	y[1] = obj.axis.u_y;
	x[2] = obj.axis.u_x;
	y[2] = obj.axis.u_y + obj.wh.u_h;
	x[3] = obj.axis.u_x + obj.wh.u_w;
	y[3] = obj.axis.u_y + obj.wh.u_h;

	while (!no_this_obj[0] || !no_this_obj[1] || !no_this_obj[2] || !no_this_obj[3])
	{
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				if (no_this_obj)continue;
				if (root->rect[i]->q_box.on_box_x <= x[j] && root->rect[i]->q_box.on_box_y <= y[j]
					&& root->rect[i]->q_box.to_box_x >= x[j] && root->rect[i]->q_box.to_box_y >= y[j]) {
					if (!root->rect[0]) {//是叶子节点
						root->q_date.unit_num -= 1;
						obj_addup_num -= 1;
						root->q_date.unit_date->clean_Unit_elem_node(root->q_date.unit_date->elem_head, obj);
					}
				}
			}
		}
	}
}

void quad_tree::clean_quad_tree_node_date(q_tree * root, unit_sys::Unit & obj)
{
	q_tree * q_node[4];
	float x[4], y[4];
	bool no_this_obj[4]{ false,false,false,false };
	
	int next_node = 0;
	for (int i = 0; i < 4; i++)
	{
		if (root->rect[i]) {
			next_node += 1;
			q_node[i] = root->rect[i];
		}
		else {
			no_this_obj[i] = true;
			q_node[i] = nullptr;
		}
	}
	if (next_node == 0) {
		no_this_obj[0] = false;
		q_node[0] = root;
	}

	x[0] = obj.axis.u_x + obj.wh.u_w;
	y[0] = obj.axis.u_y;
	x[1] = obj.axis.u_x;
	y[1] = obj.axis.u_y;
	x[2] = obj.axis.u_x;
	y[2] = obj.axis.u_y + obj.wh.u_h;
	x[3] = obj.axis.u_x + obj.wh.u_w;
	y[3] = obj.axis.u_y + obj.wh.u_h;

	while (!no_this_obj[0] || !no_this_obj[1] || !no_this_obj[2] || !no_this_obj[3])
	{
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				if (no_this_obj)continue;
				if (root->rect[i]->q_box.on_box_x <= x[j] && root->rect[i]->q_box.on_box_y <= y[j]
					&& root->rect[i]->q_box.to_box_x >= x[j] && root->rect[i]->q_box.to_box_y >= y[j]) {
					if (!root->rect[0]) {//是叶子节点
						obj_addup_num -= root->q_date.unit_num;
						root->q_date.unit_num = 0;
						root->q_date.unit_date->clean_Unit_elem(root->q_date.unit_date->elem_head);
					}
				}
			}
		}
	}
}

void quad_tree::destroy_surplus_quad_tree_node(q_tree * root)
{
	if (root->rect[0]) {
		if (root->rect[UR]->q_date.unit_num == 0 && root->rect[UL]->q_date.unit_num == 0
			&& root->rect[BR]->q_date.unit_num == 0 && root->rect[BL]->q_date.unit_num == 0) {
			for (int i = 0; i < 4; i++)
			{
				root->rect[i]->q_date.unit_date->destroy_Unit_elem(root->rect[i]->q_date.unit_date->elem_head);
				delete root->rect[i];
				root->rect[i] = nullptr;
			}
		}
		destroy_surplus_quad_tree_node(root);
		destroy_surplus_quad_tree_node(root);
		destroy_surplus_quad_tree_node(root);
		destroy_surplus_quad_tree_node(root);
	}
}

int quad_tree::get_quad_tree_area_obj_num(unit_sys::Unit & target_obj)
{
	q_tree * q_node[4];
	float x[4], y[4];
	bool no_this_obj[4]{ false,false,false,false };
	bool after_area[4]{ false,false,false,false };
	int next_node = 0;

	for (int i = 0; i < 4; i++)
	{
		if (root->rect[i]) {
			next_node += 1;
			q_node[i] = root->rect[i];
		}
		else {
			no_this_obj[i] = true;
			q_node[i] = nullptr;
		}
	}
	if (next_node == 0) {
		no_this_obj[0] = false;
		q_node[0] = root;
	}

	x[0] = target_obj.axis.u_x + target_obj.wh.u_w;
	y[0] = target_obj.axis.u_y;
	x[1] = target_obj.axis.u_x;
	y[1] = target_obj.axis.u_y;
	x[2] = target_obj.axis.u_x;
	y[2] = target_obj.axis.u_y + target_obj.wh.u_h;
	x[3] = target_obj.axis.u_x + target_obj.wh.u_w;
	y[3] = target_obj.axis.u_y + target_obj.wh.u_h;

	while (!no_this_obj[0] || !no_this_obj[1] || !no_this_obj[2] || !no_this_obj[3])
	{
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				if (no_this_obj[j])
					continue;
				if (q_node[i]->q_box.on_box_x <= x[j] && q_node[i]->q_box.on_box_y <= y[j]
					&& q_node[i]->q_box.to_box_x >= x[j] && q_node[i]->q_box.to_box_y >= y[j]) {
					if (after_area[i]) {//避免重复数据
						no_this_obj[j] = true;
						break;
					}
					if (!q_node[i]->rect[0]) {//是叶子节点,将数据导出
						no_this_obj[j] = true;
						after_area[i] = true;
					}
				}
			}
		}
	}
	return 0;
}

int quad_tree::get_quad_tree_obj_addup()
{
	return obj_addup_num;
}

bool quad_tree::get_pos(float & x, float & y)
{
	if ((x <= x_axis[0] + w2) ||
		(y <= y_axis[0] + w2) ||
		(x_axis[0] <= x + w1) ||
		(y_axis[0] <= y + h1)) {
		return true;
	}
	return false;
}

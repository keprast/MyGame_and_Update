#include"ai_state.h"

ai_state::ai_state()
{
}

ai_state::~ai_state()
{
}

void ai_state::reg_player_date_in_state(player_sys::Player_opertion & player)
{
	player_date = player;
}

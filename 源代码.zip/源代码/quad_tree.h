﻿#ifndef quad_tree_
#define quad_tree_

#include"animation_elem.h"
#include"unit_elem.h"

//四叉树，地图遍历用，存储了游戏进行中的动画数据和单元数据，是框架中的主要交互系统之一
//可用于数据导入和数据导出
//四叉树的叶子节点为存储区块，非叶子节点不存储数据，仅供查询
//四叉树类（基类）
class quad_tree
{
public:
	//四叉树的区块位置结构
	enum q_tree_pos
	{
		UR,//右上角
		UL,//左上角
		BL,//左下角
		BR//右下角
	};

	//单元数目为单元数据的大小
	//四叉树的数据结构
	struct q_tree_date
	{
		int unit_num;//单元数目
		unit_elem * unit_date;//单元数据
		animation_elem * animation_date;//动画数据
	};

	//四叉树的区块分割参数结构
	struct q_tree_box
	{
		float on_box_x, on_box_y;//起点坐标（左上角）
		float to_box_x, to_box_y;//终点坐标（右下角）
	};

	//四叉树结构体
	struct q_tree
	{
		int t_lever;//节点层数
		int node_id;//节点id（在四叉树中表示为节点层数）
		q_tree_box q_box;//四叉树盒子
		q_tree_date q_date;//四叉树数据
		q_tree * rect[4];//四叉树子节点
	};

	q_tree * root;//四叉树根节点
	q_tree_box root_box;//四叉树根盒子
	int * word_book;//四叉树字典

	quad_tree();
	~quad_tree();

	//设置四叉树
	void set_quad_tree(int lever);
	//创建四叉树
	q_tree * create_quad_tree(int * lever, q_tree_box root_box);
	//破坏四叉树
	void destroy_quad_tree(q_tree *& root);
	//前序遍历四叉树
	void pre_quad_tree(q_tree * root);

	//获取对象所在片区的全部数据对象
	int get_quad_tree_date(unit_sys::Unit & target, unit_sys::Unit need_u_obj[][150], animation_elem::Animation animation[][150]);

	//加入一个对象数据
	void in_quad_tree_date(unit_sys::Unit & unit_obj, animation_elem::Animation & animation);

	//清除一个对象数据
	void clean_quad_tree_obj_date(q_tree * root, unit_sys::Unit & obj, animation_elem::Animation & anima_obj);
	//清除一个区域的四叉树数据
	void clean_quad_tree_node_date(q_tree * root, unit_sys::Unit & obj);
	//删除多余的节点（空数据节点）
	void destroy_surplus_quad_tree_node(q_tree * root);

	//获取某对象所在的区域的对象数目
	int get_quad_tree_area_obj_num(unit_sys::Unit & target_obj);
	//获取四叉树中对象的总数目
	int get_quad_tree_obj_addup();
	bool get_pos(float & x, float & y);

private:
	int tree_H_num;//四叉树的高度
	int tree_node_num;//四叉树的节点数目
	int obj_addup_num;//包含的对象总数目
	static const int object_max_num = 150;//区域最大对象数目

	static unit_sys::Unit unit_obj;
	static animation_elem::Animation animation_obj;
	static int * map_table;
	static unit_sys::Unit unit[16][object_max_num];
	static animation_elem::Animation animation[16][object_max_num];

	bool stop_in;
	int just_this, now_arr;
	int x_axis[4], y_axis[4];
	int w1, h1, w2, h2;

	static int tree_wordbook_1[6];//字典
	static int tree_wordbook_2[22];
	static int tree_wordbook_3[86];

	//创建新节点
	void create_new_node(q_tree *& root);
	//内部数据接口
	void get_date(q_tree * root);
	//划分区域
	void divesion_area(q_tree * root, q_tree_box rect_box[4]);
	//位置导向
	void guide_to_pos(q_tree *& q_pos, const float & target_x, const float & target_y, bool pos[4]);
	//加入数据
	void in_quad_tree_date(q_tree * root);
	void in_date(q_tree * root);
	//获取数据
	void get_quad_tree_date(q_tree * root);

};

#endif // !quad_tree_
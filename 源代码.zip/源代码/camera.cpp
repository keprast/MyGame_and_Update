﻿#include"camera.h"

camera::camera(int c_w, int c_h)
{
	camera_wh.camera_w = c_w;
	camera_wh.camera_h = c_h;
}

camera::~camera()
{
}

void camera::reg_player_unit_date(unit_sys::Unit_axis & pl_axis)
{
	player_axis = pl_axis;
	camera_axis.c_x = player_axis.u_x - camera_wh.camera_w / 2;
	camera_axis.c_y = player_axis.u_y - camera_wh.camera_h / 2;
	camera_axis.c_z = player_axis.u_z;
}

unit_sys::Unit_axis camera::To_camera(unit_sys::Unit_axis & u_axis)
{
	unit_sys::Unit_axis axis;
	axis.u_x = u_axis.u_x - camera_axis.c_x - 64;
	axis.u_y = u_axis.u_y - camera_axis.c_y - 64;
	axis.u_z = u_axis.u_z;
	axis.u_arc = u_axis.u_arc;
	return axis;
}

unit_sys::Unit_axis camera::player_To_camera(unit_sys::Unit & player)
{
	unit_sys::Unit_axis axis;
	axis.u_x = camera_wh.camera_w / 2 - player.wh.u_w;
	axis.u_y = camera_wh.camera_h / 2 - player.wh.u_h;
	axis.u_z = player.axis.u_z;
	axis.u_arc = player.axis.u_arc;
	return axis;
}

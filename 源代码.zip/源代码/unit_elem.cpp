﻿#include"unit_elem.h"
#include<iostream>

using std::cout;
using std::endl;

unit_elem::unit_elem()
{
	elem_head = nullptr;
	get_node = in_node = elem_head;
	unit_num = 0;
}

unit_elem::~unit_elem()
{

}

unit_elem::Unit_elem * unit_elem::create_Unit_elem(int e_num)
{
	int arr = 0;
	Unit_elem * e_head;
	Unit_elem * e_after, *e_next;

	e_node_num = e_num;
	int e_id = 0;
	e_head = nullptr;
	e_after = e_next = nullptr;
	e_next = new Unit_elem[e_num];
	while (e_num != 0)
	{
		e_num--;
		if (e_head == nullptr) {
			e_head = &e_next[arr];
			get_node = in_node = e_head;
			e_next->next_elem = nullptr;
			e_next->after_elem = nullptr;
			e_next->e_node_id = e_id;
		}
		else {
			arr += 1;
			e_after->next_elem = &e_next[arr];
			e_next[arr].after_elem = e_after;
			e_next[arr].e_node_id = ++e_id;
			e_next[arr].next_elem = nullptr;
		}
		e_next[arr].has_date = NULL;
		e_next[arr].date.state.u_pid = -1;
		e_after = &e_next[arr];
	}
	elem_tail = e_next;

	return e_head;
}

void unit_elem::create_new_node()
{
	Unit_elem * new_node = new Unit_elem;
	e_node_num += 1;

	new_node->has_date = NULL;
	elem_tail->next_elem = new_node;
	new_node->after_elem = elem_tail;
	new_node->next_elem = nullptr;
	new_node->e_node_id = elem_tail->e_node_id + 1;
	elem_tail = new_node;
}

void unit_elem::create_an_node(Unit_elem * e_head, int node_id)
{
	while (e_head)
	{
		if (e_head->e_node_id == node_id) {
			Unit_elem * new_node = new Unit_elem;

			new_node->has_date = NULL;
			e_head->next_elem = new_node;
			new_node->after_elem = e_head;
			if (e_head->next_elem == nullptr)new_node->next_elem = nullptr;
			else new_node->next_elem = e_head->next_elem;
			e_node_num += 1;
		}
		if (e_head->next_elem == nullptr)
			break;
		e_head = e_head->next_elem;
	}
}

void unit_elem::init_order_flg()
{
	order_pos = 0;
}

bool unit_elem::get_Unit_elem_order_date(Unit_elem * e_head, unit_sys::Unit & unit)
{
	while (e_head)
	{
		if (!e_head->has_date)
			return false;
		if (e_head->e_node_id == order_pos) {
			unit = e_head->date;
			order_pos++;
			return true;
		}
		if (e_head->next_elem)
			e_head = e_head->next_elem;
		else
			break;
	}
	return false;
}

int unit_elem::get_order_flg()
{
	return order_pos;
}

void unit_elem::get_Unit_elem_date(int u_pid, Unit_elem * e_head, unit_sys::Unit & need_date)
{
	while (e_head)
	{
		if (e_head->date.state.u_pid == u_pid && e_head->has_date) {
			need_date = e_head->date;
			break;
		}
		if (!e_head->next_elem)
			break;
		e_head = e_head->next_elem;
	}
}

void unit_elem::get_Unit_elem_arr_date(Unit_elem * e_head, unit_sys::Unit need_date[])
{
	if (e_head) {
		for (int i = 0; i < e_node_num; i++)
		{
			if (e_head->has_date)
				need_date[i] = e_head->date;
			if (!e_head->next_elem)
				break;
			e_head = e_head->next_elem;
		}
	}
	else
		cout << "该单元线性链表不存在对象！" << endl;
}

int unit_elem::in_Unit_elem_date_is_null(Unit_elem * e_head, unit_sys::Unit & in_date)
{
	if (!e_head)return -1;//不存在该表
	while (e_head)
	{
		if (e_head->has_date == NULL) {
			e_head->date = in_date;
			e_head->has_date = true;
			unit_num += 1;
			return 1;//成功
		}
		if (!e_head->next_elem)
			break;
		e_head = e_head->next_elem;
	}
	return 0;//无空位置
}

void unit_elem::in_Unit_elem_date(int e_id, Unit_elem * e_head, unit_sys::Unit & in_date)
{
	while (e_head)
	{
		if (e_head->e_node_id == e_id) {
			e_head->date = in_date;
			e_head->has_date = true;
			if (!e_head->has_date)
				unit_num += 1;
			break;
		}
		if (!e_head->next_elem)
			break;
		e_head = e_head->next_elem;
	}
}

void unit_elem::clean_Unit_elem(Unit_elem * e_head)
{
	unit_num = 0;
	while (e_head)
	{
		e_head->has_date = NULL;
		if (e_head->next_elem == nullptr)
			break;
		e_head = e_head->next_elem;
	}
}

void unit_elem::clean_Unit_elem_node(Unit_elem * e_head, unit_sys::Unit & obj)
{
	while (e_head)
	{
		if (e_head->date.state.u_pid == obj.state.u_pid) {
			e_head->has_date = NULL;
			unit_num -= 1;
			break;
		}
		if (e_head->next_elem == nullptr)
			break;
		e_head = e_head->next_elem;
	}
}

void unit_elem::destroy_Unit_elem(Unit_elem *& e_head)
{
	if (e_head) {
		Unit_elem * after_e = nullptr;
		if (e_head->next_elem) {
			while (e_head->next_elem)
			{
				delete after_e;
				after_e = nullptr;
				after_e = e_head;
				e_head = e_head->next_elem;
			}
			delete after_e;
			after_e = nullptr;
		}
		else
		{
			delete e_head;
			e_head = nullptr;
		}
	}
}

void unit_elem::destroy_an_node(Unit_elem * e_head, int node_id)
{
	while (e_head)
	{
		if (e_head->e_node_id == node_id) {
			if (e_head == elem_head) {
				elem_head = e_head->next_elem;
				e_head->next_elem->after_elem = nullptr;
				delete e_head;
				e_head = nullptr;
				e_node_num -= 1;
				break;
			}
			if (e_head == elem_tail) {
				elem_tail = elem_tail->after_elem;
				elem_tail->after_elem->next_elem = nullptr;
				delete e_head;
				e_head = nullptr;
				e_node_num -= 1;
				break;
			}
			e_head->next_elem->after_elem = e_head->after_elem;
			e_head->after_elem->next_elem = e_head->next_elem;
			delete e_head;
			e_head = nullptr;
			e_node_num -= 1;
			break;
		}
		if (e_head->next_elem == nullptr)
			break;
		e_head = e_head->next_elem;
	}
}

void unit_elem::pre_order_elem(Unit_elem * e_head)
{
	while (e_head)
	{
		get_node_date(e_head);
		if (e_head->next_elem == nullptr)break;
		e_head = e_head->next_elem;
	}
}

void unit_elem::lrd_order_elem(Unit_elem * e_tail)
{
	while (e_tail)
	{
		get_node_date(e_tail);
		if (e_tail->after_elem == nullptr)
			break;
		e_tail = e_tail->after_elem;
	}
}

bool unit_elem::Unit_elem_is_state(Unit_elem * e_head)
{
	bool e_state = false;
	while (e_head)
	{
		if (e_head->has_date == NULL) {
			e_state = true;
			break;
		}
		e_head = e_head->next_elem;
	}
	return e_state;
}

int unit_elem::get_e_node_num()
{
	return e_node_num;
}

void unit_elem::get_node_date(Unit_elem * e_tail)
{

}
﻿#include"controller.h"
#include"association.h"
#include<iostream>

using std::cout;
using std::endl;

controller::controller(int obj_num, int t_i, int t_j)
{
	now_windows = Gui_sys::INDEX;//默认窗口为主界面
	set_tra_obj_num(t_i, t_j);
}

controller::~controller()
{
	delete[] transiting;
}

int controller::windows_pos_transition()
{
	static association::Assoc_win * win_pos;
	get_win_assoc_date(win_pos);

	if (win_pos[0].in_assoc) {
		now_windows = win_pos[0].windows_id;
		switch (now_windows)
		{
		case Gui_sys::INDEX:
			return 0;
		case Gui_sys::INDEX_About:
			return 1;
		case Gui_sys::INDEX_Config:
			return 2;
		case Gui_sys::INDEX_StaGame:
			return 3;
		case Gui_sys::INDEX_StaGames:
			return 4;
		}
	}
	else
		return now_windows;
	return -1;
}

void controller::register_ai_date()
{

}

controller::Tran_id_plus * controller::get_service_state()
{
	return transiting;
}

void controller::set_now_windows(int w_pos)
{
	now_windows = w_pos;
}

int controller::get_now_windows()
{
	return now_windows;
}

void controller::reg_date_in_gui(int w_pos, player_sys::Player_opertion & pdate)//需要修改
{
	temp_pdate = pdate;
	value = { 0,0 };
	//获取窗口数据
	get_ST_elem_date(w_pos, elem_head, tran);

	switch (w_pos)
	{
	case 0://主页
		key_value_transition_for_mouse();//转换键值
		Button();
		break;
	case 1://关于
		key_value_transition_for_mouse();//转换键值
		Button();
		break;
	case 2://帮助
		key_value_transition_for_mouse();//转换键值
		Button();
		break;
	case 3:
		break;
	case 4:
		break;
	}
}

void controller::reg_date_in_gui()
{
	value = { 0,0 };
	get_ST_elem_date(now_windows, elem_head, tran);//获取窗口数据

	switch (now_windows)
	{
	case 0:
		Button();
		break;
	case 1:
		Button();
		break;
	case 2:
		Button();
		break;
	}
}

void controller::init_index_logic()
{
	init_transition(0, 6);


	init_tra_other_act_num(0, 0, 1);
	set_tra_df_action_id(0, 0, 0, BAXIS, 0, 0, 0);


	init_tra_other_act_num(0, 1, 1);
	set_tra_df_action_id(0, 1, 0, BAXIS, 1, 0, 0);


	init_tra_other_act_num(0, 2, 1);
	set_tra_df_action_id(0, 2, 0, BAXIS, 2, 0, 0);
	set_tra_for_axis(0, 2, 0, 2, 1, 200, 200, 400, 250);
	set_tra_action_lever_for_axis(0, 2, 0, 1);
	set_tra_for_button(0, 2, 0, BAXIS, 1);
	set_button_pos(0, 2, 0, BAXIS, 0, 2, 2);
	set_button_value(0, 2, 0, BAXIS, 0, MOUSE_L_BUTTON_DOWN);
	set_tra_action_lever_for_button(0, 2, 0, BAXIS, 0, 2);
	set_button_ass_win(0, 2, 0, BAXIS, 0, false, 3);


	init_tra_other_act_num(0, 3, 1);
	set_tra_df_action_id(0, 3, 0, BAXIS, 3, 0, 0);
	set_tra_for_axis(0, 3, 0, 3, 1, 200, 325, 400, 375);
	set_tra_action_lever_for_axis(0, 3, 0, 1);
	set_tra_for_button(0, 3, 0, BAXIS, 1);
	set_button_pos(0, 3, 0, BAXIS, 0, 3, 2);
	set_button_value(0, 3, 0, BAXIS, 0, MOUSE_L_BUTTON_DOWN);
	set_tra_action_lever_for_button(0, 3, 0, BAXIS, 0, 2);
	set_button_ass_win(0, 3, 0, BAXIS, 0, false, 4);


	init_tra_other_act_num(0, 4, 1);
	set_tra_df_action_id(0, 4, 0, BAXIS, 4, 0, 0);
	set_tra_for_axis(0, 4, 0, 4, 1, 200, 450, 400, 500);
	set_tra_action_lever_for_axis(0, 4, 0, 1);
	set_tra_for_button(0, 4, 0, BAXIS, 1);
	set_button_pos(0, 4, 0, BAXIS, 0, 4, 2);
	set_button_value(0, 4, 0, BAXIS, 0, MOUSE_L_BUTTON_DOWN);
	set_tra_action_lever_for_button(0, 4, 0, BAXIS, 0, 2);
	set_button_ass_win(0, 4, 0, BAXIS, 0, false, 1);


	init_tra_other_act_num(0, 5, 1);
	set_tra_df_action_id(0, 5, 0, BAXIS, 5, 0, 0);
	set_tra_for_axis(0, 5, 0, 5, 1, 200, 575, 400, 625);
	set_tra_action_lever_for_axis(0, 5, 0, 1);
	set_tra_for_button(0, 5, 0, BAXIS, 1);
	set_button_pos(0, 5, 0, BAXIS, 0, 5, 2);
	set_button_value(0, 5, 0, BAXIS, 0, MOUSE_L_BUTTON_DOWN);
	set_tra_action_lever_for_button(0, 5, 0, BAXIS, 0, 2);
	set_button_ass_win(0, 5, 0, BAXIS, 0, false, 2);


	in_ST_elem_date(0, elem_head, *get_transition(0));
}

void controller::init_index_about_logic()
{
	init_transition(1, 2);

	init_tra_other_act_num(1, 0, 1);
	set_tra_df_action_id(1, 0, 0, BAXIS, 0, 0, 0);

	init_tra_other_act_num(1, 1, 1);
	set_tra_df_action_id(1, 1, 0, BAXIS, 1, 0, 0);
	set_tra_for_axis(1, 1, 0, 1, 1, 1180, 620, 1280, 720);
	set_tra_action_lever_for_axis(1, 1, 0, 1);
	set_tra_for_button(1, 1, 0, BAXIS, 1);
	set_button_pos(1, 1, 0, BAXIS, 0, 1, 2);
	set_button_value(1, 1, 0, BAXIS, 0, MOUSE_L_BUTTON_DOWN);
	set_tra_action_lever_for_button(1, 1, 0, BAXIS, 0, 2);
	set_button_ass_win(1, 1, 0, BAXIS, 0, false, 0);


	in_ST_elem_date(1, elem_head, *get_transition(1));
}

void controller::init_index_config_logic()
{
	init_transition(2, 2);

	init_tra_other_act_num(2, 0, 1);
	set_tra_df_action_id(2, 0, 0, BAXIS, 0, 0, 0);

	init_tra_other_act_num(2, 1, 1);
	set_tra_df_action_id(2, 1, 0, BAXIS, 1, 0, 0);
	set_tra_for_axis(2, 1, 0, 1, 1, 1180, 620, 1280, 720);
	set_tra_action_lever_for_axis(2, 1, 0, 1);
	set_tra_for_button(2, 1, 0, BAXIS, 1);
	set_button_pos(2, 1, 0, BAXIS, 0, 1, 2);
	set_button_value(2, 1, 0, BAXIS, 0, MOUSE_L_BUTTON_DOWN);
	set_tra_action_lever_for_button(2, 1, 0, BAXIS, 0, 2);
	set_button_ass_win(2, 1, 0, BAXIS, 0, false, 0);


	in_ST_elem_date(2, elem_head, *get_transition(2));
}

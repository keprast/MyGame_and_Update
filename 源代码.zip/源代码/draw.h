#ifndef draw_
#define draw_

#include"Gui_sys.h"
#include"map_sys.h"

#endif

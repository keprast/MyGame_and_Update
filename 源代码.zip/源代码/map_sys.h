﻿#ifndef map_sys_
#define map_sys_

#include"allegro5\allegro.h"
#include"allegro5\allegro_image.h"
#include"animation_sys.h"
#include"quad_tree.h"
#include"unit_sys.h"
#include"player_sys.h"
#include"player_state.h"
#include"ai_state.h"
#include"camera.h"
#include<string>

using std::string;

//这是游戏的主体类
//首先根据本游戏的很多特殊情况，我们把地图切割为n份
//且存在多层次结构
class Map_sys :public animation_sys, public quad_tree
{
public:
	struct Life_pos_state
	{
		int life_on_x;//复活点x
		int life_on_y;//复活点y
		int life_to_x;//
		int life_to_y;//
	};

	struct Map_date
	{
		int map_z;//该地图所在层级
		int team_num;//包含的队伍数目
		string name;//地图的名字
		int * map_table;//地图表格
		float map_max_x;//地图x轴最大值
		float map_max_y;//地图y轴最大值
		quad_tree * map;
		Life_pos_state * life_pos_state;
	};

	Map_sys(int z = 0, float x_max = 0, float y_max = 0, string name = "null");
	~Map_sys();

	//翻转重新设置标记
	void flip_reset();

	//初始化地图背景
	void init_map_context(Map_sys & map_context, unit_elem & context, animation_elem & context_animation);
	//初始化地图单元
	void init_map_unit(Map_sys & map_unit, unit_elem & unit, animation_elem & unit_animation);
	//注册玩家数据在地图中
	void reg_player_date_in_map(player_sys::Player_opertion & pdate, unit_sys::Unit & punit);
	//更新地图数据
	void update_map_date(player_sys & player, ai_state & ai_ste);
	//获取地图数据
	Map_date & get_map_date();
	//获取全部地图名字
	string * get_map_name();
	//获取全部地图数目
	int get_map_num();
	//更新动画数据
	void update_map_animation(Map_sys & map_context, Map_sys & map_unit, unit_elem & player_date, animation_elem & player_aniamtion/*, unit_elem & ai_date, animation_elem & ai_aniamtion*/, camera & car);
	//初始化计时器
	void init_map_timer(Animation_elem_flags flg);
	//绘制对象
	void MapContext_draw_object();
	void MapUnit_draw_object();
	void Spriti_draw_object();
	//设定地图表格
	void set_map_table(int map_size, int *& table);

private:
	//重新设定
	static bool reset;

	player_sys::Player_opertion player_date;
	player_sys::Player_opertion left_player_date;
	unit_sys::Unit player_unit;

	Map_date Map;
	Animation draw_object;

	static const int map_num = 2;
	static string map_name[map_num];

	//初始化队伍数目
	void init_team_num(string name);
	//初始化队伍复活点
	void init_life_pos(string name);
	//获取玩家视野范围
	unit_sys::Unit get_player_see_area(unit_sys::Unit & unit);

	//注册逻辑至框架系统
	void reg_logic_to_event_queue(Animation & animation);

};

#endif
/*
地图的数据分为多个部分
主要为三个部分：
地图本身（贴图背景）
地图可操作单元（如载具，门或箱子等具有实体的物体）
玩家和电脑单元
-----------------------
ps：
除贴图背景，都将进行物理判断
当载具实体被玩家或电脑操控时，将会从中剔除并替换电脑或玩家单元表中的数据，而原有的数据将加入不同的缓冲表中
当门被玩家或电脑操控时，将会改变门在可操作单元中的数据
*/
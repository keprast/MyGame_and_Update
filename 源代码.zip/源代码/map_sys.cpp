﻿#include"map_sys.h"
#include<iostream>

using std::cout;
using std::endl;

bool Map_sys::reset = false;

string Map_sys::map_name[2]
{ 
"test",
"fire_island" 
};

Map_sys::Map_sys(int z, float x_max, float y_max, string name)
{
	if (x_max != 0 && y_max != 0) {
		Map.map_z = z;
		Map.name = name;
		Map.map_table = nullptr;
		Map.life_pos_state = nullptr;
		init_team_num(name);
		Map.map_max_x = x_max;
		Map.map_max_y = y_max;
		Map.map = new quad_tree;
		init_life_pos(name);

		Map.map->root_box.on_box_x = 0;
		Map.map->root_box.on_box_y = 0;
		Map.map->root_box.to_box_x = Map.map_max_x;
		Map.map->root_box.to_box_y = Map.map_max_y;

		set_quad_tree(2);
		root = create_quad_tree(word_book, Map.map->root_box);
	}
}

Map_sys::~Map_sys()
{
}

void Map_sys::flip_reset()
{
	if (reset == true)
		reset = false;
	else
		reset = true;
}

void Map_sys::init_map_context(Map_sys & map_context, unit_elem & context, animation_elem & context_animation)
{
	unit_sys::Unit unit;
	Animation animation;
	//将地图背景加入地图
	int map_context_num = context.get_e_node_num();
	context.init_order_flg();
	context_animation.init_order_flg();
	for (int i = 0; i < map_context_num; i++)
	{
		context.get_Unit_elem_order_date(context.elem_head, unit);
		context_animation.get_Animation_elem_order_date(context_animation.elem_head, animation);
		map_context.in_quad_tree_date(unit, animation);//加入四叉树存在bug
	}
/*	int ai_obj_num = ai_unit.get_e_node_num();
	for (int i = 0; i < ai_obj_num; i++)
	{
		unit.state.u_pid = -1;
		animation.bitmap_id = -1;
		ai_unit.get_Unit_elem_date(i, ai_unit.elem_head, unit);
		ai_animation.get_Animation_elem_date(i, ai_animation.elem_head, animation);
		if (unit.state.u_pid == -1 || animation.bitmap_id == -1)
			break;
		map_date.in_quad_tree_date(map_date.root, unit, animation);
	}*/
}

void Map_sys::init_map_unit(Map_sys & map_unit, unit_elem & unit, animation_elem & unit_animation)
{
	unit_sys::Unit tunit;
	Animation tanimation;
	//将地图单元加入地图
	int map_unit_num = unit.get_e_node_num();
	unit.init_order_flg();
	unit_animation.init_order_flg();
	for (int i = 0; i < map_unit_num; i++)
	{
		unit.get_Unit_elem_order_date(unit.elem_head, tunit);
		unit_animation.get_Animation_elem_order_date(unit_animation.elem_head, tanimation);
		map_unit.in_quad_tree_date(tunit, tanimation);//加入四叉树存在bug
	}
}

void Map_sys::reg_player_date_in_map(player_sys::Player_opertion & pdate, unit_sys::Unit & punit)
{
	player_date = pdate;
	player_unit = punit;
}

void Map_sys::update_map_date(player_sys & player, ai_state & ai_ste)
{
	//在此加入将单元的数据更新于四叉树阵列中
}

Map_sys::Map_date & Map_sys::get_map_date()
{
	return Map;
}

string * Map_sys::get_map_name()
{
	return map_name;
}

int Map_sys::get_map_num()
{
	return map_num;
}

void Map_sys::update_map_animation(Map_sys & map_context, Map_sys & map_unit, unit_elem & player_date, animation_elem & player_aniamtion/*, unit_elem & ai_date*/, camera & car)
{
	static int animation_elem_pos;
	static unit_sys::Unit context_unit[16][150];
	static unit_sys::Unit unit[16][150];
	static unit_sys::Unit p_unit[2];
	static animation_elem::Animation context_animation[16][150];
	static animation_elem::Animation unit_animation[16][150];
	static animation_elem::Animation pla_animation[2];
	static unit_sys::Unit target_area;
	static unit_sys::Unit player_car_unit;
	static int context_size, unit_size;
	animation_elem_pos = 0;

	target_area = map_context.get_player_see_area(player_unit);
	player_aniamtion.get_Animation_elem_arr_date(player_aniamtion.elem_head, pla_animation);
	context_size = map_context.get_quad_tree_date(target_area, context_unit, context_animation);
	unit_size = map_unit.get_quad_tree_date(target_area, unit, unit_animation);

	//////转换为相机坐标
	car.reg_player_unit_date(player_unit.axis);
	player_car_unit = player_unit;
	player_car_unit.axis = car.player_To_camera(player_unit);

	for (int i = 0; i < context_size; i++)
	{
		for (int j = 0; j < 50; j++)
		{
			if (context_unit[i][j].state.u_pid == -1)//可能无数据
				continue;
			context_unit[i][j].axis = car.To_camera(context_unit[i][j].axis);//转换为相机坐标
		}
	}
	for (int i = 0; i < unit_size; i++)
	{
		for (int j = 0; j < 50; j++)
		{
			if (unit[i][j].state.u_pid == -1)//可能无数据
				continue;
			unit[i][j].axis = car.To_camera(unit[i][j].axis);//转换为相机坐标
		}
	}
	static unit_sys::Unit pla_unit;
	int player_num = player_date.get_e_node_num();
	player_date.init_order_flg();
	for (int i = 0; i < player_num; i++)
	{
		player_date.get_Unit_elem_order_date(player_date.elem_head, pla_unit);
		if (pla_unit.state.u_pid != player_unit.state.u_pid)
			p_unit[i].axis = car.To_camera(pla_unit.axis);
		else
			p_unit[i].axis = player_car_unit.axis;
	}
	//////

	for (int i = 0; i < context_size; i++)//将坐标赋予地图背景
	{
		if (context_unit[i][0].state.u_pid == -1)//剔除无意义对象
			continue;
		for (int j = 0; j < 50; j++)
		{
			if (context_unit[i][j].state.u_pid == -1)//剔除无效对象
				continue;
			for (int k = 0; k < context_animation[i][j].bitmap_obj_num; k++)
			{
				for (int L = 0; L < context_animation[i][j].bmp[k].action_num; L++)
				{
					context_animation[i][j].bmp[k].action[L].axis->b_x = context_unit[i][j].axis.u_x;
					context_animation[i][j].bmp[k].action[L].axis->b_y = context_unit[i][j].axis.u_y;
					context_animation[i][j].bmp[k].action[L].axis->b_arc = context_unit[i][j].axis.u_arc;
				}
			}
			in_Animation_elem_date_is_null(get_elem(MapContext_ELEM), context_animation[i][j]);
		}
	}
	for (int i = 0; i < unit_size; i++)//将坐标赋予地图单元
	{
		if (unit[i][0].state.u_pid == -1)//剔除无意义对象
			continue;
		for (int j = 0; j < 50; j++)
		{
			if (unit[i][j].state.u_pid == -1)//剔除无效对象
				continue;
			for (int k = 0; k < unit_animation[i][j].bitmap_obj_num; k++)
			{
				for (int L = 0; L < unit_animation[i][j].bmp[k].action_num; L++)
				{
					unit_animation[i][j].bmp[k].action[L].axis->b_x = unit[i][j].axis.u_x;
					unit_animation[i][j].bmp[k].action[L].axis->b_y = unit[i][j].axis.u_y;
					unit_animation[i][j].bmp[k].action[L].axis->b_arc = unit[i][j].axis.u_arc;
				}
			}
			in_Animation_elem_date_is_null(get_elem(MapUnit_ELEM), unit_animation[i][j]);
		}
	}
	for (int i = 0; i < player_num; i++)
	{
		for (int j = 0; j < pla_animation[i].bitmap_obj_num; j++)
		{
			for (int k = 0; k < pla_animation[i].bmp[j].action_num; k++)
			{
				pla_animation[i].bmp[j].action[k].axis->b_x = p_unit[i].axis.u_x;
				pla_animation[i].bmp[j].action[k].axis->b_y = p_unit[i].axis.u_y;
				pla_animation[i].bmp[j].action[k].axis->b_arc = p_unit[i].axis.u_arc;
			}
		}
		in_Animation_elem_date_is_null(get_elem(PlayerSpriti_ELEM), pla_animation[i]);
	}
/*	for (int i = 0; i < ai_num; i++)
	{
		for (int j = 0; j < p_animation[i].bitmap_obj_num; j++)
		{
			for (int k = 0; k < p_animation[i].bmp[j].action_num; k++)
			{
				p_animation[i].bmp[j].action[k].axis->b_x = p_unit[i].axis.u_x;
				p_animation[i].bmp[j].action[k].axis->b_y = p_unit[i].axis.u_y;
				p_animation[i].bmp[j].action[k].axis->b_arc = p_unit[i].axis.u_arc;
			}
		}
		in_Animation_elem_date_is_null(get_elem(PlayerSpriti_ELEM), unit_animation[i][i]);
	}*/
}

void Map_sys::init_map_timer(Animation_elem_flags flg)
{
	static int obj_num;
	obj_num = get_have_date_num(get_elem(flg));

	if (reset) {
		
	}
}

void Map_sys::MapContext_draw_object()
{
	int obj_num = get_have_date_num(get_elem(MapContext_ELEM));

	init_order_flg();
	for (int i = 0; i < obj_num; i++)
	{
		get_Animation_elem_order_date(get_elem(MapContext_ELEM), draw_object);
		for (int j = 0; j < draw_object.bitmap_obj_num; j++)
		{
			if (!draw_object.bmp[j].non_obj) {
				al_draw_rotated_bitmap(draw_object.bmp[j].animations->get_bitmap(draw_object.bmp[j].now_arr),
					draw_object.bmp[j].bitmap_wh[draw_object.bmp[j].now_arr].bitmap_w / 2.0,
					draw_object.bmp[j].bitmap_wh[draw_object.bmp[j].now_arr].bitmap_h / 2.0,
					draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].axis->b_x +
					draw_object.bmp[j].bitmap_wh[draw_object.bmp[j].now_arr].bitmap_w / 2.0,
					draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].axis->b_y +
					draw_object.bmp[j].bitmap_wh[draw_object.bmp[j].now_arr].bitmap_h / 2.0,
					draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].axis->b_arc,
					ALLEGRO_VIDEO_BITMAP);
			}
			if (draw_object.bmp[j].action[draw_object.bmp[j].in_acting_id].flags->d_arr
				== draw_object.bmp[j].now_arr || draw_object.bmp[j].non_obj) {
				draw_object.bmp[j].have_action = false;
				draw_object.bmp[j].draw_OK = true;
			}
		}
		in_Animation_elem_date_is_null(get_elem(MapContext_ELEM), draw_object);
	}
}

void Map_sys::MapUnit_draw_object()
{
	animation_draw_object(MapUnit_ELEM);
}

void Map_sys::Spriti_draw_object()
{
	//animation_draw_object(AiSpriti_ELEM);
	animation_draw_object(PlayerSpriti_ELEM);
}

void Map_sys::set_map_table(int map_size, int *& table)
{
	Map.map_table = new int[map_size];
	for (int i = 0; i < map_size; i++)
		Map.map_table[i] = table[i];
}

void Map_sys::init_team_num(string name)
{
	if (map_name[0].compare(name) == 0)
		Map.team_num = 2;
	else if (map_name[1].compare(name) == 0)
		Map.team_num = 2;
}

void Map_sys::init_life_pos(string name)
{
	Map.life_pos_state = new Life_pos_state[Map.team_num];
	if (map_name[0].compare(name) == 0) {
		Map.life_pos_state[0].life_on_x = 0;
		Map.life_pos_state[0].life_on_y = 64 * 3;
		Map.life_pos_state[0].life_to_x = 64 * 2;
		Map.life_pos_state[0].life_to_y = 64 * 5;

		Map.life_pos_state[1].life_on_x = 64 * 3;
		Map.life_pos_state[1].life_on_y = 0;
		Map.life_pos_state[1].life_to_x = 64 * 5;
		Map.life_pos_state[1].life_to_y = 64 * 2;
	}
	else if (map_name[1].compare(name) == 0) {

	}
}

unit_sys::Unit Map_sys::get_player_see_area(unit_sys::Unit & unit)
{
	unit_sys un;
	unit_sys::Unit area = un.get_unit();
	int mx = get_map_date().map_max_x;
	int my = get_map_date().map_max_y;
	int r = unit.see.see_area;
	int x = unit.axis.u_x + unit.wh.u_w;
	int y = unit.axis.u_y + unit.wh.u_h;
	//计算渲染距离（与视距相同）
	int dx[2], dy[2];
	dx[0] = x - r;
	dy[0] = y - r;
	dx[1] = x + r;
	dy[1] = y + r;
	//限制范围在地图范围内
	if (dx[0] < 0)
		dx[0] = 0;
	if (dy[0] < 0)
		dy[0] = 0;
	if (dx[1] > mx)
		dx[1] = mx - dx[0];
	if (dy[1] > my)
		dy[1] = my - dy[0];

	area.axis.u_x = dx[0];
	area.axis.u_y = dy[0];
	area.wh.u_w = dx[1];
	area.wh.u_h = dy[1];

	return area;
}

void Map_sys::reg_logic_to_event_queue(Animation & animation)
{
	int obj_num = animation.bitmap_obj_num;

	for (int i = 0; i < obj_num; i++)
	{
		int sub_obj_num = animation.bmp[i].animations->get_bitmap_num();
/*		for (size_t i = 0; i < length; i++)
		{

		}*/
	}
}

﻿#ifndef carmer_
#define camera_

#include"unit_sys.h"

class camera
{
public:
	struct Camera_axis
	{
		float c_x;
		float c_y;
		float c_z;
	};
	struct Camera_wh
	{
		int camera_w;
		int camera_h;
	};

	camera(int c_w, int c_h);
	~camera();

	//注册玩家数据到相机
	void reg_player_unit_date(unit_sys::Unit_axis & pl_axis);
	//转换坐标到相机（将物体转换到相机坐标）
	unit_sys::Unit_axis To_camera(unit_sys::Unit_axis & u_axis);
	//转换玩家的坐标到相机
	unit_sys::Unit_axis player_To_camera(unit_sys::Unit & player);

private:
	unit_sys::Unit_axis player_axis;
	Camera_axis camera_axis;
	Camera_wh camera_wh;

};

#endif
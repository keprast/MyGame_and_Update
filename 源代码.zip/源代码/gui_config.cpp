﻿#include"gui_config.h"
#include"debug.h"

#define FPS_ 1 / 60.0
int Gui_config::obj_num = 0;

Gui_config::Gui_config()
{
	obj_num += 1;
	bitmap_id = 0;
	bitmap_pid = 0;
	animation_num = 0;
	animation = nullptr;
}

Gui_config::~Gui_config()
{
}

void Gui_config::add_button(char * bitmap_name, Button_name name, int x, int y)
{
	stor_allocation();

	init_bitmap(bitmap_pid, 1, animation[animation_num - 1], bitmap_name);
	
	set_bitmap_pid(0, bitmap_id, animation[animation_num - 1]);
	set_bitmap_num(0, 3, animation[animation_num - 1]);
	set_bitmap_lever(1, animation[animation_num - 1]);
	set_bitmap_lever(0, 0, animation[animation_num - 1]);

	set_bitmap_name(0, 0, get_button_path(name, 0), "按钮图标", animation[animation_num - 1]);
	set_bitmap_name(0, 1, get_button_path(name, 1), "按钮触摸", animation[animation_num - 1]);
	set_bitmap_name(0, 2, get_button_path(name, 2), "按钮按下", animation[animation_num - 1]);

	set_bitmap_action_num(0, 3, animation[animation_num - 1]);

	set_bitmap_action_draw_flags(0, 0, true, false, 0, 0, 0, animation[animation_num - 1]);
	set_bitmap_action_axis(0, 0, x, y, 0, animation[animation_num - 1]);
	set_bitmap_action_times(0, 0, FPS_, animation[animation_num - 1]);

	set_bitmap_action_draw_flags(0, 1, true, false, 1, 0, 0, animation[animation_num - 1]);
	set_bitmap_action_axis(0, 1, x, y, 0, animation[animation_num - 1]);
	set_bitmap_action_times(0, 1, FPS_, animation[animation_num - 1]);

	set_bitmap_action_draw_flags(0, 2, true, false, 2, 0, 0, animation[animation_num - 1]);
	set_bitmap_action_axis(0, 2, x, y, 0, animation[animation_num - 1]);
	set_bitmap_action_times(0, 2, FPS_, animation[animation_num - 1]);

	set_bitmap_df_action_flags(0, 0, 0, animation[animation_num - 1]);

	bitmap_id++;
	bitmap_pid++;
}

void Gui_config::add_animation(char * bitmap_name, Animation_name name, int x, int y, int bitmap_num, int now, int sta, int end, double time_sec, bool whi)
{
	char * num;

	stor_allocation();

	init_bitmap(bitmap_id, 1, animation[animation_num - 1], bitmap_name);

	set_bitmap_pid(0, bitmap_pid, animation[animation_num - 1]);
	set_bitmap_num(0, bitmap_num, animation[animation_num - 1]);
	set_bitmap_lever(1, animation[animation_num - 1]);
	set_bitmap_lever(0, 0, animation[animation_num - 1]);

	for (int i = 0; i < bitmap_num; i++) {
		num = int_tran_to_char(i);
		set_bitmap_name(0, i, get_animation_path(name, i), num, animation[animation_num - 1]);
	}

	set_bitmap_action_num(0, 1, animation[animation_num - 1]);

	set_bitmap_action_draw_flags(0, 0, false, true, now, sta, end, animation[animation_num - 1], whi);
	set_bitmap_action_axis(0, 0, x, y, 0, animation[animation_num - 1]);
	set_bitmap_action_times(0, 0, time_sec, animation[animation_num - 1]);

	set_bitmap_df_action_flags(0, 0, 0, animation[animation_num - 1]);

	bitmap_id++;
	bitmap_pid++;
}

void Gui_config::add_context(char * bitmap_name, Context_name name, int x, int y)
{
	stor_allocation();

	init_bitmap(bitmap_id, 1, animation[animation_num - 1], bitmap_name);

	set_bitmap_pid(0, bitmap_pid, animation[animation_num - 1]);
	set_bitmap_num(0, 1, animation[animation_num - 1]);
	set_bitmap_lever(0, animation[animation_num - 1]);
	set_bitmap_lever(0, 0, animation[animation_num - 1]);

	set_bitmap_name(0, 0, get_context_path(name), bitmap_name, animation[animation_num - 1]);

	set_bitmap_action_num(0, 1, animation[animation_num - 1]);

	set_bitmap_action_draw_flags(0, 0, true, false, 0, 0, 0, animation[animation_num - 1]);
	set_bitmap_action_axis(0, 0, x, y, 0, animation[animation_num - 1]);
	set_bitmap_action_times(0, 0, FPS_, animation[animation_num - 1]);

	set_bitmap_df_action_flags(0, 0, 0, animation[animation_num - 1]);

	bitmap_id++;
	bitmap_pid++;
}
int Gui_config::get_obj_num()
{
	return obj_num;
}
int Gui_config::get_animation_num()
{
	return animation_num;
}
animation_sys::Animation & Gui_config::operator[](int i)
{
	return animation[i];
}
animation_sys::Animation * Gui_config::get_animation()
{
	return animation;
}
animation_sys::Animation & Gui_config::get_animation(int i)
{
	return animation[i];
}
//分配内存
void Gui_config::stor_allocation()
{
	if (animation_num != 0) {
		//创建临时对象存储旧数据
		auto animation_buffer = new animation_sys::Animation[animation_num];
		for (int i = 0; i < animation_num; i++)
			animation_buffer[i] = animation[i];
		delete[] animation;
		animation = nullptr;
		animation_num += 1;
		//将旧数据存储至新数据中
		animation = new animation_sys::Animation[animation_num];
		for (int i = 0; i < animation_num - 1; i++)
			animation[i] = animation_buffer[i];
		delete[] animation_buffer;
		animation_buffer = nullptr;
	}
	else {
		animation_num += 1;
		animation = new animation_sys::Animation[animation_num];
	}
}

char * Gui_config::get_button_path(Button_name button_name, int pos)
{
	static char path[32], *button, *name, *num, *img_type;

	button = "button";
	img_type = ".png";

	for (int i = 0; i < 32; i++)
		path[i] = '\0';
	switch (button_name)
	{
	case Gui_config::WhiteRectangle:
		name = "/WhiteRectangle/";
		break;
	case Gui_config::WhiteDiamond:
		name = "/WhiteDiamond/";
		break;
	}
	num = int_tran_to_char(pos);
	strcat_s(path, button);
	strcat_s(path, name);
	strcat_s(path, num);
	strcat_s(path, img_type);

	return path;
}

char * Gui_config::get_animation_path(Animation_name animation_name, int pos)
{
	static char path[32], *animation, *name, *num, *img_type;

	animation = "context/animation";
	img_type = ".png";

	for (int i = 0; i < 32; i++)
		path[i] = '\0';
	switch (animation_name)
	{
	case Gui_config::Frie:
		name = "/fire/";
		break;
	}
	num = int_tran_to_char(pos);
	strcat_s(path, animation);
	strcat_s(path, name);
	strcat_s(path, num);
	strcat_s(path, img_type);

	return path;
}

char * Gui_config::get_context_path(Context_name context_name)
{
	static char path[32], *context, *name, *img_type;

	context = "context/";
	img_type = ".png";

	for (int i = 0; i < 32; i++)
		path[i] = '\0';
	switch (context_name)
	{
	case Gui_config::index:
		name = "index";
		break;
	case Gui_config::about:
		name = "about";
		break;
	case Gui_config::config:
		name = "config";
		break;
	}
	strcat_s(path, context);
	strcat_s(path, name);
	strcat_s(path, img_type);

	return path;
}

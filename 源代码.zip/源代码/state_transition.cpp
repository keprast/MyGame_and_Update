﻿#include"state_transition.h"
#include<iostream>

using std::cout;
using std::endl;

int state_transition::now_windows = -1;

state_transition::state_transition()
{
	elem_head = create_ST_elem(windows_num);
	transiting = nullptr;
}

state_transition::~state_transition()
{
	destroy_ST_elem(elem_head);
}

void state_transition::set_tra_obj_num(int obj_num, int sub_obj_num)
{
	tra_obj_num = obj_num;
	tra_sub_obj_num = sub_obj_num;
	transiting = new Tran_id_plus[obj_num];
	for (int i = 0; i < obj_num; i++) {
		transiting[i].tran_id_num = sub_obj_num;
		transiting[i].tra_sub_obj = new Tran_id[sub_obj_num];
	}
}

int state_transition::get_TS_num()
{
	return tra_obj_num;
}

int state_transition::get_TS_sub_num()
{
	return tra_sub_obj_num;
}

state_transition::Transition_op_to_anima & state_transition::get_tran()
{
	return tran;
}

//键值转换器（鼠标）
void state_transition::key_value_transition_for_mouse()
{
	if (temp_pdate.mouse.left)value.m_value += 1;
	if (temp_pdate.mouse.right)value.m_value += 10;
}
//键值转换器（键盘）
void state_transition::key_value_transition_for_keybord()
{
	if (temp_pdate.keybords.key_w)value.k_value += 100;
	if (temp_pdate.keybords.key_s)value.k_value += 1000;
	if (temp_pdate.keybords.key_a)value.k_value += 10000;
	if (temp_pdate.keybords.key_d)value.k_value += 100000;
	if (temp_pdate.keybords.key_r)value.k_value += 1000000;
}
//初始化转换器并设定触发窗口id
void state_transition::init_transition(int w_id, int obj_num)
{
	set_tran[w_id] = new Transition_op_to_anima;
	set_tran[w_id]->windows_id = w_id;
	set_tran[w_id]->action_count_num = 0;
	set_tran[w_id]->act_obj_num = obj_num;
	set_tran[w_id]->act_obj = new Transition[obj_num];
	for (int i = 0; i < obj_num; i++) {
		set_tran[w_id]->act_obj[i].sub_action_num = 0;
		set_tran[w_id]->act_obj[i].sub_action = nullptr;
	}
}

void state_transition::set_tra_df_action_id(int w_id, int obj_id, int act_id, T_POS pos, int b_id, int a_id, int lev)
{
	if (set_tran[w_id]->act_obj[obj_id].sub_action) {
		if (pos == BAXIS) {
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].df_action_id->to_bitmap_id = b_id;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].df_action_id->to_acting_id = a_id;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].df_action_id->lever = lev;
		}
	}
	else
		cout << "set_tra_df_action_id" << "函数使用错误！" << endl;
}

void state_transition::init_tra_other_act_num(int w_id, int obj_id, int act_num)
{
	set_tran[w_id]->act_obj[obj_id].sub_action_num += act_num;
	set_tran[w_id]->act_obj[obj_id].sub_action = new Animation_tra[act_num];

	for (int i = 0; i < act_num; i++)//初始化
	{
		set_tran[w_id]->act_obj[obj_id].sub_action[i].other_Act = false;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].df_action_id = new Tran_id;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].axis_button = nullptr;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].assoc_bmp = nullptr;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].has_assoc_bmp = false;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].button = false;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].button_num = 0;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].on_t_x = -1;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].on_t_y = -1;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].to_t_x = -1;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].to_t_y = -1;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].action_id = new Tran_id;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].action_id->assoc_lock = false;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].action_id->assoc_winid = -1;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].action_id->pid = -1;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].action_id->to_acting_id = -1;
		set_tran[w_id]->act_obj[obj_id].sub_action[i].action_id->to_bitmap_id = -1;
	}
}

void state_transition::set_tra_action_lever_for_button(int w_id, int obj_id, int act_id, T_POS pos, int butt_arr, int lev)
{
	if (pos == BAXIS) {
		set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button->action_id->lever = lev;
	}
}

void state_transition::set_tra_action_lever_for_axis(int w_id, int obj_id, int act_id, int lev)
{
	set_tran[w_id]->act_obj[obj_id].sub_action[act_id].action_id->lever = lev;
}
//设定坐标触发位置（obj_id为操作位，一个位图结构只能有一个操作位）
void state_transition::set_tra_for_axis(int w_id, int obj_id, int act_id, int b_id, int a_id, float on_x, float on_y, float to_x, float to_y)
{
	set_tran[w_id]->act_obj[obj_id].sub_action[act_id].other_Act = true;
	set_tran[w_id]->act_obj[obj_id].sub_action[act_id].action_id->to_bitmap_id = b_id;
	set_tran[w_id]->act_obj[obj_id].sub_action[act_id].action_id->to_acting_id = a_id;
	set_tran[w_id]->act_obj[obj_id].sub_action[act_id].on_t_x = on_x;
	set_tran[w_id]->act_obj[obj_id].sub_action[act_id].on_t_y = on_y;
	set_tran[w_id]->act_obj[obj_id].sub_action[act_id].to_t_x = to_x;
	set_tran[w_id]->act_obj[obj_id].sub_action[act_id].to_t_y = to_y;
}

//初始化按钮（pos为按钮的位置）
void state_transition::set_tra_for_button(int w_id, int obj_id, int act_id, T_POS pos, int b_num)
{
	if (pos == BAXIS) {
		set_tran[w_id]->act_obj[obj_id].sub_action[act_id].button = true;
		set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button = new Button_s[b_num];
		set_tran[w_id]->act_obj[obj_id].sub_action[act_id].button_num = b_num;
		for (int i = 0; i < b_num; i++) {
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[i].action_id = new Tran_id;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[i].action_id->to_bitmap_id = -1;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[i].action_id->to_acting_id = -1;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[i].button_value = 0;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[i].has_assoc_bmp = false;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[i].has_assoc_win = false;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[i].assoc_windows_id = -1;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[i].assoc_windows_lock = false;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[i].assoc_bmp = nullptr;
		}
	}
}
//设定按钮的位置和触发的位置
void state_transition::set_button_pos(int w_id, int obj_id, int act_id, T_POS pos, int b_arr, int b_id, int a_id)
{
	if (set_tran[w_id]->act_obj[obj_id].sub_action[act_id].button) {
		if (pos == BAXIS) {
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[b_arr].action_id->to_bitmap_id = b_id;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[b_arr].action_id->to_acting_id = a_id;
		}
	}
	else {
		cout << "按钮设定错误！位置：" << "窗口" << w_id << "obj_id" << obj_id << "act_id" << act_id << endl;
		cout << "可能未初始化" << endl;
	}
}
//设定按钮的键值
void state_transition::set_button_value(int w_id, int obj_id, int act_id, T_POS pos, int button_arr, Button_value b_val)
{
	if (set_tran[w_id]->act_obj[obj_id].sub_action[act_id].button) {
		if (pos == BAXIS) {
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[button_arr].button_value = b_val;
		}
	}
	else {
		cout << "按钮设定错误！位置：" << "窗口" << w_id << "obj_id" << obj_id << "act_id" << act_id << endl;
		cout << "可能未初始化" << endl;
	}
}

//获取触发结构数据
state_transition::Transition_op_to_anima *& state_transition::get_transition(int w_id)
{
	if (w_id > windows_num)
		cout << "获取触发结构数据有误，可能超过了最大值，位置：" << w_id << endl;
	return set_tran[w_id];
}

void state_transition::set_axis_ass_bmp(int w_id, int obj_id, int act_id, T_POS pos, int bmp_id, bool lock, int id)
{
	if (set_tran[w_id]->act_obj[obj_id].sub_action[act_id].other_Act) {
		if (pos == BAXIS) {
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].has_assoc_bmp = true;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].assoc_bmp = new Tran_id;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].assoc_bmp->to_bitmap_id = bmp_id;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].assoc_bmp->to_acting_id = act_id;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].assoc_bmp->pid = id;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].assoc_bmp->assoc_lock = lock;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].assoc_bmp->assoc_winid = -1;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].assoc_bmp->lever = -1;
		}
	}
	else {
		cout << "关联对象设定错误，可能没有初始化或有其他错误的设置" << endl;
	}
}

void state_transition::set_button_ass_bmp(int w_id, int obj_id, int act_id, T_POS pos, int b_arr, bool lock, int other_bid, int other_aid)
{
	if (set_tran[w_id]->act_obj[obj_id].sub_action[act_id].button) {
		if (pos == BAXIS) {
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[b_arr].has_assoc_bmp = true;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[b_arr].assoc_bmp = new Tran_id;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[b_arr].assoc_bmp->to_bitmap_id = other_bid;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[b_arr].assoc_bmp->to_acting_id = other_aid;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[b_arr].assoc_bmp->assoc_lock = lock;
		}
	}
	else {
		cout << "按钮设定错误！位置：" << "窗口" << w_id << "obj_id" << obj_id << "act_id" << act_id << endl;
		cout << "可能未初始化" << endl;
	}
}

void state_transition::set_button_ass_win(int w_id, int obj_id, int act_id, T_POS pos, int b_arr, bool lock, int win_id)
{
	if (set_tran[w_id]->act_obj[obj_id].sub_action[act_id].button) {
		if (pos == BAXIS) {
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[b_arr].has_assoc_win = true;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[b_arr].assoc_windows_lock = lock;
			set_tran[w_id]->act_obj[obj_id].sub_action[act_id].axis_button[b_arr].assoc_windows_id = win_id;
		}
	}
	else {
		cout << "按钮设定错误！位置：" << "窗口" << w_id << "obj_id" << obj_id << "act_id" << act_id << endl;
		cout << "可能未初始化" << endl;
	}
}

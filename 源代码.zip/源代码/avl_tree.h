#ifndef avl_tree_
#define avl_tree_

#include"two_tree.h"

class avl_tree:public two_tree
{
public:
	avl_tree();
	~avl_tree();

	int create_AVL_tree(Ttree * t_node);//����AVL����ԭ�����ϣ�
	int get_AVL_tree_date(Ttree * t_node, int n_id, int & get_date);//avl��ѯ
	int in_AVL_tree_date(Ttree * t_node, int n_id, int get_date);//avl����

private:
	short * avl_wordbook;//avl�ֵ�
	int array_node;//�ڵ������±�

	static short AVL_wordbook_1[1];//AVL�ֵ�
	static short AVL_wordbook_2[3];
	static short AVL_wordbook_3[7];
	static short AVL_wordbook_4[15];
	static short AVL_wordbook_5[31];
	static short AVL_wordbook_6[63];

	void modify_node_id(Ttree * t_node, short ar_id[]);//�޸Ľڵ�id
};

#endif // !avl_tree_
﻿#include"set_player.h"
#include<cmath>
#include<iostream>

using std::string;
using std::cout;
using std::endl;

set_player::set_player(int pla_num, Map_sys & map_date)
{
	player_id = 0;
	player_num = pla_num;
	punit_table = new unit_elem;
	punit_table->elem_head = punit_table->create_Unit_elem(pla_num);

	map_name = new string[map_date.get_map_num()];
	map_name = map_date.get_map_name();

	team_end = nullptr;
	init_teams = true;
	init_poed = true;
	init_pos_one = true;
	init_pos_two = true;
	init_pos_treen = true;
	init_pos_four = true;
	init_pos_five = true;
	team_in_obj_num = nullptr;
}

set_player::~set_player()
{
}

void set_player::init_player(Map_sys & map_date, player_sys & player_unit, animation_elem & player_animation)
{
	static unit_sys::Unit unit = player_unit.get_unit();
	static animation_sys::Animation animation;
	if (player_animation.elem_head == nullptr)
		player_animation.elem_head = player_animation.create_Animation_elem(player_num);

	int team_id = init_team(player_num, map_date.get_map_date().team_num, player_id, unit);
	init_solier(unit, animation);
	init_pos(team_id, map_date, unit);
	player_unit.set_unit(unit);
	punit_table->in_Unit_elem_date(player_id, punit_table->elem_head, unit);
	player_animation.in_Animation_elem_date_is_null(player_animation.elem_head, animation);
	player_id += 1;
}
//更新玩家的动画和单元表
void set_player::update_player(player_sys & player_unit, animation_elem & player_animation)
{
	punit_table->in_Unit_elem_date_is_null(punit_table->elem_head, player_unit.get_unit());
}

int set_player::get_player_num()
{
	return player_num;
}

int set_player::init_team(int obj_num, int team_num, int id, unit_sys::Unit & unit)
{
	if (init_poed) {
		init_poed = false;
		if (team_end == nullptr) {
			team_end = new int[team_num];
			team_in_obj_num = new int[team_num];
		}
		else {
			delete[] team_end;
			delete[] team_in_obj_num;
			team_end = new int[team_num];
			team_in_obj_num = new int[team_num];
		}
		for (int i = 0; i < team_num; i++)
			team_in_obj_num[i] = 0;

		int num;
		if (team_num == 1)
			team_end[0] = obj_num;
		else if (team_num == 2) {
			team_end[0] = (obj_num) / team_num;
			team_end[1] = obj_num;
		}
		else if (team_num == 3) {
			switch (rand() % 3)
			{
			case 0:
				num = (obj_num - 1) / team_num;
				break;
			case 1:
				num = (obj_num + 1) / team_num;
				break;
			case 2:
				num = (obj_num) / team_num;
				break;
			}
			team_end[0] = num;
			team_end[1] = 2 * num;
			team_end[2] = obj_num;
		}
		else if (team_num == 4) {
			num = (obj_num) / team_num;
			team_end[0] = num;
			team_end[1] = 2 * num;
			team_end[2] = 3 * num;
			team_end[3] = obj_num;
		}
		else if (team_num == 5) {
			switch (rand() % 3)
			{
			case 0:
				num = (obj_num - 1) / team_num;
				break;
			case 1:
				num = (obj_num + 1) / team_num;
				break;
			case 2:
				num = (obj_num) / team_num;
				break;
			}
			team_end[0] = num;
			team_end[1] = 2 * num;
			team_end[2] = 3 * num;
			team_end[3] = 4 * num;
			team_end[4] = obj_num;
		}
	}

	if (id <= team_end[0])//被分配到队伍一
		unit.state.u_team_id = 1;
	else if (id <= team_end[1])//被分配到队伍二
		unit.state.u_team_id = 2;
	else if (id <= team_end[2])//被分配到队伍三
		unit.state.u_team_id = 3;
	else if (id <= team_end[3])//被分配到队伍四
		unit.state.u_team_id = 4;
	else if (id <= team_end[4])//被分配到队伍五
		unit.state.u_team_id = 5;
	return unit.state.u_team_id;
}

void set_player::init_pos(int team_id, Map_sys & map_date, unit_sys::Unit & unit)
{
	static int on_x, on_y;
	static int to_x, to_y;
	static int w, h;
	static int x, y;

	on_x = map_date.get_map_date().life_pos_state[team_id - 1].life_on_x;
	on_y = map_date.get_map_date().life_pos_state[team_id - 1].life_on_y;
	to_x = map_date.get_map_date().life_pos_state[team_id - 1].life_to_x;
	to_y = map_date.get_map_date().life_pos_state[team_id - 1].life_to_y;
	w = to_x - on_x;
	h = to_y - on_y;
	w = rand() % w;
	h = rand() % h;
	x = w + on_x;
	y = h + on_y;

	unit.axis.u_x = 0;
	unit.axis.u_y = 0;
/*	unit.axis.u_x = x;
	unit.axis.u_y = y;*/
}

void set_player::init_solier(unit_sys::Unit & unit, animation_sys::Animation & animation)
{
	switch (unit.state.u_itme_id)
	{
	case 1:
		Rush_solier(unit, animation);
		break;
	case 2:
		Doctor_solier(unit, animation);
		break;
	case 3:
		Repar_solier(unit, animation);
		break;
	case 4:
		Spy_solier(unit, animation);
		break;
	}
}

unit_elem *& set_player::get_player_date()
{
	return punit_table;
}

void set_player::set_init_poed_state(bool sta)
{
	init_poed = sta;
}

void set_player::set_init_teams_state(bool sta)
{
	init_teams = sta;
}

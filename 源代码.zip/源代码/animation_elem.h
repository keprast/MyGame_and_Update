﻿#ifndef animation_elem_
#define animation_elem_

#include"allegro5\allegro.h"
#include"allegro5\allegro_image.h"
#include"state_transition_elem.h"
#include<string>
#include"animation.h"
#include"timer_sys.h"

//动画线性链表类
class animation_elem
{
public:
	//队列标记
	enum Animation_elem_flags
	{
		Ui_ELEM,
		MapContext_ELEM,
		MapUnit_ELEM,
		PlayerSpriti_ELEM,
		AiSpriti_ELEM
	};

	//绘制标记
	struct Animation_draw_flags
	{
		bool now_draw_flg;//当前渲染标记
		bool while_draw_flg;//循环渲染标记
		bool in_while_flg;//连续渲染标记
		bool while_draw;//循环渲染

		int d_arr;//目标位图
		int sta_num;//连续渲染开始标记
		int end_num;//连续渲染结束标记
	};

	//动画位图坐标结构
	struct Animation_axis
	{
		float b_x;//图片x位置
		float b_y;//图片y位置
		float b_arc;//图片arc位置
	};

	//动画位图的宽高属性
	struct Animation_wh
	{
		int bitmap_w;//位图宽
		int bitmap_h;//位图高
	};

	//动画行为结构
	struct Animation_action
	{
		int action_id;//行为id
		
		timer_sys * animation_timer;//动画计时器
		Animation_axis * axis;//动画的坐标
		Animation_draw_flags * flags;//动画的绘制标记
	};

	struct Bmp_date
	{
		std::string obj_name;//该对象的名字
		int b_pid;//身份id，在整个框架中，身份id是不重复的，除非是不同种类的对象
		int lever;//动画位置层数目

		int action_num;//行为数目
		int in_acting_id;//当前动画动作标记
		int now_arr;//当前渲染位图

		bool draw_OK;//绘制状态
		bool have_action;//是否有行动
		bool non_obj;//有无对象（用于判断是否渲染出来）//请结合api位图锁使用

		Animation_wh * bitmap_wh;//宽高
		animation * animations;//位图
		Animation_action * action;//动画的行为
	};

	//动画结构
	struct Animation
	{
		std::string bitmap_name;//该动画的名字
		int bitmap_id;//动画的id
		int bitmap_count_num;//位图总和数
		int bitmap_obj_num;//几个动画对象

		int lever;

		Bmp_date * bmp;//位图
	};

	//动画线性链表结构
	struct Animation_elem
	{
		int e_node_id;//节点id
		Animation_elem * after_elem;//前一个节点
		Animation_elem * next_elem;//后一个节点
		Animation date;//动画结构
		Animation * p_date;//动画结构指针
		bool has_date;//数据有无标记（是否有数据，这是抽象标记，实际上初始化时数据为0，也是数据）
	};

	Animation_elem * elem_head;//线性链表头部
	Animation_elem * elem_tail;//线性链表尾部

	animation_elem();
	~animation_elem();

	//创建线性链表
	Animation_elem * create_Animation_elem(int e_num);
	//创建新节点
	void create_new_node();
	//在某节点后插入一个节点
	void create_an_node(Animation_elem * e_head, int node_id);
	//按照顺序获得指针数据
	void get_Animation_elem_date(Animation_elem * e_head, Animation *& need_date, short state = 0);
	//按照顺序获得栈数据
	void init_order_flg();
	bool get_Animation_elem_order_date(Animation_elem * e_head, Animation & unit);
	int get_order_flg();
	void get_Animation_elem_date(Animation_elem * e_head, Animation & need_date, short state = 0);
	//获取某一节点的数据
	void get_Animation_elem_date(int e_id, Animation_elem * e_head, Animation & need_date);
	void get_Animation_elem_arr_date(Animation_elem * e_head, Animation need_date[]);

	//数据自动插入一个空位置
	int in_Animation_elem_date_is_null(Animation_elem *e_head, Animation & in_date);
	//指针自动插入一个空位置
	int in_Animation_elem_date_is_null(Animation_elem *e_head, Animation * in_date);
	//将数据插入某一节点
	void in_Animation_elem_date(int e_id, Animation_elem * e_head, Animation & in_date);
	//将数据插入某一节点
	void in_Animation_elem_date(int e_id, Animation_elem * e_head, Animation * in_date);
	//按顺序导入栈数据
	void in_Animation_elem_date(Animation_elem * e_head, Animation & in_need, short state = 0);
	//按顺序导入指针数据
	void in_Animation_elem_date(Animation_elem * e_head, Animation *& in_need, short state = 0);
	//重置指针（p_name=1重置获取指针p_name=2重置输入指针,pos指定重置位置）
	void res_point(Animation_elem * e_head, int p_name, int pos = 0);
	//清洗线性链表
	void clean_Animation_elem(Animation_elem * e_head);
	//清除一个对象
	void clean_Animation_elem_node(Animation_elem * e_head, Animation & obj);
	//破坏线性链表
	void destroy_Animation_elem(Animation_elem *& e_head);
	//破坏一个节点
	void destroy_an_node(Animation_elem * e_head, int node_id);
	//前序遍历
	void pre_order_elem(Animation_elem * e_head);
	//后序遍历
	void lrd_order_elem(Animation_elem * e_tail);
	//检查线性链表的状态
	int Animation_elem_is_state(Animation_elem * e_head);
	//获取节点数
	int get_elem_node_num();
	//获取有动作的节点数
	int get_have_action_num(Animation_elem * head);
	//获取有数据的节点数目
	int get_have_date_num(Animation_elem * head);

protected:
	//设定动画数据
	void set_animation_date(int bmp_id, state_transition_elem::Tran_id_plus * to_act_id, Animation_elem * head);

private:
	Animation_elem * get_node;//按顺序获取节点标记
	Animation_elem * in_node;//按顺序输入节点标记
	int e_node_num;//节点的数目
	bool in_tail;//到达队列末尾
	int order_pos;

	//输出结构中的数据
	void get_node_date(Animation_elem * e_tail);

};

#endif 
﻿#include"unit_sys.h"

int unit_sys::unit_num = 0;
float pi = 3.141592f;

unit_sys::unit_sys()
{
	unit.state = { 100,true,unit_num,0,0 };//队伍id为0表示静态物体
	unit.axis = { 0,0,0,0 };
	unit.velocity = { 0,0,0,0 };
	unit.accelerate = { 0,0,0,0 };
	unit.see = { 0 };

	unit_num += 1;
}

unit_sys::~unit_sys()
{
	
}

void unit_sys::set_unit_x(float x)
{
	unit.axis.u_x = x;
}

void unit_sys::set_unit_y(float y)
{
	unit.axis.u_y = y;
}

void unit_sys::set_unit_z(float z)
{
	unit.axis.u_z = z;
}

void unit_sys::set_unit_arc(float arc)
{
	unit.axis.u_arc = arc;
}

void unit_sys::set_unit_axis(float x, float y, float z, float arc)
{
	unit.axis.u_x = x;
	unit.axis.u_y = y;
	unit.axis.u_z = z;
	unit.axis.u_arc = arc;
}

void unit_sys::set_unit_vx(float vx)
{
	unit.velocity.u_v_x = vx;
}

void unit_sys::set_unit_vy(float vy)
{
	unit.velocity.u_v_y = vy;
}

void unit_sys::set_unit_vz(float vz)
{
	unit.velocity.u_v_z = vz;
}

void unit_sys::set_unit_varc(float varc)
{
	unit.velocity.u_v_arc = varc;
}

void unit_sys::set_unit_velocity(float vx, float vy, float vz, float varc)
{
	unit.velocity.u_v_x = vx;
	unit.velocity.u_v_y = vy;
	unit.velocity.u_v_z = vz;
	unit.velocity.u_v_arc = varc;
}

void unit_sys::set_unit_ax(float ax)
{
	unit.accelerate.u_a_x = ax;
}

void unit_sys::set_unit_ay(float ay)
{
	unit.accelerate.u_a_y = ay;
}

void unit_sys::set_unit_az(float az)
{
	unit.accelerate.u_a_z = az;
}

void unit_sys::set_unit_aarc(float aarc)
{
	unit.accelerate.u_a_arc = aarc;
}

void unit_sys::set_unit_accelerate(float ax, float ay, float az, float aarc)
{
	unit.accelerate.u_a_x = ax;
	unit.accelerate.u_a_y = ay;
	unit.accelerate.u_a_z = az;
	unit.accelerate.u_a_arc = aarc;
}

void unit_sys::set_unit_see_area(int r)
{
	unit.see.see_area = r;
}

void unit_sys::set_unit_pid(int obj_pid)
{
	unit.state.u_pid = obj_pid;
}

void unit_sys::set_unit_itme_id(int itme_id)
{
	unit.state.u_itme_id = itme_id;
	if (itme_id >= 1 && itme_id <= 4)
		set_unit_see_area(1500);
}

void unit_sys::set_unit_team_id(int team_id)
{
	unit.state.u_team_id = team_id;
}

void unit_sys::set_unit_hp(int hp)
{
	unit.state.u_hp = hp;
}

void unit_sys::set_unit_live(bool live)
{
	unit.state.u_is_live = live;
}

void unit_sys::set_unit_state(int obj_id, int team_id, int hp, bool live, int itme_id)
{
	if (itme_id != -1)unit.state.u_itme_id = itme_id;
	unit.state.u_pid = obj_id;
	unit.state.u_team_id = team_id;
	unit.state.u_hp = hp;
	unit.state.u_is_live = live;
}

void unit_sys::set_unit(Unit & un)
{
	unit = un;
}

void unit_sys::set_unit_wh(int w, int h)
{
	unit.wh.u_w = w;
	unit.wh.u_h = h;
}

int & unit_sys::get_unit_w()
{
	return unit.wh.u_w;
}

int & unit_sys::get_unit_h()
{
	return unit.wh.u_h;
}

int & unit_sys::get_unit_hp()
{
	return unit.state.u_hp;
}

int & unit_sys::get_unit_object_id()
{
	return unit.state.u_pid;
}

int & unit_sys::get_unit_itme_id()
{
	return unit.state.u_itme_id;
}

int & unit_sys::get_unit_team_id()
{
	return unit.state.u_team_id;
}

bool & unit_sys::get_unit_is_live()
{
	return unit.state.u_is_live;
}

unit_sys::Unit_state & unit_sys::get_unit_state()
{
	return unit.state;
}

float & unit_sys::get_unit_x()
{
	return unit.axis.u_x;
}

float & unit_sys::get_unit_y()
{
	return unit.axis.u_y;
}

float & unit_sys::get_unit_z()
{
	return unit.axis.u_z;
}

float & unit_sys::get_unit_arc()
{
	return unit.axis.u_arc;
}

unit_sys::Unit_axis & unit_sys::get_unit_axis()
{
	return unit.axis;
}

float & unit_sys::get_unit_vx()
{
	return unit.velocity.u_v_x;
}

float & unit_sys::get_unit_vy()
{
	return unit.velocity.u_v_y;
}

float & unit_sys::get_unit_vz()
{
	return unit.velocity.u_v_z;
}

float & unit_sys::get_unit_varc()
{
	return unit.velocity.u_v_arc;
}

unit_sys::Unit_v & unit_sys::get_unit_velocity()
{
	return unit.velocity;
}

float & unit_sys::get_unit_ax()
{
	return unit.accelerate.u_a_x;
}

float & unit_sys::get_unit_ay()
{
	return unit.accelerate.u_a_y;
}

float & unit_sys::get_unit_az()
{
	return unit.accelerate.u_a_z;
}

float & unit_sys::get_unit_aarc()
{
	return unit.accelerate.u_a_arc;
}

unit_sys::Unit_a & unit_sys::get_unit_accelerate()
{
	return unit.accelerate;
}

unit_sys::Unit & unit_sys::get_unit()
{
	return unit;
}

﻿#ifndef set_player_
#define set_player_

#include"unit_elem.h"
#include"animation_elem.h"
#include"map_sys.h"
#include"other_unit.h"
#include<string>

using std::string;

class set_player :protected other_unit
{
public:
	set_player(int pla_num, Map_sys & map_date);
	~set_player();

	//初始化玩家
	void init_player(Map_sys & map_date, player_sys & player_unit, animation_elem & player_animation);
	//更新数据表
	void update_player(player_sys & player_unit, animation_elem & player_animation);
	//获取玩家的数目
	int get_player_num();
	//获取所有玩家的数据
	unit_elem *& get_player_date();
	//设定初始状态
	void set_init_poed_state(bool sta);
	void set_init_teams_state(bool sta);

protected:
	bool init_teams;//初始化队伍
	bool init_poed;//初始化位置
	bool init_pos_one;//初始化位置
	bool init_pos_two;//
	bool init_pos_treen;//
	bool init_pos_four;//
	bool init_pos_five;//

	int * team_end;//队伍
	int * team_in_obj_num;//当前队伍用有的对象

	string * map_name;//地图名字

	//分配队伍
	int init_team(int obj_num, int team_num, int id, unit_sys::Unit & unit);
	//初始化位置
	void init_pos(int team_id, Map_sys & map_date, unit_sys::Unit & unit);
	//初始化兵种
	void init_solier(unit_sys::Unit & unit, animation_sys::Animation & animation);

	//队伍位置
	void team_pos(int team_id, Map_sys & map_date, unit_sys::Unit & unit);
	void team_two_pos(Map_sys & map_date, unit_sys::Unit & unit);
	void team_treen_pos(Map_sys & map_date, unit_sys::Unit & unit);
	void team_four_pos(Map_sys & map_date, unit_sys::Unit & unit);
	void team_five_pos(Map_sys & map_date, unit_sys::Unit & unit);

private:
	int player_num;//玩家的数目
	int player_id;//玩家id
	unit_elem * punit_table;//单元

};

#endif
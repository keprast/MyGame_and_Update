﻿#include"set_sys.h"

int display_w;
int display_h;

set_sys::set_sys()
{
}

set_sys::~set_sys()
{
}

void set_sys::init_display_wh(ALLEGRO_DISPLAY *& display, int dis_w, int dis_h)
{
	display_w = dis_w;
	display_h = dis_h;
	display = al_create_display(display_w, display_h);
}

void set_sys::init_mouse_axis(ALLEGRO_DISPLAY *& display, player_sys::Player_opertion & player)
{
	al_set_mouse_xy(display, display_w / 2, display_h / 2);
	player.mouse.x = display_w / 2;
	player.mouse.y = display_h / 2;
}
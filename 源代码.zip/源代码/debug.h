﻿#pragma once

#include<string>
#include<Windows.h>
#include<time.h>

using std::string;

enum Output_flg
{
	Error,
	Tip,
	Text,
	X_axis,
	Y_axis,
	Z_axis,
	Arc_p
};

extern long start_time, end_time;

void get_out_message_to_text(Output_flg flg, char * ch, char * ch_flg = nullptr);
void get_out_message_to_text(Output_flg flg, string & ch, char * ch_flg = nullptr);

char * int_tran_to_char(int num);
char * float_tran_to_char(float num);

//获取运行时间（会暂停运行）
void get_run_time(long & sta, long & end);
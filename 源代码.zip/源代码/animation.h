﻿#ifndef animation_
#define animation_

#include"allegro5\allegro.h"

class animation
{
public:
	animation(int bitmap_num);
	~animation();

	//获取位图数
	int get_bitmap_num();
	//获取位图
	ALLEGRO_BITMAP * operator[](int i);
	ALLEGRO_BITMAP * get_bitmap(int i);

	//设定位图
	void set_bitmap(int i, char * name);

private:
	int bitmap_num;//位图数目
	ALLEGRO_BITMAP ** bitmap;//位图组

};

#endif

﻿#ifndef other_unit_
#define other_unit_

#include"animation_elem.h"
#include"unit_sys.h"
#include"set_bitmap.h"

class other_unit :public set_bitmap
{
public:
	other_unit();
	~other_unit();

protected:
	int bitmap_pid;
	int bitmap_id;

	//突击兵
	void Rush_solier(unit_sys::Unit & unit, animation_elem::Animation & animation);
	//医护兵
	void Doctor_solier(unit_sys::Unit & unit, animation_elem::Animation & animation);
	//修理师
	void Repar_solier(unit_sys::Unit & unit, animation_elem::Animation & animation);
	//侦察兵
	void Spy_solier(unit_sys::Unit & unit, animation_elem::Animation & animation);


private:

};

#endif
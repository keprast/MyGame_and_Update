﻿#ifndef text_sys_
#define text_sys_

#include<cmath>
#include"gui_sys.h"
#include"player_sys.h"
#include"debug.h"
#include"allegro5\allegro.h"
#include"allegro5\allegro_font.h"
#include"allegro5\allegro_ttf.h"

class text_sys
{
public:
	//字体
	enum Font
	{
		msyh,//微软雅黑
		simhei,//石墨黑
	};
	//字体大小
	enum Size
	{
		Siz_Def,
		size_8,
		size_16,
		size_24,
		size_32
	};
	//常用颜色
	enum Color
	{
		Col_Def,//默认
		Black,//黑色
		White,//白色
		Red,//红色
		Yellow,//黄色
		Blue,//蓝色
		Green,//绿色
		Young,//青色
		Orange,//橙色
	};
	//滑动样式
	enum Slide_style
	{
		Slide_Def,//默认
		crosswise,//横向
		lengthways//纵向
	};
	//渐变样式
	enum Shade_style
	{
		vanish,//消失
		appear//出现
	};

	//文本触发方式
	enum Spark
	{
		Spa_Def,
		Mouse_axis,//鼠标滑轮
		Key_button//键盘按钮
	};

	//额外数据
	//坐标数据
	struct Axis
	{
		int x;
		int y;
	};

	//滚动文本
	struct Roll_text
	{
		bool run;//运行
		ALLEGRO_TIMER * timer;//计时器

		int roll_count;//滚动计数
		int roll_now_pos;//滚动的位置
		int content_now_pos;//内容当前位置
		int roll_size;//滚动内容字符数（中文UTF8占3字节）
		char * roll_content;//滚动内容

		int content_size;//内容大小
		char * content;//内容
	};
	//滑动文本
	struct Slide_text
	{
		bool * run;//运行
		ALLEGRO_TIMER * timer;//计时器
		ALLEGRO_FONT * smile_font;//小字字体
		Slide_style * style;//样式标记
		Spark * spark_style;//触发方式

		bool * ok;//操作情况
		int * run_count;//运行计数

		Axis * on_axis;//触发坐标
		Axis * to_axis;//触发坐标
		Axis * refer_to;//参考坐标
		int * slide_addup;//滑动文本合计
		int * slide_num;//滑动文本显示数
		double * line_size;//文本距离
		Size * smile_size;//小文本字体大小

		int * now_text_flg;//文本标记（当前是哪一个文本）
		int * sta_text_flg;//开始位置标记
		int * end_text_flg;//结束位置标记
		int * way;//方向（1向上动，-1向下动）
	};
	//渐变文本
	struct Shade_text
	{
		bool run;//运行
		ALLEGRO_TIMER * timer;//计时器
	};

	//文本
	struct Text
	{
		char * content;//内容
		Font font;//字体
		Color color;//颜色
		Axis axis;//坐标
		Size size;//大小

		Roll_text * roll_text;//滚动文本数据
		Slide_text * slide_text;//滑动文本数据
		Shade_text * shade_text;//渐变文本数据
	};

	text_sys();
	~text_sys();

	//初始化文本
	void init_text();
	//获取事件系统
	void get_event_queue(ALLEGRO_EVENT_QUEUE *& event_queue);
	//获取事件
	void get_event(ALLEGRO_EVENT & event);
	//获得用户操作
	void get_opertion(player_sys::Player_opertion & opertion);
	//获得坐标数据
	void set_axis_date(float x, float y);
	//绘制文本
	void draw_text(int windows_id);

	//重置文本
	void res_text();
	//开始计时器
	void start_text_timer(int windows_id);
	//运行计时器
	void run_text_timer();
	//停止计时器
	void stop_text_timer(int windows_id);

private:
	//样式
	enum Style
	{
		Roll,
		Slide,
		Shade
	};

	static player_sys::Player_opertion * opertion;
	static Axis unit_axis;//单元坐标
	static text_sys * text_date;//文本数据
	static ALLEGRO_EVENT_QUEUE * event_queue;//事件系统队列
	static ALLEGRO_EVENT * event;//事件系统

	static int now_draw_text;//当前绘制文本
	static int now_draw_win;//当前绘制窗口
	static Text after_text;//前一个文本
	static Slide_text after_slide;//前一个滑动文本
	static int * slide_flg;//滑动文本临时标记
	static int slide_addup;//滑动文本临时计数

	int text_num;//文本数目
	Text * text;//文本数据

	//滚动文本
	void text_roll(int i, int roll_size, double sec);
	//滑动文本
	void text_slide(int i, Slide_style style = Slide_Def, Spark spark = Spa_Def, int slide_num = -1, double sec = -1, double line_size = -1, Size smile_text_size = Siz_Def, int w = -1, int h = -1);
	void start_slide_text(int s_num);
	void end_slide_text();
	//渐变文本
	void text_shade(int i, Shade_style style, double sec);
	//一行文本
	int line_text(char * content, int x = -1, int y = -1, Size size = Siz_Def, Color color = Col_Def, Font font = msyh);
	//获取滚动（返回的布尔值来确定是否滚动）
	bool roll();
	//获取滑动
	bool slide();
	bool slide_spark();
	//获取渐变
	bool shade();

	//更改文本内容
	void modfiy_content(Text & text, char * content);
	//更改文本坐标
	void modfiy_axis(Text & text, int x, int y);
	//更改文本颜色
	void modfiy_color(Text & text, Color color);
	//修改文本大小
	void modfiy_size(Text & text, Size size);
	//修改文本字体
	void modfiy_font(Text & text, Font font);

	//获取颜色
	ALLEGRO_COLOR get_color();
	//获取字体
	ALLEGRO_FONT * get_font(Font font = msyh, Size size = Siz_Def);
	//获取内容
	char * get_content();
	//获取坐标
	Axis get_axis();

	//分配内存
	void stor_allocation();

};

#endif

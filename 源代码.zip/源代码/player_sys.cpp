﻿#include"player_sys.h"
#include"cmath"

player_sys::player_sys()
{
	player_opertion.keybords = { false,false,false,false };
	player_opertion.mouse = { false,false,0,0 };
}

player_sys::player_sys(Unit & pl)
{
	set_unit(pl);
}

player_sys::~player_sys()
{

}

void player_sys::set_player_mouse_x(int & mx)
{
	player_opertion.mouse.x = mx;
}

void player_sys::set_player_mouse_y(int & my)
{
	player_opertion.mouse.y = my;
}

void player_sys::set_player_mouse_left(bool & ml)
{
	player_opertion.mouse.left = ml;
}

void player_sys::set_player_mouse_right(bool & mr)
{
	player_opertion.mouse.right = mr;
}

void player_sys::set_player_mouse(Mouse_opertion & m)
{
	player_opertion.mouse = m;
}

void player_sys::set_player_key_w(bool & kw)
{
	player_opertion.keybords.key_w = kw;
}

void player_sys::set_player_key_s(bool & ks)
{
	player_opertion.keybords.key_s = ks;
}

void player_sys::set_player_key_a(bool & ka)
{
	player_opertion.keybords.key_a = ka;
}

void player_sys::set_player_key_d(bool & kd)
{
	player_opertion.keybords.key_d = kd;
}

void player_sys::set_player_keybord(Keybord_opertion & kbord)
{
	player_opertion.keybords = kbord;
}

void player_sys::set_player_date(Player_opertion & plop)
{
	player_opertion = plop;
}

int & player_sys::get_player_mouse_x()
{
	return player_opertion.mouse.x;
}

int & player_sys::get_player_mouse_y()
{
	return player_opertion.mouse.y;
}

bool & player_sys::get_player_mouse_left()
{
	return player_opertion.mouse.left;
}

bool & player_sys::get_player_mouse_right()
{
	return player_opertion.mouse.right;
}

player_sys::Mouse_opertion & player_sys::get_player_mouse()
{
	return player_opertion.mouse;
}

bool & player_sys::get_player_key_w()
{
	return player_opertion.keybords.key_w;
}

bool & player_sys::get_player_key_s()
{
	return player_opertion.keybords.key_s;
}

bool & player_sys::get_player_key_a()
{
	return player_opertion.keybords.key_a;
}

bool & player_sys::get_player_key_d()
{
	return player_opertion.keybords.key_d;
}

player_sys::Keybord_opertion & player_sys::get_player_keybord()
{
	return player_opertion.keybords;
}

player_sys::Player_opertion player_sys::get_player_opertion()
{
	return player_opertion;
}

bool & player_sys::get_player_is_live_state()
{
	static Unit_state player = get_unit_state();
	return player.u_is_live;
}

bool & player_sys::get_player_fire_state()
{
	return player_opertion.mouse.left;
}

bool & player_sys::get_player_move_state()
{
	static Unit_v player = get_unit_velocity();
	static bool player_state = true;//假定玩家在移动
	if (player.u_v_x == 0 && player.u_v_y == 0 && player.u_v_z == 0 && player.u_v_arc == 0)player_state = false;
	return player_state;
}

void player_sys::move()
{
	Unit player;
	player = get_unit();//获取玩家的单元数据

	if (player.state.u_hp > 0) {
		player.velocity.u_v_x = player.accelerate.u_a_x;//获取加速度
		player.velocity.u_v_y = player.accelerate.u_a_y;//后期将加入加速和减速情况
		player.velocity.u_v_z = player.accelerate.u_a_z;
		player.velocity.u_v_arc = player.accelerate.u_a_arc;
		if (player_opertion.keybords.key_w && !player_opertion.keybords.key_s &&
			!player_opertion.keybords.key_a && !player_opertion.keybords.key_d) {//向前走
			player.axis.u_x -= (player.velocity.u_v_x*cos(player.axis.u_arc + pi / 2));
			player.axis.u_y -= (player.velocity.u_v_y*sin(player.axis.u_arc + pi / 2));
		}
		else if (!player_opertion.keybords.key_w && player_opertion.keybords.key_s &&
			!player_opertion.keybords.key_a && !player_opertion.keybords.key_d) {//向后走
			player.axis.u_x += (player.velocity.u_v_x*cos(player.axis.u_arc + pi / 2));
			player.axis.u_y += (player.velocity.u_v_y*sin(player.axis.u_arc + pi / 2));
		}
		else if (!player_opertion.keybords.key_w && !player_opertion.keybords.key_s &&
			player_opertion.keybords.key_a && !player_opertion.keybords.key_d) {//向左走
			player.axis.u_x += (player.velocity.u_v_x*cos(player.axis.u_arc + pi));
			player.axis.u_y += (player.velocity.u_v_y*sin(player.axis.u_arc + pi));
		}
		else if (!player_opertion.keybords.key_w && !player_opertion.keybords.key_s &&
			!player_opertion.keybords.key_a && player_opertion.keybords.key_d) {//向右走
			player.axis.u_x -= (player.velocity.u_v_x*cos(player.axis.u_arc + pi));
			player.axis.u_y -= (player.velocity.u_v_y*sin(player.axis.u_arc + pi));
		}
		else if (player_opertion.keybords.key_w && !player_opertion.keybords.key_s &&
			player_opertion.keybords.key_a && !player_opertion.keybords.key_d) {//向左转
			player.axis.u_arc -= player.velocity.u_v_arc;
		}
		else if (player_opertion.keybords.key_w && !player_opertion.keybords.key_s &&
			!player_opertion.keybords.key_a && player_opertion.keybords.key_d) {//向右转
			player.axis.u_arc += player.velocity.u_v_arc;
		}

		set_unit(player);//导回玩家的单元数据
	}
}

void player_sys::fire()
{
	
}

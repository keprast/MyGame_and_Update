#include"bullet_sys.h"

bullet_sys::bullet_sys()
{

}

bullet_sys::~bullet_sys()
{

}
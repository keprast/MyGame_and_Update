﻿#ifndef set_bitmap_
#define set_bitmap_

#include"timer_sys.h"
#include"animation.h"
#include"animation_elem.h"
#include"allegro5\allegro.h"
#include<string>

class set_bitmap
{
public:
	set_bitmap();
	~set_bitmap();

protected:
	//初始化位图并设定位图id
	void init_bitmap(int b_id, int obj_num, animation_elem::Animation & animation, std::string bmp_name);
	//设定位图数目
	void set_bitmap_num(int obj_arr, int b_num, animation_elem::Animation & animation);
	//设定位图名字
	void set_bitmap_name(int obj_arr, int b_arr, char * animation_name, std::string obj_names, animation_elem::Animation & animation);
	//设定位图行为数目
	void set_bitmap_action_num(int obj_arr, int a_num, animation_elem::Animation & animation);
	//设定默认位图权重及动作
	void set_bitmap_df_action_flags(int obj_arr, int act_id, int act_lev, animation_elem::Animation & animation);
	//设定位图是否被显示
	void set_bitmap_non_obj(int obj_arr, bool non, animation_elem::Animation & animation);
	//设定位图显示速度
	void set_bitmap_action_times(int obj_arr, int act_arr, double t, animation_elem::Animation & animation);
	//设定位图显示位置
	void set_bitmap_action_axis(int obj_arr, int act_arr, float x, float y, float arc, animation_elem::Animation & animation);
	//设定位图绘制标记
	void set_bitmap_action_draw_flags(int obj_arr, int act_arr, bool now_flg, bool whi_flg, int now_num, int sta, int end, animation_elem::Animation & animation, bool whi = false);
	//设定位图所在层数（绘制的位置，数字越小越底层）
	void set_bitmap_lever(int lev, animation_elem::Animation & animation);
	void set_bitmap_lever(int obj_arr, int lev, animation_elem::Animation & animation);
	//设置pid值
	void set_bitmap_pid(int obj_arr, int id, animation_elem::Animation & animation);
	//破坏参数结构内存
	void destory_bitmap_obj(animation_elem::Animation *& obj);

private:

};

#endif
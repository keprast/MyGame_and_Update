﻿#include"animation_elem.h"
#include<iostream>

using std::cout;
using std::endl;

animation_elem::animation_elem()
{
	elem_head = nullptr;
	get_node = in_node = elem_head;
	in_tail = false;
}

animation_elem::~animation_elem()
{

}

animation_elem::Animation_elem * animation_elem::create_Animation_elem(int e_num)
{
	Animation_elem * e_head;
	Animation_elem * e_after, *e_next;

	e_node_num = e_num;
	int e_id = 0;
	e_head = nullptr;
	e_after = e_next = nullptr;
	while (e_num != 0)
	{
		e_num--;
		e_next = new Animation_elem;
		if (e_head == nullptr) {
			e_head = e_next;
			get_node = in_node = e_head;
			e_next->next_elem = nullptr;
			e_next->after_elem = nullptr;
			e_next->e_node_id = e_id;
			e_next->has_date = NULL;
			e_next->date.bitmap_id = -1;
			e_next->p_date = nullptr;
			e_after = e_next;
		}
		else
		{
			e_after->next_elem = e_next;
			e_next->after_elem = e_after;
			e_next->e_node_id = ++e_id;
			e_next->has_date = NULL;
			e_next->date.bitmap_id = -1;
			e_next->p_date = nullptr;
			e_next->next_elem = nullptr;
			e_after = e_next;
		}
	}
	if (e_num == 0)elem_tail = e_next;

	return e_head;
}

void animation_elem::create_new_node()
{
	Animation_elem * new_node = new Animation_elem;
	e_node_num += 1;

	new_node->has_date = NULL;
	new_node->p_date = nullptr;
	elem_tail->next_elem = new_node;
	new_node->after_elem = elem_tail;
	new_node->next_elem = nullptr;
	new_node->e_node_id = elem_tail->e_node_id + 1;
	elem_tail = new_node;
}

void animation_elem::create_an_node(Animation_elem * e_head, int node_id)
{
	while (e_head)
	{
		if (e_head->e_node_id == node_id) {
			Animation_elem * new_node = new Animation_elem;

			new_node->has_date = NULL;
			new_node->p_date = nullptr;
			e_head->next_elem = new_node;
			new_node->after_elem = e_head;
			if (e_head->next_elem == nullptr)new_node->next_elem = nullptr;
			else new_node->next_elem = e_head->next_elem;
			e_node_num += 1;
		}
		if (e_head->next_elem == nullptr)break;
		e_head = e_head->next_elem;
	}
}

void animation_elem::get_Animation_elem_date(Animation_elem * e_head, Animation *& need_date, short state)
{
	in_tail = false;
	if (state != 0)
		get_node = e_head;//顺序归位
	need_date = get_node->p_date;
	if (get_node == elem_tail) {
		get_node = e_head;//顺序归位
	}
	else if (get_node->next_elem)
		get_node = get_node->next_elem;
}

void animation_elem::init_order_flg()
{
	order_pos = 0;
}

bool animation_elem::get_Animation_elem_order_date(Animation_elem * e_head, Animation & unit)
{
	while (e_head)
	{
		if (!e_head->has_date)
			return false;
		if (e_head->e_node_id == order_pos) {
			unit = e_head->date;
			order_pos++;
			return true;
		}
		if (e_head->next_elem)
			e_head = e_head->next_elem;
		else
			break;
	}
	return false;
}

int animation_elem::get_order_flg()
{
	return order_pos;
}

void animation_elem::get_Animation_elem_date(Animation_elem * e_head, Animation & need_date, short state)
{
	if (state != 0)
		get_node = e_head;//顺序归位
	need_date = get_node->date;
	if (get_node == elem_tail) {
		get_node = e_head;//顺序归位
	}
	else if (get_node->next_elem)
		get_node = get_node->next_elem;
}

void animation_elem::get_Animation_elem_date(int e_id, Animation_elem * e_head, Animation & need_date)
{
	while (e_head)
	{
		if (e_head->e_node_id == e_id) {
			need_date = e_head->date;
			break;
		}
		if (!e_head->next_elem)
			break;
		e_head = e_head->next_elem;
	}
}

void animation_elem::get_Animation_elem_arr_date(Animation_elem * e_head, Animation need_date[])
{
	if (e_head) {
		for (int i = 0; i < e_node_num; i++)
		{
			if (e_head->has_date)
				need_date[i] = e_head->date;
			if (!e_head->next_elem)
				break;
			e_head = e_head->next_elem;
		}
	}
	else
		cout << "该动画线性链表不存在对象！" << endl;
}

int animation_elem::in_Animation_elem_date_is_null(Animation_elem * e_head, Animation & in_date)
{
	if (!e_head)return -1;//不存在该表
	while (e_head)
	{
		if (e_head->has_date == NULL || e_head->date.bitmap_id == in_date.bitmap_id) {
			e_head->date = in_date;
			e_head->has_date = true;
			return 1;//成功
		}
		if (!e_head->next_elem)
			break;
		e_head = e_head->next_elem;
	}
	return 0;//无空位置
}

int animation_elem::in_Animation_elem_date_is_null(Animation_elem * e_head, Animation * in_date)
{
	if (!e_head)return -1;
	while (true)
	{
		if (e_head->p_date == nullptr) {
			e_head->p_date = in_date;
			get_node->has_date = true;
			return 1;
		}
		if (!e_head->next_elem)break;
		e_head = e_head->next_elem;
	}
	return 0;
}

void animation_elem::in_Animation_elem_date(int e_id, Animation_elem * e_head, Animation & in_date)
{
	while (e_head)
	{
		if (e_head->date.bitmap_id == e_id) {
			e_head->date = in_date;
			e_head->has_date = true;
			break;
		}
		if (!e_head->next_elem)
			break;
		e_head = e_head->next_elem;
	}
}

void animation_elem::in_Animation_elem_date(int e_id, Animation_elem * e_head, Animation * in_date)
{
	while (e_head)
	{
		if (e_head->e_node_id == e_id) {
			e_head->p_date = in_date;
			get_node->has_date = true;
			break;
		}
		e_head = e_head->next_elem;
	}
}

void animation_elem::in_Animation_elem_date(Animation_elem * e_head, Animation & in_date, short state)
{
	if (state != 0)
		in_node = e_head;//顺序归位
	in_node->date = in_date;
	in_node->has_date = true;
	if (in_node == elem_tail) {
		in_node = e_head;//顺序归位
	}
	if (in_node->next_elem)
		in_node = in_node->next_elem;
}

void animation_elem::in_Animation_elem_date(Animation_elem * e_head, Animation *& in_date, short state)
{
	if (state != 0)
		in_node = e_head;//顺序归位
	in_node->p_date = in_date;
	in_node->has_date = true;
	if (in_node == elem_tail)
		in_node = e_head;//顺序归位
	if (in_node->next_elem)
		in_node = in_node->next_elem;
}

void animation_elem::res_point(Animation_elem * e_head, int p_name, int pos)
{
	while (e_head)
	{
		if (e_head->e_node_id == pos) {
			if (p_name == 1)get_node = e_head;
			else if (p_name == 2)in_node = e_head;
			break;
		}
		if (!e_head->next_elem)break;
		e_head = e_head->next_elem;
	}
}

void animation_elem::clean_Animation_elem(Animation_elem * e_head)
{
	while (e_head)
	{
		e_head->has_date = NULL;
		e_head->p_date = nullptr;
		if (!e_head->next_elem)break;
		e_head = e_head->next_elem;
	}
}

void animation_elem::clean_Animation_elem_node(Animation_elem * e_head, Animation & obj)
{
	while (e_head)
	{
		if (e_head->date.bitmap_id == obj.bitmap_id) {
			e_head->has_date = NULL;
			break;
		}
		if (e_head->next_elem == nullptr)break;
		e_head = e_head->next_elem;
	}
}

void animation_elem::destroy_Animation_elem(Animation_elem *& e_head)
{
	if (e_head) {
		Animation_elem * after_e = nullptr;
		if (e_head->next_elem) {
			while (e_head->next_elem)
			{
				delete after_e;
				after_e = nullptr;
				after_e = e_head;
				e_head = e_head->next_elem;
			}
			delete after_e;
			after_e = nullptr;
		}
		else
		{
			delete e_head;
			e_head = nullptr;
		}
	}
}

void animation_elem::destroy_an_node(Animation_elem * e_head, int node_id)
{
	while (e_head)
	{
		if (e_head->e_node_id == node_id) {
			if (e_head == elem_head) {
				elem_head = e_head->next_elem;
				e_head->next_elem->after_elem = nullptr;
				delete e_head;
				e_head = nullptr;
				e_node_num -= 1;
				break;
			}
			if (e_head == elem_tail) {
				elem_tail = elem_tail->after_elem;
				elem_tail->after_elem->next_elem = nullptr;
				delete e_head;
				e_head = nullptr;
				e_node_num -= 1;
				break;
			}
			e_head->next_elem->after_elem = e_head->after_elem;
			e_head->after_elem->next_elem = e_head->next_elem;
			delete e_head;
			e_head = nullptr;
			e_node_num -= 1;
			break;
		}
		if (e_head->next_elem == nullptr)break;
		e_head = e_head->next_elem;
	}
}

void animation_elem::pre_order_elem(Animation_elem * e_head)
{
	while (e_head)
	{
		get_node_date(e_head);
		if (e_head->next_elem == nullptr)break;
		e_head = e_head->next_elem;
	}
}

void animation_elem::lrd_order_elem(Animation_elem * e_tail)
{
	while (e_tail)
	{
		get_node_date(e_tail);
		if (e_tail->after_elem == nullptr)break;
		e_tail = e_tail->after_elem;
	}
}

int animation_elem::Animation_elem_is_state(Animation_elem * e_head)
{
	int e_state = 1;//1代表满表,0代表有空间
	while (e_head->next_elem)
	{
		if (e_head->has_date == NULL || e_head->p_date == nullptr) {
			e_state = 0;
			break;
		}
		e_head = e_head->next_elem;
	}
	return e_state;
}

int animation_elem::get_elem_node_num()
{
	return e_node_num;
}

int animation_elem::get_have_action_num(Animation_elem * head)
{
	int have_date_obj_num = 0;
	while (head)
	{
		if (head->has_date) {
			for (int i = 0; i < head->date.bitmap_obj_num; i++)
				if (head->date.bmp[i].have_action)
					have_date_obj_num += 1;
		}
		if (!head->next_elem)break;
		head = head->next_elem;
	}
	return have_date_obj_num;
}

int animation_elem::get_have_date_num(Animation_elem * head)
{
	int have_date_obj_num = 0;
	while (head)
	{
		if (head->has_date)
			have_date_obj_num += 1;
		if (!head->next_elem)
			break;
		head = head->next_elem;
	}
	return have_date_obj_num;
}

void animation_elem::set_animation_date(int bmp_id, state_transition_elem::Tran_id_plus * to_act_id, Animation_elem * head)
{
	while (head)
	{
		if (head->date.bitmap_id == bmp_id) {
			for (int i = 0; i < head->date.bitmap_obj_num; i++)
			{
				head->date.bmp[i].in_acting_id = to_act_id[bmp_id].tra_sub_obj[i].to_acting_id;
				head->date.bmp[i].have_action = true;
			}
			break;
		}
		if (head->next_elem)
			head = head->next_elem;
		else
			break;
	}
}

void animation_elem::get_node_date(Animation_elem * e_tail)
{

}
﻿#include"con_action.h"
#include"association.h"

con_action::con_action()
{
}

con_action::~con_action()
{
}

//按钮事件
void con_action::Button()
{
	for (int i = 0; i < tran.act_obj_num; i++)
	{
		for (int j = 0; j < tran.act_obj[i].sub_action_num; j++)
		{
			if (tran.act_obj[i].sub_action[j].other_Act) {//有其他动作
				if (temp_pdate.mouse.x >= tran.act_obj[i].sub_action[j].on_t_x && temp_pdate.mouse.x <= tran.act_obj[i].sub_action[j].to_t_x
					&& temp_pdate.mouse.y >= tran.act_obj[i].sub_action[j].on_t_y && temp_pdate.mouse.y <= tran.act_obj[i].sub_action[j].to_t_y) {//鼠标坐标符合坐标
					Button_act(i, j);
				}
				else {
					transiting[i].tra_sub_obj[j].to_bitmap_id = tran.act_obj[i].sub_action[j].df_action_id->to_bitmap_id;
					transiting[i].tra_sub_obj[j].to_acting_id = tran.act_obj[i].sub_action[j].df_action_id->to_acting_id;
					transiting[i].tra_sub_obj[j].lever = tran.act_obj[i].sub_action[j].df_action_id->lever;
				}
			}
			else {//否则返回默认动作
				transiting[i].tra_sub_obj[j].to_bitmap_id = tran.act_obj[i].sub_action[j].df_action_id->to_bitmap_id;
				transiting[i].tra_sub_obj[j].to_acting_id = tran.act_obj[i].sub_action[j].df_action_id->to_acting_id;
				transiting[i].tra_sub_obj[j].lever = tran.act_obj[i].sub_action[j].df_action_id->lever;
			}
		}
	}
}

//移动位图事件
void con_action::MoveBmp()
{
}

void con_action::Button_act(int & obj_pos, int & sub_obj_pos)
{
	transiting[obj_pos].tra_sub_obj[sub_obj_pos].to_bitmap_id = tran.act_obj[obj_pos].sub_action[sub_obj_pos].action_id->to_bitmap_id;//传递状态
	transiting[obj_pos].tra_sub_obj[sub_obj_pos].to_acting_id = tran.act_obj[obj_pos].sub_action[sub_obj_pos].action_id->to_acting_id;//
	transiting[obj_pos].tra_sub_obj[sub_obj_pos].lever = tran.act_obj[obj_pos].sub_action[sub_obj_pos].action_id->lever;//
	if (tran.act_obj[obj_pos].sub_action[sub_obj_pos].has_assoc_bmp)
		set_bmp_assoc(tran.act_obj[obj_pos].sub_action[sub_obj_pos].assoc_bmp);

	if (tran.act_obj[obj_pos].sub_action[sub_obj_pos].button) {
		for (int i = 0; i < tran.act_obj[obj_pos].sub_action[sub_obj_pos].button_num; i++)//鼠标按钮符合条件
		{
			if (tran.act_obj[obj_pos].sub_action[sub_obj_pos].axis_button[i].button_value == value.m_value) {
				transiting[obj_pos].tra_sub_obj[sub_obj_pos].to_acting_id = tran.act_obj[obj_pos].sub_action[sub_obj_pos].axis_button[i].action_id->to_acting_id;//传递状态
				if (tran.act_obj[obj_pos].sub_action[sub_obj_pos].axis_button[i].has_assoc_bmp)
					set_bmp_assoc(tran.act_obj[obj_pos].sub_action[sub_obj_pos].axis_button[i].assoc_bmp);
				if (tran.act_obj[obj_pos].sub_action[sub_obj_pos].axis_button[i].has_assoc_win)
					set_win_assoc(tran.act_obj[obj_pos].sub_action[sub_obj_pos].axis_button[i].assoc_windows_lock,
						tran.act_obj[obj_pos].sub_action[sub_obj_pos].axis_button[i].assoc_windows_id);
			}
		}
	}
}

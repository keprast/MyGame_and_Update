﻿#ifndef con_action_
#define con_action_

#include"state_transition.h"

class con_action :public state_transition
{
public:
	con_action();
	~con_action();

protected:
	//按钮点击行为
	void Button();
	//鼠标使得位图移动
	void MoveBmp();

private:
	void Button_act(int & obj_pos, int & sub_obj_pos);

};


#endif
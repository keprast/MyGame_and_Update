﻿#include"two_tree.h"
#include"iostream"
#include"cmath"

using std::string;
using std::cout;
using std::cin;
using std::endl;
short two_tree::tree_wordbook_1[4]
{ 0,1,0,0 };
short two_tree::tree_wordbook_2[8]
{ 0,1,2,0,0,3,0,0 };
short two_tree::tree_wordbook_3[16]
{ 0,1,2,3,0,0,4,0,0,5,6,0,0,7,0,0 };
short two_tree::tree_wordbook_4[32]
{ 0,1,2,3,4,0,0,5,0,0,6,7,0,0,8,0,0,9,10,11,0,0,12,0,0,13,14,0,0,15,0,0 };
short two_tree::tree_wordbook_5[64]
{ 0,1,2,3,4,5,0,0,6,0,0,7,8,0,0,9,0,0,10,11,12,0,0,13,0,0,14,15,0,0,16,0,0,17,18,19,20,0,0,21,0,0,22,23,0,0,24,0,0,25,26,27,0,0,28,0,0,29,30,0,0,31,0,0 };
short two_tree::tree_wordbook_6[128]
{ 0,1,2,3,4,5,6,0,0,7,0,0,8,9,0,0,10,0,0,11,12,13,0,0,14,0,0,15,16,0,0,17,0,0,18,19,20,21,0,0,22,0,0,23,24,0,0,25,0,0,26,27,28,0,0,29,0,0,30,31,0,0,32,0,0,33,34,35,36,37,0,0,38,0,0,39,40,0,0,41,0,0,42,43,44,0,0,45,0,0,46,47,0,0,48,0,0,49,50,51,52,0,0,53,0,0,54,55,0,0,56,0,0,57,58,59,0,0,60,0,0,61,62,0,0,63,0,0 };
short two_tree::tree_wordbook_7[256]
{ 0,1,2,3,4,5,6,7,0,0,8,0,0,9,10,0,0,11,0,0,12,13,14,0,0,15,0,0,16,17,0,0,18,0,0,19,20,21,22,0,0,23,0,0,24,25,0,0,26,0,0,27,28,29,0,0,30,0,0,31,32,0,0,33,0,0,34,35,36,37,38,0,0,39,0,0,40,41,0,0,42,0,0,43,44,45,0,0,46,0,0,47,48,0,0,49,0,0,50,51,52,53,0,0,54,0,0,55,56,0,0,57,0,0,58,59,60,0,0,61,0,0,62,63,0,0,64,0,0,65,66,67,68,69,70,0,0,71,0,0,72,73,0,0,74,0,0,75,76,77,0,0,78,0,0,79,80,0,0,81,0,0,82,83,84,85,0,0,86,0,0,87,88,0,0,89,0,0,90,91,92,0,0,93,0,0,94,95,0,0,96,0,0,97,98,99,100,101,0,0,102,0,0,103,104,0,0,105,0,0,106,107,108,0,0,109,0,0,110,111,0,0,112,0,0,113,114,115,116,0,0,117,0,0,118,119,0,0,120,0,0,121,122,123,0,0,124,0,0,125,126,0,0,127,0,0 };
short two_tree::tree_wordbook_8[512]
{ 0,1,2,3,4,5,6,7,8,0,0,9,0,0,10,11,0,0,12,0,0,13,14,15,0,0,16,0,0,17,18,0,0,19,0,0,20,21,22,23,0,0,24,0,0,25,26,0,0,27,0,0,28,29,30,0,0,31,0,0,32,33,0,0,34,0,0,35,36,37,38,39,0,0,40,0,0,41,42,0,0,43,0,0,44,45,46,0,0,47,0,0,48,49,0,0,50,0,0,51,52,53,54,0,0,55,0,0,56,57,0,0,58,0,0,59,60,61,0,0,62,0,0,63,64,0,0,65,0,0,66,67,68,69,70,71,0,0,72,0,0,73,74,0,0,75,0,0,76,77,78,0,0,79,0,0,80,81,0,0,82,0,0,83,84,85,86,0,0,87,0,0,88,89,0,0,90,0,0,91,92,93,0,0,94,0,0,95,96,0,0,97,0,0,98,99,100,101,102,0,0,103,0,0,104,105,0,0,106,0,0,107,108,109,0,0,110,0,0,111,112,0,0,113,0,0,114,115,116,117,0,0,118,0,0,119,120,0,0,121,0,0,122,123,124,0,0,125,0,0,126,127,0,0,
128,0,0,129,130,131,132,133,134,135,0,0,136,0,0,137,138,0,0,139,0,0,140,141,142,0,0,143,0,0,144,145,0,0,146,0,0,147,148,149,150,0,0,151,0,0,152,153,0,0,154,0,0,155,156,157,0,0,158,0,0,159,160,0,0,161,0,0,162,163,164,165,166,0,0,167,0,0,168,169,0,0,170,0,0,171,172,173,0,0,174,0,0,175,176,0,0,177,0,0,178,179,180,181,0,0,182,0,0,183,184,0,0,185,0,0,186,187,188,0,0,189,0,0,190,191,0,0,192,0,0,193,194,195,196,197,198,0,0,199,0,0,200,201,0,0,202,0,0,203,204,205,0,0,206,0,0,207,208,0,0,209,0,0,210,211,212,213,0,0,214,0,0,215,216,0,0,217,0,0,218,219,220,0,0,221,0,0,222,223,0,0,224,0,0,225,226,227,228,229,0,0,230,0,0,231,232,0,0,233,0,0,234,235,236,0,0,237,0,0,238,239,0,0,240,0,0,241,242,243,244,0,0,245,0,0,246,247,0,0,248,0,0,249,250,251,0,0,252,0,0,253,254,0,0,255,0,0 };

two_tree::two_tree()
{
	addup_node = 0;
	addup_lever = 0;
	array_date = 0;
	array_node = 0;
	array_point = 0;
	tree_node_num = 0;
	create_is_node_num = 0;
	create_is_need_node_num = 0;
}

two_tree::~two_tree()
{
	
}

void two_tree::set_two_tree(Ttree * t_node, short node_lever)
{
	if (addup_lever == 0 && addup_node == 0) {//创建一棵树
		addup_node = 1;
	}
	else//新建一棵树
	{
		destroy_tree(t_node);
	}
	addup_lever = node_lever;
	switch (node_lever)
	{
	case 1:
		node_num = tree_wordbook_1;
		break;
	case 2:
		node_num = tree_wordbook_2;
		break;
	case 3:
		node_num = tree_wordbook_3;
		break;
	case 4:
		node_num = tree_wordbook_4;
		break;
	case 5:
		node_num = tree_wordbook_5;
		break;
	case 6:
		node_num = tree_wordbook_6;
		break;
	case 7:
		node_num = tree_wordbook_7;
		break;
	case 8:
		node_num = tree_wordbook_8;
		break;
	}
}

Ttree * two_tree::create_node(string pos, short node[])//pos表示该节点的位置,node表示创建的节点数目
{
	Ttree * t_tree = new Ttree;

	++node;
	t_tree->node_id = *node;
	if (t_tree->node_id == 0) {
		return nullptr;
	}
	*node += (addup_lever - 1);//递归原理
	t_tree->date = 0;
	t_tree->p_date = NULL;
	t_tree->left = create_node("left", node);
	t_tree->right = create_node("right", node);
	return t_tree;
}

int two_tree::create_new_node(Ttree *& t_node)
{
	if (!t_node)return 0;
	Ttree * go_there;
	if (create_is_need_node_num == create_is_node_num) {//进行一次创建初始化
		create_is_node_num = 0;//复位
		tree_node_num = 0;//
		array_point = 0;//
		create_node_lever = get_tree_H_num(t_node);
		create_is_need_node_num = static_cast<int>(pow(2, create_node_lever));
		create_node_add_id = create_node_lever;
		get_node_point(t_node, after_go_there);
		addup_node = get_tree_node_num(t_node);
	}
	for (int i = 0; i < addup_node; i++)
	{
		int after_node_id;
		go_there = after_go_there[i];
		if (after_go_there[i]->left == nullptr && after_go_there[i]->right == nullptr) {//先创建左节点
			if (create_is_node_num % 2 == 0) {
				create_is_node_num += 1;
				create_node_add_id += create_node_lever;
				Ttree * new_node = new Ttree;
				after_node_id = go_there->node_id;
				go_there->left = new_node;
				new_node->node_id = after_node_id + create_node_add_id;
				new_node->date = 0;
				new_node->p_date = NULL;
				new_node->left = nullptr;
				new_node->right = nullptr;
				break;
			}
			else
			{
				continue;
			}
		}
		else if (after_go_there[i]->right == nullptr) {//再创建右节点
			if (create_is_node_num % 2 == 1) {
				create_is_node_num += 1;
				create_node_add_id += create_node_lever;
				Ttree * new_node = new Ttree;
				after_node_id = go_there->node_id;
				go_there->right = new_node;
				new_node->node_id = after_node_id + create_node_add_id;
				new_node->date = 0;
				new_node->p_date = NULL;
				new_node->left = nullptr;
				new_node->right = nullptr;
				break;
			}
			else
			{
				continue;
			}
		}
	}
	tree_node_num = 0;
	return 0;
}

void two_tree::destroy_tree(Ttree *& t_node)
{
	if (t_node) {
		destroy_tree(t_node->left);
		destroy_tree(t_node->right);

		delete t_node;
	}
}

void two_tree::clean_tree(Ttree * t_node)
{
	if (t_node) {
		t_node->date = 0;
		t_node->p_date = NULL;
		clean_tree(t_node->left);
		clean_tree(t_node->right);
	}
}

int two_tree::modify_node_date(Ttree * t_node, int your_date)
{
	get_node_point(t_node, after_go_there);
	addup_node = get_tree_node_num(t_node);
	tree_node_num = 0;
	for (int i = 0; i < addup_node; i++)
	{
		for (int j = 0; j < addup_node; j++) {
			if (i == j)j++;
			if (j == addup_node)break;
			if (after_go_there[i]->node_id >= after_go_there[j]->node_id) {
				if (after_go_there[j]->date == 0)in_point = after_go_there[j];
			}
		}
		if (i == addup_node - 1)return 0;
	}
	in_point->date = your_date;
	return 1;
}

int two_tree::modify_node_date(Ttree * t_node, int * your_date)
{
	get_node_point(t_node, after_go_there);
	addup_node = get_tree_node_num(t_node);
	tree_node_num = 0;
	for (int i = 0; i < addup_node; i++)
	{
		for (int j = 0; j < addup_node; j++) {
			if (i == j)j++;
			if (j == addup_node)break;
			if (after_go_there[i]->node_id >= after_go_there[j]->node_id) {
				if (after_go_there[j]->p_date == NULL)in_point = after_go_there[j];
			}
		}
		if (i == addup_node - 1)return 0;
	}
	in_point->p_date = your_date;
	return 1;
}

int two_tree::modify_node_date(Ttree * t_node, int your_date, short n_id)
{
	int goback = 0;
	int lever = node_in_lever(n_id);
	if (t_node) {
		if (lever == 1) {
			goback = pre_order(t_node, your_date, n_id);
			return goback;
		}
		else if (lever == 2) {
			goback = ldr_order(t_node, your_date, n_id);
			return goback;
		}
		else if (lever == 3) {
			goback = lrd_order(t_node, your_date, n_id);
			return goback;
		}
	}
	return goback;
}

int two_tree::modify_node_date(Ttree * t_node, int * your_date, short n_id)
{
	int goback = 0;
	int lever = node_in_lever(n_id);
	if (lever == 1) {
		goback = pre_order(t_node, your_date, n_id);
		return goback;
	}
	else if (lever == 2) {
		goback = ldr_order(t_node, your_date, n_id);
		return goback;
	}
	else if (lever == 3) {
		goback = lrd_order(t_node, your_date, n_id);
		return goback;
	}
	return goback;
}

int two_tree::modify_node_date(Ttree * t_node, short min_n_id, short max_n_id, int your_date[], int ar_num)
{
	in_array = ar_num;
	int goback = 0;
	min = min_n_id;
	max = max_n_id;
	short ar_node[512];

	get_pre_order_node(t_node, ar_node);
	array_node = 0;
	goback = modify_pre_order_node_date(t_node, ar_node, your_date);
	array_date = 0;
	array_node = 0;
	return goback;
}

int two_tree::get_node_date(Ttree * t_node, short n_id)
{
	static int date;
	int lever = node_in_lever(n_id);
	if (t_node) {
		if (lever == 1) {
			get_pre_order(t_node, n_id, date);
			return date;
		}
		else if (lever == 2) {
			get_ldr_order(t_node, n_id, date);
			return date;
		}
		else if (lever == 3) {
			get_lrd_order(t_node, n_id, date);
			return date;
		}
	}
	return 0;//没找到
}

int * two_tree::get_node_date(Ttree * t_node, short min_n_id, short max_n_id ,int ar_date[])
{
	min = min_n_id;
	max = max_n_id;
	short ar_node[512];

	get_pre_order_node(t_node, ar_node);
	array_node = 0;
	get_pre_order(t_node, ar_node, ar_date);
	array_date = 0;
	array_node = 0;
	return ar_date;
}

void two_tree::node_pre_order(Ttree * t_node)
{
	if (t_node) {//节点不为空，则输出该点，下同
		get_date(t_node);
		node_pre_order(t_node->left);
		node_pre_order(t_node->right);
	}
}

void two_tree::node_ldr_order(Ttree * t_node)
{
	if (t_node) {
		node_ldr_order(t_node->left);
		get_date(t_node);
		node_ldr_order(t_node->right);
	}
}

void two_tree::node_lrd_order(Ttree * t_node)
{
	if (t_node) {
		node_lrd_order(t_node->left);
		node_lrd_order(t_node->right);
		get_date(t_node);
	}
}

int two_tree::get_tree_H_num(Ttree * t_node)
{
	if (!t_node)return 0;
	Ttree * go_left;
	Ttree * go_right;
	Ttree * go_there;
	tree_H_num = 2;//树高
	go_left = t_node->left;
	go_right = t_node->right;

	if (go_left->node_id <= go_right->node_id) {
		go_there = go_left;
	}
	else
	{
		go_there = go_right;
	}
	while (true)
	{
		if (go_there->left == nullptr && go_there->right == nullptr) {
			break;
		}
		else if (go_there->left == nullptr || go_there->right == nullptr) {
			tree_H_num++;
			break;
		}
		if (go_there->left->node_id <= go_there->right->node_id) {
			go_there = go_there->left;
		}
		else
		{
			go_there = go_there->right;
		}
		tree_H_num++;
	}
	return tree_H_num;
}

int two_tree::get_tree_node_num(Ttree * t_node)
{
	if (t_node) {
		get_tree_node_num(t_node->left);
		get_tree_node_num(t_node->right);
	}
	else if (!t_node) {
		return (tree_node_num++);
	}
}

int two_tree::avo_of_rep_for_node_date(Ttree * t_node)
{
	int goback = 0;
	int ar_date[512];
	short ar_node[512];
	tree_node_num = get_tree_node_num(t_node);
	get_node_date(t_node, 1, 10000, ar_date);
	get_pre_order_node(t_node, ar_node);
	array_date = 0;
	array_node = 0;
	for (int i = 0; i < tree_node_num; i++)//遍历所有的数据
	{
		for (int j = 0; j < tree_node_num; j++) {
			if (j == i)j++;
			if (j == tree_node_num)break;
			if (ar_date[i] == ar_date[j]) {
				avo_of_rep_for_node_date(t_node, ar_node[j]);
				goback = 1;
			}
		}
	}
	return goback;//没有可删除的数据（0）,已经复位重复的数据（1）
}

void two_tree::get_date(Ttree * t_node)
{
	cout << t_node->node_id << ":" << t_node->date << endl;
}

int two_tree::node_in_lever(short n_id)
{
	if (n_id < 5)return 1;
	else if (n_id >= 5 && n_id < 12)return 2;
	else if (n_id >= 12 && n_id < 25)return 2;
	else if (n_id >= 25 && n_id < 50)return 2;
	else if (n_id >= 50 && n_id < 80)return 2;
	else if (n_id >= 80 && n_id <= 256)return 3;
	return 0;//没找到
}

int two_tree::node_in_lever(short min_n_id, short max_n_id)
{
	if (max_n_id < 5)return 1;
	else if (min_n_id >= 5 && max_n_id < 12)return 2;
	else if (min_n_id >= 12 && max_n_id < 25)return 2;
	else if (min_n_id >= 25 && max_n_id < 50)return 2;
	else if (min_n_id >= 50 && max_n_id < 80)return 2;
	else if (min_n_id >= 80 && max_n_id <= 256)return 3;
	return 0;//没找到
}

//注意node_in_lever函数中的范围最大为256；
//若查询失败，很可能是因为需要查询的树的节点id大于了该值。

short two_tree::pre_order(Ttree * t_node, int & your_date, short & n_id)
{
	if (t_node) {
		if (t_node->node_id == n_id) {
			t_node->date = your_date;
			return 1;
		}
		pre_order(t_node->left, your_date, n_id);
		pre_order(t_node->right, your_date, n_id);
	}
	else
	{
		return 0;
	}
}

short two_tree::ldr_order(Ttree * t_node, int & your_date, short & n_id)
{
	if (t_node) {
		pre_order(t_node->left, your_date, n_id);
		if (t_node->node_id == n_id) {
			t_node->date = your_date;
			return 1;
		}
		pre_order(t_node->right, your_date, n_id);
	}
	else
	{
		return 0;
	}
}

short two_tree::lrd_order(Ttree * t_node, int & your_date, short & n_id)
{
	if (t_node) {
		pre_order(t_node->left, your_date, n_id);
		pre_order(t_node->right, your_date, n_id);
		if (t_node->node_id == n_id) {
			t_node->date = your_date;
			return 1;
		}
	}
	else
	{
		return 0;
	}
}

short two_tree::pre_order(Ttree * t_node, int *& your_date, short & n_id)
{
	if (t_node) {
		if (t_node->node_id == n_id) {
			t_node->p_date = your_date;
			return 1;
		}
		pre_order(t_node->left, your_date, n_id);
		pre_order(t_node->right, your_date, n_id);
	}
	else
	{
		return 0;
	}
}

short two_tree::ldr_order(Ttree * t_node, int *& your_date, short & n_id)
{
	if (t_node) {
		ldr_order(t_node->left, your_date, n_id);
		if (t_node->node_id == n_id) {
			t_node->p_date = your_date;
			return 1;
		}
		ldr_order(t_node->right, your_date, n_id);
	}
	else
	{
		return 0;
	}
}

short two_tree::lrd_order(Ttree * t_node, int *& your_date, short & n_id)
{
	if (t_node) {
		lrd_order(t_node->left, your_date, n_id);
		lrd_order(t_node->right, your_date, n_id);
		if (t_node->node_id == n_id) {
			t_node->p_date = your_date;
			return 1;
		}
	}
	else
	{
		return 0;
	}
}

short two_tree::get_pre_order(Ttree * t_node, short & n_id, int & need)
{
	if (t_node) {
		if (t_node->node_id == n_id) {
			need = t_node->date;
			return 1;
		}
		get_pre_order(t_node->left, n_id, need);
		get_pre_order(t_node->right, n_id, need);
	}
	else
	{
		return 0;
	}
}

short two_tree::get_ldr_order(Ttree * t_node, short & n_id, int & need)
{
	if (t_node) {
		get_ldr_order(t_node->left, n_id, need);
		if (t_node->node_id == n_id) {
			need = t_node->date;
			return 1;
		}
		get_ldr_order(t_node->right, n_id, need);
	}
	else
	{
		return 0;
	}
}

short two_tree::get_lrd_order(Ttree * t_node, short & n_id, int & need)
{
	if (t_node) {
		get_lrd_order(t_node->left, n_id, need);
		get_lrd_order(t_node->right, n_id, need);
		if (t_node->node_id == n_id) {
			need = t_node->date;
			return 1;
		}
	}
	else
	{
		return 0;
	}
}

void two_tree::get_pre_order(Ttree * t_node, short n_id[], int ar_date[])
{
	if (t_node) {
		if (t_node->node_id == n_id[array_node]) {
			ar_date[array_date] = t_node->date;
			array_date++;
			array_node++;
		}
		get_pre_order(t_node->left, n_id, ar_date);
		get_pre_order(t_node->right, n_id, ar_date);
	}
}

void two_tree::get_pre_order_node(Ttree * t_node, short n_id[])
{
	if (t_node) {
		if (t_node->node_id >= min && t_node->node_id <= max) {
			n_id[array_node] = t_node->node_id;
			array_node++;
		}
		get_pre_order_node(t_node->left, n_id);
		get_pre_order_node(t_node->right, n_id);
	}
}

void two_tree::get_node_point(Ttree * t_root, Ttree * t_node[])
{
	if (t_root) {
		t_node[array_point] = t_root;
		array_point++;
		get_node_point(t_root->left, t_node);
		get_node_point(t_root->right, t_node);
	}
}

short two_tree::modify_pre_order_node_date(Ttree * t_node, short n_id[], int your_date[])
{
	if (t_node) {
		if (t_node->node_id == n_id[array_node]) {
			in_array -= 1;
			if (in_array == 0) {//防止添加未初始化的数据
				return 1;
			}
			else
			{
				t_node->date = your_date[array_date];
				array_date++;
				array_node++;
			}
		}
		modify_pre_order_node_date(t_node->left, n_id, your_date);
		modify_pre_order_node_date(t_node->right, n_id, your_date);
	}
	else
	{
		return 0;
	}
}

short two_tree::avo_of_rep_for_node_date(Ttree * t_node, short n_id)
{
	if (t_node) {
		if (t_node->node_id == n_id) {
			t_node->date = 0;
			t_node->p_date = NULL;
			return 1;
		}
		avo_of_rep_for_node_date(t_node->left, n_id);
		avo_of_rep_for_node_date(t_node->right, n_id);
	}

	return 0;//没复位成功
}
#include"ai_sys.h"

ai_sys::ai_sys()
{

}

ai_sys::~ai_sys()
{

}
#include"physics_sys.h"

physics_sys::physics_sys()
{

}

physics_sys::~physics_sys()
{

}
﻿#include"set_map.h"
#include<iostream>

using std::cout;
using std::endl;

Set_map::Set_map(Map_sys & map_date)
{
	name = new std::string[map_date.get_map_num()];
	name = map_date.get_map_name();
	pid = 0;
}

Set_map::~Set_map()
{
}

void Set_map::init_bmp_flg()
{
	bitmap_id = 0;
}

void Set_map::init_map_table(Map_sys & map_date, unit_elem & map_context, unit_elem & map_unit, animation_elem & map_context_animation, animation_elem & map_unit_animation)
{
	int x = 0;
	int y = 0;
	int z = map_date.get_map_date().map_z;
	int map_w, map_h;
	static int * map_table = nullptr;
	static unit_sys::Unit unit;
	static animation_sys::Animation animation;

	map_table = get_map_table(z, map_date.get_map_date().name, map_w, map_h);
	if (map_table != nullptr) {
		map_date.set_map_table(map_w*map_h, map_table);
		init_bmp_flg();

		map_context.elem_head = map_context.create_Unit_elem(1);
		map_context_animation.elem_head = map_context_animation.create_Animation_elem(1);
		map_unit.elem_head = map_unit.create_Unit_elem(1);
		map_unit_animation.elem_head = map_unit_animation.create_Animation_elem(1);

		for (int pos = 0, w = 0; pos < map_w * map_h; pos++, w++, x += 64)
		{
			if (w == map_w) {
				w = 0;
				x = 0;
				y += 64;
			}
			switch (map_table[pos])
			{
			case 0:
				black(x, y, z, unit, animation);
				break;
			case 1:
				cement_floor(x, y, z, unit, animation);
				break;
			case 2:
				grass(x, y, z, unit, animation);
				break;
			case 3:
				wood_box(x, y, z, unit, animation);
				break;
			}

			if (unit.state.u_itme_id == 0 || unit.state.u_itme_id >= 3) {
				if (!map_unit.Unit_elem_is_state(map_unit.elem_head)) {
					map_unit.create_new_node();
					map_unit_animation.create_new_node();
				}
				map_unit.in_Unit_elem_date_is_null(map_unit.elem_head, unit);
				map_unit_animation.in_Animation_elem_date_is_null(map_unit_animation.elem_head, animation);
			}
			else {
				if (!map_context.Unit_elem_is_state(map_context.elem_head)) {
					map_context.create_new_node();
					map_context_animation.create_new_node();
				}
				map_context.in_Unit_elem_date_is_null(map_context.elem_head, unit);
				map_context_animation.in_Animation_elem_date_is_null(map_context_animation.elem_head, animation);
			}
		}
	}
	else
		cout << "获取地图表格时出错！" << endl;

	static Unit u[100];
	static animation_elem::Animation anima[100];
	int wood_box_unit_num = 0;
	int wood_box_animation_num = 0;
	string wood_box_name = "wood_box";

	for (int i = 0; i < 100; i++) {
		u[i].state.u_itme_id = -1;
		anima[i].bitmap_name = "null";
	}
	map_unit.get_Unit_elem_arr_date(map_unit.elem_head, u);
	map_unit_animation.get_Animation_elem_arr_date(map_unit_animation.elem_head, anima);
	for (int i = 0; i < 100; i++)
	{
		if (u[i].state.u_itme_id == 3)
			wood_box_unit_num += 1;
		if (anima[i].bitmap_name.compare(wood_box_name) == 0)
			wood_box_animation_num += 1;
	}
}

int * Set_map::get_map_table(int map_z, string map_name, int & map_w, int & map_h)
{
	const int map_num = 2;
	static int * map_table = nullptr;

	if (name[0].compare(map_name) == 0)
		map_table = test_of_table(map_z, map_w, map_h);
	else if (name[1].compare(map_name) == 0)
		map_table = fire_island_of_table(map_z, map_w, map_h);

	return map_table;
}

int * Set_map::test_of_table(int map_z, int & map_w, int & map_h)
{
	switch (map_z)
	{
	case 0:
		const int mw = 10;
		const int mh = 10;
		static int map_table[100]
		{
			Grassd,WoodBx,Grassd,Grassd,WoodBx,  WoodBx,WoodBx,Grassd,Grassd,WoodBx,
			Grassd,Grassd,Grassd,Grassd,Grassd,  WoodBx,WoodBx,Grassd,Grassd,WoodBx,
			Grassd,Grassd,Grassd,Grassd,Grassd,  Grassd,Grassd,Grassd,Grassd,WoodBx,
			Grassd,Grassd,Grassd,Grassd,Grassd,  Grassd,Grassd,Grassd,Grassd,WoodBx,
			Grassd,Grassd,Grassd,Grassd,Grassd,  Grassd,Grassd,Grassd,Grassd,Grassd,

			WoodBx,Grassd,Grassd,Grassd,Grassd,  Grassd,Grassd,Grassd,Grassd,WoodBx,
			CemFlo,CemFlo,CemFlo,CemFlo,CemFlo,  CemFlo,CemFlo,CemFlo,CemFlo,CemFlo,
			CemFlo,CemFlo,CemFlo,CemFlo,CemFlo,  CemFlo,CemFlo,CemFlo,CemFlo,CemFlo,
			CemFlo,CemFlo,CemFlo,CemFlo,CemFlo,  CemFlo,CemFlo,CemFlo,CemFlo,CemFlo,
			CemFlo,CemFlo,CemFlo,CemFlo,CemFlo,  CemFlo,CemFlo,CemFlo,CemFlo,CemFlo
		};

		map_w = mw;
		map_h = mh;
		return map_table;
	}
	return nullptr;
}

int * Set_map::fire_island_of_table(int map_z, int & map_w, int & map_h)
{
	return nullptr;
}



void Set_map::black(int x, int y, int z, unit_sys::Unit & unit, animation_elem::Animation & animation)
{
	unit.axis.u_x = x;
	unit.axis.u_y = y;
	unit.axis.u_z = z;

	init_bitmap(bitmap_id, 1, animation, "black");
	set_bitmap_pid(0, pid, animation);
	set_bitmap_num(0, 1, animation);
	bitmap_id += 1;
	set_bitmap_lever(0, animation);
	set_bitmap_lever(0, 0, animation);

	set_bitmap_name(0, 0, "map_img/static/black.png", "无对象", animation);

	set_bitmap_action_num(0, 1, animation);

	set_bitmap_action_draw_flags(0, 0, true, false, 0, 0, 0, animation);
	set_bitmap_action_axis(0, 0, 0, 0, 0, animation);//单元的绘制位置由相机位置决定
	set_bitmap_action_times(0, 0, 1 / 60.0, animation);//绘制速度与fps同步

	set_bitmap_df_action_flags(0, 0, 0, animation);

	set_unit_axis(x, y, z, 0);
	set_unit_live(false);
	set_unit_itme_id(0);
	set_unit_wh(64, 64);
	set_unit_pid(pid);

	unit.axis = get_unit_axis();
	unit.state.u_is_live = get_unit_is_live();
	unit.state.u_itme_id = get_unit_itme_id();
	unit.wh.u_w = get_unit_w();
	unit.wh.u_h = get_unit_h();
	unit.state.u_pid = get_unit_object_id();
	pid += 1;
}

void Set_map::cement_floor(int x, int y, int z, unit_sys::Unit & unit, animation_elem::Animation & animation)
{
	unit.axis.u_x = x;
	unit.axis.u_y = y;
	unit.axis.u_z = z;

	init_bitmap(bitmap_id, 1, animation, "cement_floor");
	set_bitmap_pid(0, pid, animation);
	set_bitmap_num(0, 1, animation);
	bitmap_id += 1;
	set_bitmap_lever(0, animation);
	set_bitmap_lever(0, 0, animation);

	set_bitmap_name(0, 0, "map_img/static/cement_floor.png", "水泥地", animation);

	set_bitmap_action_num(0, 1, animation);

	set_bitmap_action_draw_flags(0, 0, true, false, 0, 0, 0, animation);
	set_bitmap_action_axis(0, 0, 0, 0, 0, animation);//单元的绘制位置由相机位置决定
	set_bitmap_action_times(0, 0, 1 / 60.0, animation);//绘制速度与fps同步

	set_bitmap_df_action_flags(0, 0, 0, animation);

	set_unit_axis(x, y, z, 0);
	set_unit_live(false);
	set_unit_itme_id(1);
	set_unit_wh(64, 64);
	set_unit_pid(pid);

	unit.axis = get_unit_axis();
	unit.state.u_is_live = get_unit_is_live();
	unit.state.u_itme_id = get_unit_itme_id();
	unit.wh.u_w = get_unit_w();
	unit.wh.u_h = get_unit_h();
	unit.state.u_pid = get_unit_object_id();
	pid += 1;
}

void Set_map::grass(int x, int y, int z, unit_sys::Unit & unit, animation_elem::Animation & animation)
{
	unit.axis.u_x = x;
	unit.axis.u_y = y;
	unit.axis.u_z = z;

	init_bitmap(bitmap_id, 1, animation, "grass");
	set_bitmap_pid(0, pid, animation);
	bitmap_id += 1;
	set_bitmap_num(0, 1, animation);
	set_bitmap_lever(0, animation);
	set_bitmap_lever(0, 0, animation);

	set_bitmap_name(0, 0, "map_img/static/grass.png", "草地", animation);

	set_bitmap_action_num(0, 1, animation);

	set_bitmap_action_draw_flags(0, 0, true, false, 0, 0, 0, animation);
	set_bitmap_action_axis(0, 0, 0, 0, 0, animation);//单元的绘制位置由相机位置决定
	set_bitmap_action_times(0, 0, 1 / 60.0, animation);//绘制速度与fps同步

	set_bitmap_df_action_flags(0, 0, 0, animation);

	set_unit_axis(x, y, z, 0);
	set_unit_live(false);
	set_unit_itme_id(2);
	set_unit_wh(64, 64);
	set_unit_pid(pid);

	unit.axis = get_unit_axis();
	unit.state.u_is_live = get_unit_is_live();
	unit.state.u_itme_id = get_unit_itme_id();
	unit.wh.u_w = get_unit_w();
	unit.wh.u_h = get_unit_h();
	unit.state.u_pid = get_unit_object_id();
	pid += 1;
}

void Set_map::wood_box(int x, int y, int z, unit_sys::Unit & unit, animation_elem::Animation & animation)
{
	unit.axis.u_x = x;
	unit.axis.u_y = y;
	unit.axis.u_z = z;

	init_bitmap(bitmap_id, 1, animation, "wood_box");
	set_bitmap_pid(0, pid, animation);
	set_bitmap_num(0, 1, animation);
	set_bitmap_lever(0, animation);
	set_bitmap_lever(0, 0, animation);

	set_bitmap_name(0, 0, "map_img/static/wood_box.png", "木箱子", animation);

	set_bitmap_action_num(0, 1, animation);

	set_bitmap_action_draw_flags(0, 0, true, false, 0, 0, 0, animation);
	set_bitmap_action_axis(0, 0, 0, 0, 0, animation);//单元的绘制位置由相机位置决定
	set_bitmap_action_times(0, 0, 1 / 60.0, animation);//绘制速度与fps同步

	set_bitmap_df_action_flags(0, 0, 0, animation);

	set_unit_axis(x, y, z, 0);
	set_unit_hp(10000);
	set_unit_live(true);
	set_unit_itme_id(3);
	set_unit_wh(64, 64);
	set_unit_pid(pid);

	unit.axis = get_unit_axis();
	unit.state.u_hp = get_unit_hp();
	unit.state.u_is_live = get_unit_is_live();
	unit.state.u_itme_id = get_unit_itme_id();
	unit.wh.u_w = get_unit_w();
	unit.wh.u_h = get_unit_h();
	unit.state.u_pid = get_unit_object_id();
	bitmap_id += 1;
	pid += 1;
}

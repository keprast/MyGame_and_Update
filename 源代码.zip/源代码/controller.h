﻿#ifndef controller_
#define controller_

#include"allegro5\allegro.h"
#include"state_transition.h"
#include"con_action.h"

class controller :public con_action
{
public:
	//对象数为最大可操控对象，t_i为
	controller(int obj_num, int t_i, int t_j);
	~controller();

	//初始化主页逻辑
	void init_index_logic();
	//初始化主页关于的逻辑
	void init_index_about_logic();
	//初始化主页设置的逻辑
	void init_index_config_logic();

	//控制窗口位置
	int windows_pos_transition();
	//注册玩家数据（w_pos需要窗口位置函数的转换）
	void reg_date_in_gui(int w_pos, player_sys::Player_opertion & pdate);
	//注册玩家数据
	void reg_date_in_gui();
	//注册电脑数据
	void register_ai_date();
	//获取运行转换结果
	Tran_id_plus * get_service_state();

	//设定当前的窗口
	void set_now_windows(int w_pos);
	//获得当前的窗口
	int get_now_windows();

private:
	int now_windows;//当前的窗口

};

#endif
﻿#include"Gui_sys.h"

int Gui_sys::gui_num = 0;//Gui的数目
int Gui_sys::after_gui_name = -1;//上一个Gui的名字
int Gui_sys::now_gui_name = -1;//当前Gui的名字
Gui_config * Gui_sys::gui_animation = nullptr;//Gui动画

Gui_sys::Gui_sys(int gui_e_num)
{
	set_op_obj_num(gui_e_num);
	elem_head = create_Animation_elem(gui_e_num);
}

Gui_sys::~Gui_sys()
{
	destroy_Animation_elem(elem_head);
}

void Gui_sys::init_gui()
{
	const int gui_n = 4;
	gui_num = gui_n;

	static Gui_config animation[gui_n];
	gui_animation = animation;

	init_gui_style(animation[INDEX], INDEX);
	init_gui_style(animation[INDEX_StaGame], INDEX_StaGame);
	init_gui_style(animation[INDEX_About], INDEX_About);
	init_gui_style(animation[INDEX_Config], INDEX_Config);
}

void Gui_sys::update_gui(Gui_sys::Gui_name name)
{
	int animation_num = gui_animation[name].get_animation_num();

	if (after_gui_name == -1) {
		now_gui_name = name;
		after_gui_name = now_gui_name;
	}
	else 
		now_gui_name = name;

	for (int i = 0; i < animation_num; i++)
		in_Animation_elem_date_is_null(elem_head, gui_animation[name][i]);
}

int Gui_sys::get_gui_name()
{
	return now_gui_name;
}

void Gui_sys::reg_logic_to_event_queue(Gui_config & obj)
{
	int obj_num = obj.get_animation_num();
	for (int i = 0; i < obj_num; i++)
	{
		int obj_nums = obj.get_animation(i).bitmap_obj_num;
		for (int j = 0; j < obj_nums; j++)
		{
			int obj_numss = obj.get_animation(i).bmp[j].action_num;
			for (int k = 0; k < obj_numss; k++)
				al_register_event_source(event_queue, al_get_timer_event_source(
					obj.get_animation(i).bmp[j].action[k].animation_timer->get_timer()));
		}
	}
}

void Gui_sys::init_gui_style(Gui_config & animation, Gui_name flg)
{
	//改此处
	switch (flg)
	{
	case Gui_sys::INDEX:
		init_index(animation);
		break;
	case Gui_sys::INDEX_About:
		init_index_about(animation);
		break;
	case Gui_sys::INDEX_Config:
		init_index_config(animation);
		break;
	case Gui_sys::INDEX_StaGame:
		init_index_stagame(animation);
		break;
	case Gui_sys::INDEX_StaGames:
		break;
	}

	//注册逻辑到事件队列
	reg_logic_to_event_queue(animation);
}

void Gui_sys::init_index(Gui_config & obj)
{
	obj.add_context("首页背景", obj.index);
	obj.add_animation("右下角测试", obj.Frie, 1180, 620, 4, 0, 0, 3, 0.5, true);
	obj.add_button("demo演示", obj.WhiteRectangle, 200, 200);
	obj.add_button("尝试操作", obj.WhiteRectangle, 200, 325);
	obj.add_button("关于我们", obj.WhiteRectangle, 200, 450);
	obj.add_button("设置按钮", obj.WhiteRectangle, 200, 575);
}

void Gui_sys::init_index_stagame(Gui_config & obj)//待完善
{
	obj.add_context("关于背景", obj.about);
}

void Gui_sys::init_index_about(Gui_config & obj)
{
	obj.add_context("关于背景", obj.about);
	obj.add_button("返回主页", obj.WhiteDiamond, 1180, 620);
}

void Gui_sys::init_index_config(Gui_config & obj)
{
	obj.add_context("游戏设置背景", obj.config);
	obj.add_button("返回主页", obj.WhiteDiamond, 1180, 620);
}

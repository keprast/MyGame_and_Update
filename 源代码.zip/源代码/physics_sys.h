#ifndef physics_sys_
#define physics_sys_

class physics_sys
{
public:
	physics_sys();
	~physics_sys();

private:

};

#endif

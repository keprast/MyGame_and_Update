﻿#ifndef timer_sys_
#define timer_sys_

#include"allegro5\allegro.h"

class timer_sys
{
public:
	timer_sys(double sec);
	~timer_sys();

	//获取计时器计时数
	double get_timer_sec();
	//获取计时器
	ALLEGRO_TIMER * get_timer();

private:
	double sec;//计时时间
	ALLEGRO_TIMER * timer;//计时器

};

#endif

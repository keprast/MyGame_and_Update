﻿#include "debug.h"
#include<iostream>
#include<fstream>

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::ios;

long start_time = 0, end_time = 0;

void get_out_message_to_text(Output_flg flg, char * ch, char * ch_flg)
{
	if (flg == Error) {
		ofstream error_output("debug_text/Error.txt", ios::app);
		error_output << "!错误：" << ch << endl;
	}
	else if (flg == Tip) {
		ofstream tip_output("debug_text/Tip.txt", ios::app);
		tip_output << "?提示：" << ch << endl;
	}
	else if (flg == Text) {
		ofstream tip_output("debug_text/Tip.txt", ios::app);
		tip_output << "?提示：" << ch << endl;
	}
	else if (flg == X_axis || flg == Y_axis || flg == Z_axis || flg == Arc_p) {
		ofstream axis_output("debug_text/Axis.txt", ios::app);
		switch (flg)
		{
		case X_axis:
			axis_output << "X：" << ch << endl;
			break;
		case Y_axis:
			axis_output << "Y：" << ch << endl;
			break;
		case Z_axis:
			axis_output << "Z：" << ch << endl;
			break;
		case Arc_p:
			axis_output << "Arc：" << ch << endl;
			break;
		}
	}
}

void get_out_message_to_text(Output_flg flg, string & ch, char * ch_flg)
{
	ofstream output("debug_text/debug.txt", ios::app);

	if (flg == Error) {
		ofstream error_output("debug_text/Error.txt", ios::app);
		error_output << "!错误：" << ch << endl;
	}
	else if (flg == Tip) {
		ofstream tip_output("debug_text/Tip.txt", ios::app);
		tip_output << "?提示：" << ch << endl;
	}
	else if (flg == Text) {
		ofstream tip_output("debug_text/Tip.txt", ios::app);
		tip_output << "?提示：" << ch << endl;
	}
	else if (flg == X_axis || flg == Y_axis || flg == Z_axis || flg == Arc_p) {
		ofstream axis_output("debug_text/Axis.txt", ios::app);
		switch (flg)
		{
		case X_axis:
			axis_output << "X：" << ch << endl;
			break;
		case Y_axis:
			axis_output << "Y：" << ch << endl;
			break;
		case Z_axis:
			axis_output << "Z：" << ch << endl;
			break;
		case Arc_p:
			axis_output << "Arc：" << ch << endl;
			break;
		}
	}
}

char * int_tran_to_char(int num)
{
	static int num_bit;
	static char ch_arr[3];
	static int num_arr[3];
	for (int i = 0; i < 3; i++)
		ch_arr[i] = '\0';

	if (num < 10) {
		num_bit = 1;
		num_arr[0] = num;
	}
	else if (num >= 10 && num < 100) {
		num_bit = 2;
		num_arr[0] = num / 10;
		num_arr[1] = num - num_arr[0] * 10;
	}
	else if (num >= 100 && num < 1000) {
		num_bit = 3;
		num_arr[0] = num / 100;
		num_arr[1] = (num - num_arr[0] * 100) / 10;
		num_arr[2] = (num - num_arr[0] * 100) - num_arr[1] * 10;
	}
	else if (num >= 1000)
		return "ERROR";

	for (int i = 0; i < num_bit; i++)
	{
		switch (num_arr[i])
		{
		case 0:
			ch_arr[i] = '0';
			break;
		case 1:
			ch_arr[i] = '1';
			break;
		case 2:
			ch_arr[i] = '2';
			break;
		case 3:
			ch_arr[i] = '3';
			break;
		case 4:
			ch_arr[i] = '4';
			break;
		case 5:
			ch_arr[i] = '5';
			break;
		case 6:
			ch_arr[i] = '6';
			break;
		case 7:
			ch_arr[i] = '7';
			break;
		case 8:
			ch_arr[i] = '8';
			break;
		case 9:
			ch_arr[i] = '9';
			break;
		}
	}
	return ch_arr;
}

char * float_tran_to_char(float num)
{
	static int num_bit, num_buffer;
	static int fnum_buffer;
	static char ch_arr[8];
	static int num_arr[8];
	for (int i = 0; i < 8; i++)
		ch_arr[i] = '\0';

	num_buffer = static_cast<int>(num);
	fnum_buffer = static_cast<int>((num - num_buffer) * 10);
	if (num < 10) {
		num_bit = 3;
		num_arr[0] = static_cast<int>(num);
		num_arr[1] = -1;
		num_arr[2] = fnum_buffer;
	}
	else if (num < 100) {
		num_bit = 4;
		num_arr[0] = num_buffer / 10;
		num_arr[1] = num_buffer - num_arr[0] * 10;
		num_arr[2] = -1;
		num_arr[3] = fnum_buffer;
	}
	else if (num < 1000) {
		num_bit = 5;
		num_arr[0] = num_buffer / 100;
		num_arr[1] = (num_buffer - num_arr[0] * 100) / 10;
		num_arr[2] = (num_buffer - num_arr[0] * 100) - num_arr[1] * 10;
		num_arr[3] = -1;
		num_arr[4] = fnum_buffer;
	}
	else if (num < 10000) {
		num_bit = 6;
		num_arr[0] = num_buffer / 1000;
		num_arr[1] = (num_buffer - num_arr[0] * 1000) / 100;
		num_arr[2] = ((num_buffer - num_arr[0] * 1000) - num_arr[1] * 100) / 10;
		num_arr[3] = (num_buffer - num_arr[0] * 1000) - (num_arr[1] * 100 + num_arr[2] * 10);
		num_arr[4] = -1;
		num_arr[5] = fnum_buffer;
	}
	else if (num < 100000) {
		num_bit = 7;
		num_arr[0] = num_buffer / 10000;
		num_arr[1] = (num_buffer - num_arr[0] * 10000) / 1000;
		num_arr[2] = ((num_buffer - num_arr[0] * 10000) - num_arr[1] * 1000) / 100;
		num_arr[3] = ((num_buffer - num_arr[0] * 10000) - (num_arr[1] * 1000 + num_arr[2] * 100)) / 10;
		num_arr[4] = (num_buffer - num_arr[0] * 10000) - (num_arr[1] * 1000 + num_arr[2] * 100 + num_arr[3] * 10);
		num_arr[5] = -1;
		num_arr[6] = fnum_buffer;
	}
	else if (num < 1000000) {
		num_bit = 8;
		num_arr[0] = num_buffer / 100000;
		num_arr[1] = (num_buffer - num_arr[0] * 100000) / 10000;
		num_arr[2] = ((num_buffer - num_arr[0] * 100000) - num_arr[1] * 10000) / 1000;
		num_arr[3] = ((num_buffer - num_arr[0] * 100000) - (num_arr[1] * 10000 + num_arr[2] * 1000)) / 100;
		num_arr[4] = ((num_buffer - num_arr[0] * 100000) - (num_arr[1] * 10000 + num_arr[2] * 1000 + num_arr[3] * 100)) / 10;
		num_arr[5] = (num_buffer - num_arr[0] * 100000) - (num_arr[1] * 10000 + num_arr[2] * 1000 + num_arr[3] * 100 + num_arr[4] * 10);
		num_arr[6] = -1;
		num_arr[7] = fnum_buffer;
	}
	else
		return "ERROR";

	for (int i = 0; i < num_bit; i++)
	{
		switch (num_arr[i])
		{
		case -1:
			ch_arr[i] = '.';
			break;
		case 0:
			ch_arr[i] = '0';
			break;
		case 1:
			ch_arr[i] = '1';
			break;
		case 2:
			ch_arr[i] = '2';
			break;
		case 3:
			ch_arr[i] = '3';
			break;
		case 4:
			ch_arr[i] = '4';
			break;
		case 5:
			ch_arr[i] = '5';
			break;
		case 6:
			ch_arr[i] = '6';
			break;
		case 7:
			ch_arr[i] = '7';
			break;
		case 8:
			ch_arr[i] = '8';
			break;
		case 9:
			ch_arr[i] = '9';
			break;
		}
	}
	return ch_arr;
}

void get_run_time(long & sta, long & end)
{
	long sum_time = 0;

	if (end != 0 && sta != 0) {
		sum_time = end - sta;
		cout << sum_time << "ms" << endl;
		cin.get();
	}
}

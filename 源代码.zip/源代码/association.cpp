﻿#include"association.h"

association::Assoc_bmp association::assoc[association::assoc_bnum]{ { -1,false,false } };
association::Assoc_win association::a_win[association::assoc_wnum]{ { -1,false,false } };
bool association::assocw_OK = false;

association::association()
{
}

association::~association()
{
}

void set_bmp_assoc(state_transition_elem::Tran_id * t)
{
	for (int i = 0; i < association::assoc_bnum; i++)
	{
		if (!association::assoc[i].in_assoc) {
			association::assoc[i].in_assoc = true;
			association::assoc[i].assoc_lock = t->assoc_lock;
			association::assoc[i].pid = t->pid;
			association::assoc[i].obj.to_acting_id = t->to_acting_id;
			association::assoc[i].obj.to_bitmap_id = t->to_bitmap_id;
			break;
		}
	}
}

void association::Lock_bmp_assoc(int j_pid, state_transition_elem::Tran_id * t)
{
	for (int i = 0; i < assoc_bnum; i++)
	{
		if (assoc[i].pid == j_pid) {
			assoc[i].assoc_lock = true;
			break;
		}
	}
}

void association::unLock_bmp_assoc(int j_pid, state_transition_elem::Tran_id * t)
{
	for (int i = 0; i < assoc_bnum; i++)
	{
		if (assoc[i].pid == j_pid) {
			assoc[i].assoc_lock = false;
			break;
		}
	}
}

void association::sta_bmp_assoc(int obj_num, state_transition_elem::Tran_id_plus * t_id, int j_pid)
{
	if (j_pid != -1) {
		for (int i = 0; i < assoc_bnum; i++)
		{
			if (assoc[i].in_assoc && assoc[i].pid == j_pid) {
				for (int j = 0; j < obj_num; j++)
				{
					for (int k = 0; k < t_id[j].tran_id_num; k++)
					{
						if (t_id[j].tra_sub_obj[k].pid == assoc[i].pid) {
							t_id[j].tra_sub_obj[k].to_acting_id = assoc[i].obj.to_acting_id;
							t_id[j].tra_sub_obj[k].to_bitmap_id = assoc[i].obj.to_bitmap_id;
							break;
						}
					}
				}
				break;
			}
		}
	}
	else
	{
		for (int i = 0; i < assoc_bnum; i++)
		{
			if (assoc[i].in_assoc) {
				for (int j = 0; j < obj_num; j++)
				{
					for (int k = 0; k < t_id[i].tran_id_num; k++)
					{
						if (assoc[i].pid == t_id[j].tra_sub_obj[k].pid) {
							t_id[j].tra_sub_obj[k].to_acting_id = assoc[i].obj.to_acting_id;
							t_id[j].tra_sub_obj[k].to_bitmap_id = assoc[i].obj.to_bitmap_id;
							break;
						}
					}
				}
			}
		}
	}
}

void association::end_bmp_assoc()
{
	for (int i = 0; i < assoc_bnum; i++)
	{
		if (!assoc[i].assoc_lock) {
			assoc[i].in_assoc = false;
			assoc[i].pid = -1;
		}
	}
}

void set_win_assoc(bool lock, int w_pos)
{
	for (int i = 0; i < association::assoc_wnum; i++)
	{
		if (!association::a_win[i].in_assoc) {
			association::a_win[i].in_assoc = true;
			association::a_win[i].assoc_lock = lock;
			association::a_win[i].windows_id = w_pos;
			break;
		}
	}
}

void get_win_assoc_date(association::Assoc_win *& pos)
{
	pos = association::a_win;
}

void association::Lock_win_assoc(int j_pid, state_transition_elem::Tran_id * t)
{

}

void association::unLock_win_assoc(int j_pid, state_transition_elem::Tran_id * t)
{

}

void association::sta_win_assoc(controller & con_tran, Gui_sys & animation, text_sys & text)
{
	//如判断为真则开始切换窗口，首先会先清除整个控制表
	//并且锁定事件系统
	//上传新的控制表
	//切换为新的绘制队列
	//窗口关联被触发，将触发窗口切换
	if (a_win[0].in_assoc && !assocw_OK) {
		assocw_OK = true;

		//切换文本系统计时器
		text.res_text();
		text.stop_text_timer(con_tran.get_now_windows());
		//切换Gui窗口
		con_tran.set_now_windows(a_win[0].windows_id);
		con_tran.get_ST_elem_date(con_tran.windows_pos_transition(), con_tran.elem_head, con_tran.get_tran());
		animation.clean_Animation_elem(animation.get_elem(Gui_sys::Ui_ELEM));
		animation.clean_Animation_elem(animation.elem_head);
		animation.update_gui(static_cast<Gui_sys::Gui_name>(con_tran.windows_pos_transition()));//初始化之前先释放前数据
		con_tran.reg_date_in_gui();
		//切换文本系统计时器
		text.start_text_timer(a_win[0].windows_id);
	}
}

bool association::end_win_assoc()
{
	if (!a_win[0].assoc_lock && assocw_OK) {
		assocw_OK = false;
		a_win[0].in_assoc = false;
		a_win[0].windows_id = -1;
		return true;
	}
	return false;
}


association::Assoc_bmp * association::get_bmp_assoc_date()
{
	return assoc;
}

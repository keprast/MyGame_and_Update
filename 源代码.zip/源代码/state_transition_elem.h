﻿#ifndef state_transition_elem_
#define state_transition_elem_

class state_transition_elem
{
public:
	struct Tran_id
	{
		int act_obj;//有多少可操作对象
		bool assoc_lock;//关联锁（窗口和位图公用）
		int assoc_winid;//关联的窗口id
		int to_bitmap_id;//触发点触发的位图id
		int to_acting_id;//触发点触发的行为id

		int lever;//动作权级
		int pid;//身份证
	};

	struct Tran_id_plus
	{
		int tran_id_num;//转换数
		Tran_id * tra_sub_obj;//对应对象
	};

	//如果other_bitmap有效则说明
	//该按钮会触发其他的位图对象
	struct Button_s
	{
		Tran_id * action_id;//触发的动作
		Tran_id * assoc_bmp;//关联位图id

		int button_value;//触发键值
		int assoc_windows_id;//关联窗口id

		bool has_assoc_bmp;//关联位图
		bool has_assoc_win;//关联窗口
		bool assoc_windows_lock;//关联窗口
	};

	//动画触发结构
	struct Animation_tra
	{
		Tran_id * action_id;//当前行为
		Tran_id * assoc_bmp;//关联位图id
		Tran_id * df_action_id;//默认行为
		Button_s * axis_button;//坐标按钮

		float on_t_x;//触发起点x
		float on_t_y;//触发起点y
		float to_t_x;//触发终点x
		float to_t_y;//触发终点y

		int button_num;//按钮数目
		bool button;//存在按钮
		bool has_assoc_bmp;//关联位图
		bool other_Act;//其他动作
	};

	struct Transition
	{
		int sub_action_num;//子动作的数目

		Animation_tra * sub_action;//动画触发坐标
	};

	//转换操作到动画
	struct Transition_op_to_anima
	{
		int windows_id;//触发的窗口id
		int action_count_num;//总共的触发结构数目
		int act_obj_num;//可操作的对象

		Transition * act_obj;
	};

	struct State_Transition_elem
	{
		int e_node_id;//节点id
		State_Transition_elem * after_elem;//前一个节点
		State_Transition_elem * next_elem;//后一个节点

		bool has_date;//数据有无标记（是否有数据，这是抽象标记，实际上初始化时数据为0，也是数据）
		Transition_op_to_anima date;//动画结构
		Transition_op_to_anima * p_date;//动画结构指针
	};

	State_Transition_elem * elem_head;
	State_Transition_elem * elem_tail;

	state_transition_elem();
	~state_transition_elem();

	//创建线性链表
	State_Transition_elem * create_ST_elem(int e_num);
	//创建新节点
	void create_new_node();
	//在某节点后插入一个节点
	void create_an_node(State_Transition_elem * e_head, int node_id);
	//按照顺序获得指针数据
	void get_ST_elem_date(State_Transition_elem * e_head, Transition_op_to_anima * need_date, short state = 0);
	//按照顺序获得栈数据
	void get_ST_elem_date(State_Transition_elem * e_head, Transition_op_to_anima & need_date, short state = 0);
	//获取某一节点的数据
	void get_ST_elem_date(int e_id, State_Transition_elem * e_head, Transition_op_to_anima & need_date);

	//数据自动插入一个空位置
	int in_ST_elem_date_is_null(State_Transition_elem * e_head, Transition_op_to_anima in_date);
	//指针自动插入一个空位置
	int in_ST_elem_date_is_null(State_Transition_elem * e_head, Transition_op_to_anima * in_date);
	//将数据插入某一节点
	void in_ST_elem_date(int e_id, State_Transition_elem * e_head, Transition_op_to_anima & in_date);
	//将数据插入某一节点
	void in_ST_elem_date(int e_id, State_Transition_elem * e_head, Transition_op_to_anima * in_date);
	//按顺序导入栈数据
	void in_ST_elem_date(State_Transition_elem * e_head, Transition_op_to_anima & in_need, short state = 0);
	//按顺序导入指针数据
	void in_ST_elem_date(State_Transition_elem * e_head, Transition_op_to_anima *& in_need, short state = 0);

	//清洗线性链表
	void clean_ST_elem(State_Transition_elem * e_head);
	//破坏线性链表
	void destroy_ST_elem(State_Transition_elem *& e_head);
	//破坏一个节点
	void destroy_an_node(State_Transition_elem * e_head, int node_id);

	//前序遍历
	void pre_order_elem(State_Transition_elem * e_head);
	//后序遍历
	void lrd_order_elem(State_Transition_elem * e_tail);

	//检查线性链表的状态
	int ST_elem_is_state(State_Transition_elem * e_head);
	//获取节点的数目
	int get_elem_node_num();
	//获取有数据的节点的数目
	int get_have_date_node_num(State_Transition_elem * head);

private:
	State_Transition_elem * get_node;//按顺序获取节点标记
	State_Transition_elem * in_node;//按顺序输入节点标记
	int e_node_num;//节点的数目
	int have_date_num;//有数据的节点数目

	//输出结构中的数据
	void get_node_date(State_Transition_elem * e_tail);
};

#endif
